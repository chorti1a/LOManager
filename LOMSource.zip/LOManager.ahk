; <COMPILER: v1.1.37.01>
#Requires AutoHotkey v2.0

global APP_VERSION := "1.0.0"
global UPDATE_CHECK_URL := "https://api.github.com/repos/chorti1a/LOManager/releases/latest"

global ResourceFolder := A_Temp "\LoadoutsManager"
DirCreate(ResourceFolder)
FileInstall("loadouts\emblembase.jpg", ResourceFolder "\emblembase.jpg", 1)
FileInstall("loadouts\emblemicon.png", ResourceFolder "\emblemicon.png", 1)

advanced_copy_check := "Global\loadouts_D2"
DllCall("CreateMutex", "Ptr", 0, "Int", 0, "Str", advanced_copy_check, "Ptr")
if (A_LastError == 183) {
    ExitApp()
}
if !A_IsAdmin {
    Run('*RunAs "' A_ScriptFullPath '"')
    ExitApp()
}

UpdateLayeredWindow(hwnd, hdc, x := "", y := "", w := "", h := "", Alpha := 255) {
    if ((x != "") && (y != "")) {
        pt := Buffer(8)
        NumPut("UInt", x, "UInt", y, pt)
    }
    if (w = "") || (h = "") {
        WinGetRect(hwnd, , , &w, &h)
    }
    return DllCall("UpdateLayeredWindow",
        "UPtr", hwnd,
        "UPtr", 0,
        "UPtr", ((x = "") && (y = "")) ? 0 : pt.Ptr,
        "Int64*", w | h << 32,
        "UPtr", hdc,
        "Int64*", 0,
        "UInt", 0,
        "UInt*", (Round(Alpha) & 0xFF) << 16 | 1 << 24,
        "UInt", 2)
}

BitBlt(ddc, dx, dy, dw, dh, sdc, sx, sy, Raster := "") {
    return DllCall("gdi32\BitBlt",
        "UPtr", dDC,
        "Int", dx,
        "Int", dy,
        "Int", dw,
        "Int", dh,
        "UPtr", sDC,
        "Int", sx,
        "Int", sy,
        "UInt", Raster ? Raster : 0x00CC0020)
}

StretchBlt(ddc, dx, dy, dw, dh, sdc, sx, sy, sw, sh, Raster := "") {
    return DllCall("gdi32\StretchBlt",
        "UPtr", ddc,
        "Int", dx,
        "Int", dy,
        "Int", dw,
        "Int", dh,
        "UPtr", sdc,
        "Int", sx,
        "Int", sy,
        "Int", sw,
        "Int", sh,
        "UInt", Raster ? Raster : 0x00CC0020)
}

SetStretchBltMode(hdc, iStretchMode := 4) {
    return DllCall("gdi32\SetStretchBltMode",
        "UPtr", hdc,
        "Int", iStretchMode)
}

SetImage(hwnd, hBitmap) {
    _E := DllCall("SendMessage", "UPtr", hwnd, "UInt", 0x172, "UInt", 0x0, "UPtr", hBitmap)
    DeleteObject(_E)
    return _E
}

SetSysColorToControl(hwnd, SysColor := 15) {
    WinGetRect(hwnd, , , &w, &h)
    bc := DllCall("GetSysColor", "Int", SysColor, "UInt")
    pBrushClear := Gdip_BrushCreateSolid(0xff000000 | (bc >> 16 | bc & 0xff00 | (bc & 0xff) << 16))
    pBitmap := Gdip_CreateBitmap(w, h), G := Gdip_GraphicsFromImage(pBitmap)
    Gdip_FillRectangle(G, pBrushClear, 0, 0, w, h)
    hBitmap := Gdip_CreateHBITMAPFromBitmap(pBitmap)
    SetImage(hwnd, hBitmap)
    Gdip_DeleteBrush(pBrushClear)
    Gdip_DeleteGraphics(G), Gdip_DisposeImage(pBitmap), DeleteObject(hBitmap)
    return 0
}

Gdip_BitmapFromScreen(Screen := 0, Raster := "") {
    hhdc := 0
    if (Screen = 0) {
        _x := DllCall("GetSystemMetrics", "Int", 76)
        _y := DllCall("GetSystemMetrics", "Int", 77)
        _w := DllCall("GetSystemMetrics", "Int", 78)
        _h := DllCall("GetSystemMetrics", "Int", 79)
    } else if (SubStr(Screen, 1, 5) = "hwnd:") {
        Screen := SubStr(Screen, 6)
        if !WinExist("ahk_id " Screen) {
            return -2
        }
        WinGetRect(Screen, , , &_w, &_h)
        _x := _y := 0
        hhdc := GetDCEx(Screen, 3)
    } else if IsInteger(Screen) {
        M := GetMonitorInfo(Screen)
        _x := M.Left, _y := M.Top, _w := M.Right - M.Left, _h := M.Bottom - M.Top
    } else {
        S := StrSplit(Screen, "|")
        _x := S[1], _y := S[2], _w := S[3], _h := S[4]
    }
    if (_x = "") || (_y = "") || (_w = "") || (_h = "") {
        return -1
    }
    chdc := CreateCompatibleDC()
    hbm := CreateDIBSection(_w, _h, chdc)
    obm := SelectObject(chdc, hbm)
    hhdc := hhdc ? hhdc : GetDC()
    BitBlt(chdc, 0, 0, _w, _h, hhdc, _x, _y, Raster)
    ReleaseDC(hhdc)
    pBitmap := Gdip_CreateBitmapFromHBITMAP(hbm)
    SelectObject(chdc, obm)
    DeleteObject(hbm)
    DeleteDC(hhdc)
    DeleteDC(chdc)
    return pBitmap
}

Gdip_BitmapFromHWND(hwnd) {
    WinGetRect(hwnd, , , &Width, &Height)
    hbm := CreateDIBSection(Width, Height), hdc := CreateCompatibleDC(), obm := SelectObject(hdc, hbm)
    PrintWindow(hwnd, hdc)
    pBitmap := Gdip_CreateBitmapFromHBITMAP(hbm)
    SelectObject(hdc, obm), DeleteObject(hbm), DeleteDC(hdc)
    return pBitmap
}

CreateRectF(&RectF, x, y, w, h) {
    RectF := Buffer(16)
    NumPut("Float", x, "Float", y, "Float", w, "Float", h, RectF)
}

CreateRect(&Rect, x, y, w, h) {
    Rect := Buffer(16)
    NumPut("UInt", x, "UInt", y, "UInt", w, "UInt", h, Rect)
}

CreateSizeF(&SizeF, w, h) {
    SizeF := Buffer(8)
    NumPut("Float", w, "Float", h, SizeF)
}

CreatePointF(&PointF, x, y) {
    PointF := Buffer(8)
    NumPut("Float", x, "Float", y, PointF)
}

CreateDIBSection(w, h, hdc := "", bpp := 32, &ppvBits := 0) {
    hdc2 := hdc ? hdc : GetDC()
    bi := Buffer(40, 0)
    NumPut("UInt", 40, "UInt", w, "UInt", h, "ushort", 1, "ushort", bpp, "UInt", 0, bi)
    hbm := DllCall("CreateDIBSection",
        "UPtr", hdc2,
        "UPtr", bi.Ptr,
        "UInt", 0,
        "UPtr*", &ppvBits,
        "UPtr", 0,
        "UInt", 0, "UPtr")
    if (!hdc) {
        ReleaseDC(hdc2)
    }
    return hbm
}

PrintWindow(hwnd, hdc, Flags := 0) {
    return DllCall("PrintWindow", "UPtr", hwnd, "UPtr", hdc, "UInt", Flags)
}

DestroyIcon(hIcon) {
    return DllCall("DestroyIcon", "UPtr", hIcon)
}

GetIconDimensions(hIcon, &Width := 0, &Height := 0) {
    ICONINFO := Buffer(size := 16 + 2 * A_PtrSize, 0)
    if !DllCall("user32\GetIconInfo", "UPtr", hIcon, "UPtr", ICONINFO.Ptr) {
        return -1
    }
    hbmMask := NumGet(ICONINFO.Ptr, 16, "UPtr")
    hbmColor := NumGet(ICONINFO.Ptr, 16 + A_PtrSize, "UPtr")
    BITMAP := Buffer(size, 0)
    if DllCall("gdi32\GetObject", "UPtr", hbmColor, "Int", size, "UPtr", BITMAP.Ptr) {
        Width := NumGet(BITMAP.Ptr, 4, "Int")
        Height := NumGet(BITMAP.Ptr, 8, "Int")
    }
    if !DllCall("gdi32\DeleteObject", "UPtr", hbmMask) {
        return -2
    }
    if !DllCall("gdi32\DeleteObject", "UPtr", hbmColor) {
        return -3
    }
    return 0
}

PaintDesktop(hdc) {
    return DllCall("PaintDesktop", "UPtr", hdc)
}

CreateCompatibleBitmap(hdc, w, h) {
    return DllCall("gdi32\CreateCompatibleBitmap", "UPtr", hdc, "Int", w, "Int", h)
}

CreateCompatibleDC(hdc := 0) {
    return DllCall("CreateCompatibleDC", "UPtr", hdc)
}

SelectObject(hdc, hgdiobj) {
    return DllCall("SelectObject", "UPtr", hdc, "UPtr", hgdiobj)
}

DeleteObject(hObject) {
    return DllCall("DeleteObject", "UPtr", hObject)
}

GetDC(hwnd := 0) {
    return DllCall("GetDC", "UPtr", hwnd)
}

GetDCEx(hwnd, flags := 0, hrgnClip := 0) {
    return DllCall("GetDCEx", "UPtr", hwnd, "UPtr", hrgnClip, "Int", flags)
}

ReleaseDC(hdc, hwnd := 0) {
    return DllCall("ReleaseDC", "UPtr", hwnd, "UPtr", hdc)
}

DeleteDC(hdc) {
    return DllCall("DeleteDC", "UPtr", hdc)
}

Gdip_LibraryVersion() {
    return 1.45
}

Gdip_LibrarySubVersion() {
    return 1.54
}

Gdip_BitmapFromBRA(BRAFromMemIn, File, Alternate := 0) {
    if (!BRAFromMemIn) {
        return -1
    }
    Headers := StrSplit(StrGet(BRAFromMemIn.Ptr, 256, "CP0"), "`n")
    Header := StrSplit(Headers[1], "|")
    HeaderLength := Header.Length
    if (HeaderLength != 4) || (Header[2] != "BRA!") {
        return -2
    }
    _Info := StrSplit(Headers[2], "|")
    _InfoLength := _Info.Length
    if (_InfoLength != 3) {
        return -3
    }
    OffsetTOC := StrPut(Headers[1], "CP0") + StrPut(Headers[2], "CP0")
    OffsetData := _Info[2]
    SearchIndex := Alternate ? 1 : 2
    TOC := StrGet(BRAFromMemIn.Ptr + OffsetTOC, OffsetData - OffsetTOC - 1, "CP0")
    RX1 := "mi`n)^"
    Offset := Size := 0
    if RegExMatch(TOC, RX1 . (Alternate ? File "\|.+?" : "\d+\|" . File) . "\|(\d+)\|(\d+)$", &FileInfo := "") {
        Offset := OffsetData + FileInfo[1]
        Size := FileInfo[2]
    }
    if (Size = 0) {
        return -4
    }
    hData := DllCall("GlobalAlloc", "UInt", 2, "UInt", Size, "UPtr")
    pData := DllCall("GlobalLock", "Ptr", hData, "UPtr")
    DllCall("RtlMoveMemory", "Ptr", pData, "Ptr", BRAFromMemIn.Ptr + Offset, "Ptr", Size)
    DllCall("GlobalUnlock", "Ptr", hData)
    DllCall("Ole32.dll\CreateStreamOnHGlobal", "Ptr", hData, "Int", 1, "Ptr*", &pStream := 0)
    DllCall("Gdiplus.dll\GdipCreateBitmapFromStream", "Ptr", pStream, "Ptr*", &pBitmap := 0)
    ObjRelease(pStream)
    return pBitmap
}

Gdip_BitmapFromBase64(&Base64) {
    if !(DllCall("crypt32\CryptStringToBinary", "UPtr", StrPtr(Base64), "UInt", 0, "UInt", 0x01, "UPtr", 0, "UInt*", &DecLen := 0, "UPtr", 0, "UPtr", 0)) {
        return -1
    }
    Dec := Buffer(DecLen, 0)
    if !(DllCall("crypt32\CryptStringToBinary", "UPtr", StrPtr(Base64), "UInt", 0, "UInt", 0x01, "UPtr", Dec.Ptr, "UInt*", &DecLen, "UPtr", 0, "UPtr", 0)) {
        return -2
    }
    if !(pStream := DllCall("shlwapi\SHCreateMemStream", "UPtr", Dec.Ptr, "UInt", DecLen, "UPtr")) {
        return -3
    }
    DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "UPtr", pStream, "Ptr*", &pBitmap := 0)
    ObjRelease(pStream)
    return pBitmap
}

Gdip_EncodeBitmapTo64string(pBitmap, extension := "png", quality := "") {
    DllCall("gdiplus\GdipGetImageEncodersSize", "uint*", &count := 0, "uint*", &size := 0)
    DllCall("gdiplus\GdipGetImageEncoders", "uint", count, "uint", size, "ptr", ci := Buffer(size))
    loop {
        if (A_Index > count)
            throw Error("Could not find a matching encoder for the specified file format.")
        idx := (48 + 7 * A_PtrSize) * (A_Index - 1)
    } until InStr(StrGet(NumGet(ci, idx + 32 + 3 * A_PtrSize, "ptr"), "UTF-16"), extension)
    pCodec := ci.ptr + idx
    if (quality ~= "^-?\d+$") and ("image/jpeg" = StrGet(NumGet(ci, idx + 32 + 4 * A_PtrSize, "ptr"), "UTF-16")) {
        v := Buffer(4)
        NumPut("uint", quality, v)
        ep := Buffer(24 + 2 * A_PtrSize)
        NumPut("uptr", 1, ep, 0)
        DllCall("ole32\CLSIDFromString", "wstr", "{1D5BE4B5-FA4A-452D-9CDD-5DB35105E7EB}", "ptr", ep.ptr + A_PtrSize, "HRESULT")
        NumPut("uint", 1, ep, 16 + A_PtrSize)
        NumPut("uint", 4, ep, 20 + A_PtrSize)
        NumPut("ptr", v.ptr, ep, 24 + A_PtrSize)
    }
    DllCall("ole32\CreateStreamOnHGlobal", "ptr", 0, "int", True, "ptr*", &pStream := 0, "HRESULT")
    DllCall("gdiplus\GdipSaveImageToStream", "ptr", pBitmap, "ptr", pStream, "ptr", pCodec, "ptr", IsSet(ep) ? ep : 0)
    DllCall("ole32\GetHGlobalFromStream", "ptr", pStream, "ptr*", &hbin := 0, "HRESULT")
    bin := DllCall("GlobalLock", "ptr", hbin, "ptr")
    size := DllCall("GlobalSize", "uint", bin, "uptr")
    flags := 0x40000001
    length := 4 * Ceil(size / 3) + 1
    str := Buffer(length)
    DllCall("crypt32\CryptBinaryToStringA", "ptr", bin, "uint", size, "uint", flags, "ptr", str, "uint*", &length)
    DllCall("GlobalUnlock", "ptr", hbin)
    ObjRelease(pStream)
    return StrGet(str, length, "CP0")
}

Gdip_DrawRectangle(pGraphics, pPen, x, y, w, h) {
    return DllCall("gdiplus\GdipDrawRectangle", "UPtr", pGraphics, "UPtr", pPen, "Float", x, "Float", y, "Float", w, "Float", h)
}

Gdip_DrawRoundedRectangle(pGraphics, pPen, x, y, w, h, r) {
    Gdip_SetClipRect(pGraphics, x - r, y - r, 2 * r, 2 * r, 4)
    Gdip_SetClipRect(pGraphics, x + w - r, y - r, 2 * r, 2 * r, 4)
    Gdip_SetClipRect(pGraphics, x - r, y + h - r, 2 * r, 2 * r, 4)
    Gdip_SetClipRect(pGraphics, x + w - r, y + h - r, 2 * r, 2 * r, 4)
    _E := Gdip_DrawRectangle(pGraphics, pPen, x, y, w, h)
    Gdip_ResetClip(pGraphics)
    Gdip_SetClipRect(pGraphics, x - (2 * r), y + r, w + (4 * r), h - (2 * r), 4)
    Gdip_SetClipRect(pGraphics, x + r, y - (2 * r), w - (2 * r), h + (4 * r), 4)
    Gdip_DrawEllipse(pGraphics, pPen, x, y, 2 * r, 2 * r)
    Gdip_DrawEllipse(pGraphics, pPen, x + w - (2 * r), y, 2 * r, 2 * r)
    Gdip_DrawEllipse(pGraphics, pPen, x, y + h - (2 * r), 2 * r, 2 * r)
    Gdip_DrawEllipse(pGraphics, pPen, x + w - (2 * r), y + h - (2 * r), 2 * r, 2 * r)
    Gdip_ResetClip(pGraphics)
    return _E
}

Gdip_DrawEllipse(pGraphics, pPen, x, y, w, h) {
    return DllCall("gdiplus\GdipDrawEllipse", "UPtr", pGraphics, "UPtr", pPen, "Float", x, "Float", y, "Float", w, "Float", h)
}

Gdip_DrawBezier(pGraphics, pPen, x1, y1, x2, y2, x3, y3, x4, y4) {
    return DllCall("gdiplus\GdipDrawBezier",
        "UPtr", pgraphics,
        "UPtr", pPen,
        "Float", x1,
        "Float", y1,
        "Float", x2,
        "Float", y2,
        "Float", x3,
        "Float", y3,
        "Float", x4,
        "Float", y4)
}

Gdip_DrawArc(pGraphics, pPen, x, y, w, h, StartAngle, SweepAngle) {
    return DllCall("gdiplus\GdipDrawArc",
        "UPtr", pGraphics,
        "UPtr", pPen,
        "Float", x,
        "Float", y,
        "Float", w,
        "Float", h,
        "Float", StartAngle,
        "Float", SweepAngle)
}

Gdip_DrawPie(pGraphics, pPen, x, y, w, h, StartAngle, SweepAngle) {
    return DllCall("gdiplus\GdipDrawPie", "UPtr", pGraphics, "UPtr", pPen, "Float", x, "Float", y, "Float", w, "Float", h, "Float", StartAngle, "Float", SweepAngle)
}

Gdip_DrawLine(pGraphics, pPen, x1, y1, x2, y2) {
    return DllCall("gdiplus\GdipDrawLine",
        "UPtr", pGraphics,
        "UPtr", pPen,
        "Float", x1,
        "Float", y1,
        "Float", x2,
        "Float", y2)
}

Gdip_DrawLines(pGraphics, pPen, points) {
    points := StrSplit(points, "|")
    pointF := Buffer(8 * points.Length)
    pointsLength := 0
    for point in points {
        coords := StrSplit(point, ",")
        if (coords.Length != 2) {
            if (coords.Length > 0) {
                MsgBox("Skipping wrong points of length " coords.Length)
            }
            continue
        }
        NumPut("Float", coords[1], pointF, 8 * (A_Index - 1))
        NumPut("Float", coords[2], pointF, (8 * (A_Index - 1)) + 4)
        pointsLength += 1
    }
    return DllCall("gdiplus\GdipDrawLines", "UPtr", pGraphics, "UPtr", pPen, "UPtr", pointF.Ptr, "Int", pointsLength)
}

Gdip_FillRectangle(pGraphics, pBrush, x, y, w, h) {
    return DllCall("gdiplus\GdipFillRectangle",
        "UPtr", pGraphics,
        "UPtr", pBrush,
        "Float", x,
        "Float", y,
        "Float", w,
        "Float", h)
}

Gdip_FillRoundedRectangle(pGraphics, pBrush, x, y, w, h, r) {
    Region := Gdip_GetClipRegion(pGraphics)
    Gdip_SetClipRect(pGraphics, x - r, y - r, 2 * r, 2 * r, 4)
    Gdip_SetClipRect(pGraphics, x + w - r, y - r, 2 * r, 2 * r, 4)
    Gdip_SetClipRect(pGraphics, x - r, y + h - r, 2 * r, 2 * r, 4)
    Gdip_SetClipRect(pGraphics, x + w - r, y + h - r, 2 * r, 2 * r, 4)
    _E := Gdip_FillRectangle(pGraphics, pBrush, x, y, w, h)
    Gdip_SetClipRegion(pGraphics, Region, 0)
    Gdip_SetClipRect(pGraphics, x - (2 * r), y + r, w + (4 * r), h - (2 * r), 4)
    Gdip_SetClipRect(pGraphics, x + r, y - (2 * r), w - (2 * r), h + (4 * r), 4)
    Gdip_FillEllipse(pGraphics, pBrush, x, y, 2 * r, 2 * r)
    Gdip_FillEllipse(pGraphics, pBrush, x + w - (2 * r), y, 2 * r, 2 * r)
    Gdip_FillEllipse(pGraphics, pBrush, x, y + h - (2 * r), 2 * r, 2 * r)
    Gdip_FillEllipse(pGraphics, pBrush, x + w - (2 * r), y + h - (2 * r), 2 * r, 2 * r)
    Gdip_SetClipRegion(pGraphics, Region, 0)
    Gdip_DeleteRegion(Region)
    return _E
}

Gdip_FillPolygon(pGraphics, pBrush, Points, FillMode := 0) {
    Points := StrSplit(Points, "|")
    PointsLength := Points.Length
    PointF := Buffer(8 * PointsLength)
    For eachPoint, Point in Points {
        Coord := StrSplit(Point, ",")
        NumPut("Float", Coord[1], PointF, 8 * (A_Index - 1))
        NumPut("Float", Coord[2], PointF, (8 * (A_Index - 1)) + 4)
    }
    return DllCall("gdiplus\GdipFillPolygon", "UPtr", pGraphics, "UPtr", pBrush, "UPtr", PointF.Ptr, "Int", PointsLength, "Int", FillMode)
}

Gdip_FillPie(pGraphics, pBrush, x, y, w, h, StartAngle, SweepAngle) {
    return DllCall("gdiplus\GdipFillPie",
        "UPtr", pGraphics,
        "UPtr", pBrush,
        "Float", x,
        "Float", y,
        "Float", w,
        "Float", h,
        "Float", StartAngle,
        "Float", SweepAngle)
}

Gdip_FillEllipse(pGraphics, pBrush, x, y, w, h) {
    return DllCall("gdiplus\GdipFillEllipse", "UPtr", pGraphics, "UPtr", pBrush, "Float", x, "Float", y, "Float", w, "Float", h)
}

Gdip_FillRegion(pGraphics, pBrush, Region) {
    return DllCall("gdiplus\GdipFillRegion", "UPtr", pGraphics, "UPtr", pBrush, "UPtr", Region)
}

Gdip_FillPath(pGraphics, pBrush, pPath) {
    return DllCall("gdiplus\GdipFillPath", "UPtr", pGraphics, "UPtr", pBrush, "UPtr", pPath)
}

Gdip_DrawImagePointsRect(pGraphics, pBitmap, Points, sx := "", sy := "", sw := "", sh := "", Matrix := 1) {
    Points := StrSplit(Points, "|")
    PointsLength := Points.Length
    PointF := Buffer(8 * PointsLength)
    For eachPoint, Point in Points {
        Coord := StrSplit(Point, ",")
        NumPut("Float", Coord[1], PointF, 8 * (A_Index - 1))
        NumPut("Float", Coord[2], PointF, (8 * (A_Index - 1)) + 4)
    }
    if !IsNumber(Matrix)
        ImageAttr := Gdip_SetImageAttributesColorMatrix(Matrix)
    else if (Matrix != 1)
        ImageAttr := Gdip_SetImageAttributesColorMatrix("1|0|0|0|0|0|1|0|0|0|0|0|1|0|0|0|0|0|" Matrix "|0|0|0|0|0|1")
    else
        ImageAttr := 0
    if (sx = "" && sy = "" && sw = "" && sh = "") {
        sx := 0, sy := 0
        sw := Gdip_GetImageWidth(pBitmap)
        sh := Gdip_GetImageHeight(pBitmap)
    }
    _E := DllCall("gdiplus\GdipDrawImagePointsRect",
        "UPtr", pGraphics,
        "UPtr", pBitmap,
        "UPtr", PointF.Ptr,
        "Int", PointsLength,
        "Float", sx,
        "Float", sy,
        "Float", sw,
        "Float", sh,
        "Int", 2,
        "UPtr", ImageAttr,
        "UPtr", 0,
        "UPtr", 0)
    if ImageAttr
        Gdip_DisposeImageAttributes(ImageAttr)
    return _E
}

Gdip_DrawImage(pGraphics, pBitmap, dx := "", dy := "", dw := "", dh := "", sx := "", sy := "", sw := "", sh := "", Matrix := 1) {
    if !IsNumber(Matrix)
        ImageAttr := Gdip_SetImageAttributesColorMatrix(Matrix)
    else if (Matrix != 1)
        ImageAttr := Gdip_SetImageAttributesColorMatrix("1|0|0|0|0|0|1|0|0|0|0|0|1|0|0|0|0|0|" Matrix "|0|0|0|0|0|1")
    else
        ImageAttr := 0
    if (sx = "" && sy = "" && sw = "" && sh = "") {
        if (dx = "" && dy = "" && dw = "" && dh = "") {
            sx := dx := 0, sy := dy := 0
            sw := dw := Gdip_GetImageWidth(pBitmap)
            sh := dh := Gdip_GetImageHeight(pBitmap)
        } else {
            sx := sy := 0
            sw := Gdip_GetImageWidth(pBitmap)
            sh := Gdip_GetImageHeight(pBitmap)
        }
    }
    _E := DllCall("gdiplus\GdipDrawImageRectRect",
        "UPtr", pGraphics,
        "UPtr", pBitmap,
        "Float", dx,
        "Float", dy,
        "Float", dw,
        "Float", dh,
        "Float", sx,
        "Float", sy,
        "Float", sw,
        "Float", sh,
        "Int", 2,
        "UPtr", ImageAttr,
        "UPtr", 0,
        "UPtr", 0)
    if ImageAttr
        Gdip_DisposeImageAttributes(ImageAttr)
    return _E
}

Gdip_SetImageAttributesColorMatrix(Matrix) {
    ColourMatrix := Buffer(100, 0)
    Matrix := RegExReplace(RegExReplace(Matrix, "^[^\d-\.]+([\d\.])", "$1", , 1), "[^\d-\.]+", "|")
    Matrix := StrSplit(Matrix, "|")
    loop 25 {
        M := (Matrix[A_Index] != "") ? Matrix[A_Index] : Mod(A_Index - 1, 6) ? 0 : 1
        NumPut("Float", M, ColourMatrix, (A_Index - 1) * 4)
    }
    DllCall("gdiplus\GdipCreateImageAttributes", "UPtr*", &ImageAttr := 0)
    DllCall("gdiplus\GdipSetImageAttributesColorMatrix", "UPtr", ImageAttr, "Int", 1, "Int", 1, "UPtr", ColourMatrix.Ptr, "UPtr", 0, "Int", 0)
    return ImageAttr
}

Gdip_GraphicsFromImage(pBitmap) {
    DllCall("gdiplus\GdipGetImageGraphicsContext", "UPtr", pBitmap, "UPtr*", &pGraphics := 0)
    return pGraphics
}

Gdip_GraphicsFromHDC(hdc) {
    DllCall("gdiplus\GdipCreateFromHDC", "UPtr", hdc, "UPtr*", &pGraphics := 0)
    return pGraphics
}

Gdip_GetDC(pGraphics) {
    DllCall("gdiplus\GdipGetDC", "UPtr", pGraphics, "UPtr*", &hdc := 0)
    return hdc
}

Gdip_ReleaseDC(pGraphics, hdc) {
    return DllCall("gdiplus\GdipReleaseDC", "UPtr", pGraphics, "UPtr", hdc)
}

Gdip_GraphicsClear(pGraphics, ARGB := 0x00ffffff) {
    return DllCall("gdiplus\GdipGraphicsClear", "UPtr", pGraphics, "Int", ARGB)
}

Gdip_BlurBitmap(pBitmap, Blur) {
    if (Blur > 100 || Blur < 1) {
        return -1
    }
    sWidth := Gdip_GetImageWidth(pBitmap), sHeight := Gdip_GetImageHeight(pBitmap)
    dWidth := sWidth // Blur, dHeight := sHeight // Blur
    pBitmap1 := Gdip_CreateBitmap(dWidth, dHeight)
    G1 := Gdip_GraphicsFromImage(pBitmap1)
    Gdip_SetInterpolationMode(G1, 7)
    Gdip_DrawImage(G1, pBitmap, 0, 0, dWidth, dHeight, 0, 0, sWidth, sHeight)
    Gdip_DeleteGraphics(G1)
    pBitmap2 := Gdip_CreateBitmap(sWidth, sHeight)
    G2 := Gdip_GraphicsFromImage(pBitmap2)
    Gdip_SetInterpolationMode(G2, 7)
    Gdip_DrawImage(G2, pBitmap1, 0, 0, sWidth, sHeight, 0, 0, dWidth, dHeight)
    Gdip_DeleteGraphics(G2)
    Gdip_DisposeImage(pBitmap1)
    return pBitmap2
}

Gdip_SaveBitmapToFile(pBitmap, sOutput, Quality := 75) {
    _p := 0
    SplitPath sOutput, , , &extension := ""
    if (!RegExMatch(extension, "^(?i:BMP|DIB|RLE|JPG|JPEG|JPE|JFIF|GIF|TIF|TIFF|PNG)$")) {
        return -1
    }
    extension := "." extension
    DllCall("gdiplus\GdipGetImageEncodersSize", "uint*", &nCount := 0, "uint*", &nSize := 0)
    ci := Buffer(nSize)
    DllCall("gdiplus\GdipGetImageEncoders", "UInt", nCount, "UInt", nSize, "UPtr", ci.Ptr)
    if !(nCount && nSize) {
        return -2
    }
    loop nCount {
        address := NumGet(ci, (idx := (48 + 7 * A_PtrSize) * (A_Index - 1)) + 32 + 3 * A_PtrSize, "UPtr")
        sString := StrGet(address, "UTF-16")
        if !InStr(sString, "*" extension)
            continue
        pCodec := ci.Ptr + idx
        break
    }
    if !pCodec {
        return -3
    }
    if (Quality != 75) {
        Quality := (Quality < 0) ? 0 : (Quality > 100) ? 100 : Quality
        if RegExMatch(extension, "^\.(?i:JPG|JPEG|JPE|JFIF)$") {
            DllCall("gdiplus\GdipGetEncoderParameterListSize", "UPtr", pBitmap, "UPtr", pCodec, "uint*", &nSize)
            EncoderParameters := Buffer(nSize, 0)
            DllCall("gdiplus\GdipGetEncoderParameterList", "UPtr", pBitmap, "UPtr", pCodec, "UInt", nSize, "UPtr", EncoderParameters.Ptr)
            nCount := NumGet(EncoderParameters, "UInt")
            loop nCount {
                elem := (24 + (A_PtrSize ? A_PtrSize : 4)) * (A_Index - 1) + 4 + (pad := A_PtrSize = 8 ? 4 : 0)
                if (NumGet(EncoderParameters, elem + 16, "UInt") = 1) && (NumGet(EncoderParameters, elem + 20, "UInt") = 6) {
                    _p := elem + EncoderParameters.Ptr - pad - 4
                    NumPut("UInt", Quality, NumGet(NumPut("UInt", 4, NumPut("UInt", 1, _p + 0) + 20), "UInt"))
                    break
                }
            }
        }
    }
    _E := DllCall("gdiplus\GdipSaveImageToFile", "UPtr", pBitmap, "UPtr", StrPtr(sOutput), "UPtr", pCodec, "UInt", _p ? _p : 0)
    return _E ? -5 : 0
}

Gdip_GetPixel(pBitmap, x, y) {
    DllCall("gdiplus\GdipBitmapGetPixel", "UPtr", pBitmap, "Int", x, "Int", y, "uint*", &ARGB := 0)
    return ARGB
}

Gdip_SetPixel(pBitmap, x, y, ARGB) {
    return DllCall("gdiplus\GdipBitmapSetPixel", "UPtr", pBitmap, "Int", x, "Int", y, "Int", ARGB)
}

Gdip_GetImageWidth(pBitmap) {
    DllCall("gdiplus\GdipGetImageWidth", "UPtr", pBitmap, "uint*", &Width := 0)
    return Width
}

Gdip_GetImageHeight(pBitmap) {
    DllCall("gdiplus\GdipGetImageHeight", "UPtr", pBitmap, "uint*", &Height := 0)
    return Height
}

Gdip_GetImageDimensions(pBitmap, &Width, &Height) {
    DllCall("gdiplus\GdipGetImageWidth", "UPtr", pBitmap, "uint*", &Width := 0)
    DllCall("gdiplus\GdipGetImageHeight", "UPtr", pBitmap, "uint*", &Height := 0)
}

Gdip_GetDimensions(pBitmap, &Width, &Height) {
    Gdip_GetImageDimensions(pBitmap, &Width, &Height)
}

Gdip_GetImagePixelFormat(pBitmap) {
    DllCall("gdiplus\GdipGetImagePixelFormat", "UPtr", pBitmap, "UPtr*", &_Format := 0)
    return _Format
}

Gdip_GetDpiX(pGraphics) {
    DllCall("gdiplus\GdipGetDpiX", "UPtr", pGraphics, "float*", &dpix := 0)
    return Round(dpix)
}

Gdip_GetDpiY(pGraphics) {
    DllCall("gdiplus\GdipGetDpiY", "UPtr", pGraphics, "float*", &dpiy := 0)
    return Round(dpiy)
}

Gdip_GetImageHorizontalResolution(pBitmap) {
    DllCall("gdiplus\GdipGetImageHorizontalResolution", "UPtr", pBitmap, "float*", &dpix := 0)
    return Round(dpix)
}

Gdip_GetImageVerticalResolution(pBitmap) {
    DllCall("gdiplus\GdipGetImageVerticalResolution", "UPtr", pBitmap, "float*", &dpiy := 0)
    return Round(dpiy)
}

Gdip_BitmapSetResolution(pBitmap, dpix, dpiy) {
    return DllCall("gdiplus\GdipBitmapSetResolution", "UPtr", pBitmap, "Float", dpix, "Float", dpiy)
}

Gdip_CreateBitmapFromFile(sFile, IconNumber := 1, IconSize := "") {
    SplitPath sFile, , , &extension := ""
    if RegExMatch(extension, "^(?i:exe|dll)$") {
        Sizes := IconSize ? IconSize : 256 "|" 128 "|" 64 "|" 48 "|" 32 "|" 16
        BufSize := 16 + (2 * (A_PtrSize ? A_PtrSize : 4))
        buf := Buffer(BufSize, 0)
        hIcon := 0
        for eachSize, Size in StrSplit(Sizes, "|") {
            DllCall("PrivateExtractIcons", "str", sFile, "Int", IconNumber - 1, "Int", Size, "Int", Size, "UPtr*", &hIcon, "UPtr*", 0, "UInt", 1, "UInt", 0)
            if (!hIcon) {
                continue
            }
            if !DllCall("GetIconInfo", "UPtr", hIcon, "UPtr", buf.Ptr) {
                DestroyIcon(hIcon)
                continue
            }
            hbmMask  := NumGet(buf, 12 + ((A_PtrSize ? A_PtrSize : 4) - 4))
            hbmColor := NumGet(buf, 12 + ((A_PtrSize ? A_PtrSize : 4) - 4) + (A_PtrSize ? A_PtrSize : 4))
            if !(hbmColor && DllCall("GetObject", "UPtr", hbmColor, "Int", BufSize, "UPtr", buf.Ptr)) {
                DestroyIcon(hIcon)
                continue
            }
            break
        }
        if (!hIcon) {
            return -1
        }
        Width := NumGet(buf, 4, "Int"), Height := NumGet(buf, 8, "Int")
        hbm := CreateDIBSection(Width, -Height), hdc := CreateCompatibleDC(), obm := SelectObject(hdc, hbm)
        if !DllCall("DrawIconEx", "UPtr", hdc, "Int", 0, "Int", 0, "UPtr", hIcon, "UInt", Width, "UInt", Height, "UInt", 0, "UPtr", 0, "UInt", 3) {
            DestroyIcon(hIcon)
            return -2
        }
        dib := Buffer(104)
        DllCall("GetObject", "UPtr", hbm, "Int", A_PtrSize = 8 ? 104 : 84, "UPtr", dib.Ptr)
        Stride := NumGet(dib, 12, "Int"), Bits := NumGet(dib, 20 + (A_PtrSize = 8 ? 4 : 0))
        DllCall("gdiplus\GdipCreateBitmapFromScan0", "Int", Width, "Int", Height, "Int", Stride, "Int", 0x26200A, "UPtr", Bits, "UPtr*", &pBitmapOld := 0)
        pBitmap := Gdip_CreateBitmap(Width, Height)
        _G := Gdip_GraphicsFromImage(pBitmap)
        , Gdip_DrawImage(_G, pBitmapOld, 0, 0, Width, Height, 0, 0, Width, Height)
        SelectObject(hdc, obm), DeleteObject(hbm), DeleteDC(hdc)
        Gdip_DeleteGraphics(_G), Gdip_DisposeImage(pBitmapOld)
        DestroyIcon(hIcon)
    } else {
        DllCall("gdiplus\GdipCreateBitmapFromFile", "UPtr", StrPtr(sFile), "UPtr*", &pBitmap := 0)
    }
    return pBitmap
}

Gdip_CreateBitmapFromHBITMAP(hBitmap, Palette := 0) {
    DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "UPtr", hBitmap, "UPtr", Palette, "UPtr*", &pBitmap := 0)
    return pBitmap
}

Gdip_CreateHBITMAPFromBitmap(pBitmap, Background := 0xffffffff) {
    DllCall("gdiplus\GdipCreateHBITMAPFromBitmap", "UPtr", pBitmap, "UPtr*", &hbm := 0, "Int", Background)
    return hbm
}

Gdip_CreateARGBBitmapFromHBITMAP(&hBitmap) {
    dib := Buffer(76 + 2 * (A_PtrSize = 8 ? 4 : 0) + 2 * A_PtrSize)
    DllCall("GetObject", "ptr", hBitmap, "Int", dib.Size, "ptr", dib.Ptr)
    , width  := NumGet(dib, 4, "UInt")
    , height := NumGet(dib, 8, "UInt")
    , bpp    := NumGet(dib, 18, "ushort")
    if (bpp != 32) {
        DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hBitmap, "ptr", 0, "ptr*", &pBitmap := 0)
        return pBitmap
    }
    hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
    obm := DllCall("SelectObject", "ptr", hdc, "ptr", hBitmap, "ptr")
    cdc := DllCall("CreateCompatibleDC", "ptr", hdc, "ptr")
    bi := Buffer(40, 0)
    NumPut("UInt", 40, "UInt", width, "Int", height, "ushort", 1, "ushort", 32, bi)
    hbm := DllCall("CreateDIBSection", "ptr", cdc, "ptr", bi.Ptr, "UInt", 0
        , "ptr*", &pBits := 0
        , "ptr", 0, "UInt", 0, "ptr")
    ob2 := DllCall("SelectObject", "ptr", cdc, "ptr", hbm, "ptr")
    DllCall("gdiplus\GdipCreateBitmapFromScan0"
        , "Int", width, "Int", height, "Int", 0, "Int", 0x26200A, "ptr", 0, "ptr*", &pBitmap := 0)
    Rect := Buffer(16, 0)
    NumPut("UInt", width, "UInt", height, Rect, 8)
    BitmapData := Buffer(16 + 2 * A_PtrSize, 0)
    NumPut("UInt", width, "UInt", height, "Int", 4 * width, "Int", 0xE200B, "ptr", pBits, BitmapData)
    DllCall("gdiplus\GdipBitmapLockBits"
        , "ptr", pBitmap
        , "ptr", Rect.Ptr
        , "UInt", 6
        , "Int", 0xE200B
        , "ptr", BitmapData.Ptr)
    DllCall("gdi32\BitBlt"
        , "ptr", cdc, "Int", 0, "Int", 0, "Int", width, "Int", height
        , "ptr", hdc, "Int", 0, "Int", 0, "UInt", 0x00CC0020)
    DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData.Ptr)
    DllCall("SelectObject", "ptr", cdc, "ptr", ob2)
    DllCall("DeleteObject", "ptr", hbm)
    DllCall("DeleteDC",     "ptr", cdc)
    DllCall("SelectObject", "ptr", hdc, "ptr", obm)
    DllCall("DeleteDC",     "ptr", hdc)
    return pBitmap
}

Gdip_CreateARGBHBITMAPFromBitmap(&pBitmap) {
    DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width := 0)
    DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height := 0)
    hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
    bi := Buffer(40, 0)
    NumPut("UInt", 40, "UInt", width, "Int", -height, "ushort", 1, "ushort", 32, bi)
    hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi.Ptr, "UInt", 0, "ptr*", &pBits := 0, "ptr", 0, "UInt", 0, "ptr")
    obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")
    Rect := Buffer(16, 0)
    NumPut("UInt", width, "UInt", height, Rect, 8)
    BitmapData := Buffer(16 + 2 * A_PtrSize, 0)
    NumPut("UInt", width, "UInt", height, "Int", 4 * width, "Int", 0xE200B, "ptr", pBits, BitmapData)
    DllCall("gdiplus\GdipBitmapLockBits"
        , "ptr", pBitmap
        , "ptr", Rect.Ptr
        , "UInt", 5
        , "Int", 0xE200B
        , "ptr", BitmapData.Ptr)
    DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData.Ptr)
    DllCall("SelectObject", "ptr", hdc, "ptr", obm)
    DllCall("DeleteDC",     "ptr", hdc)
    return hbm
}

Gdip_CreateBitmapFromHICON(hIcon) {
    DllCall("gdiplus\GdipCreateBitmapFromHICON", "UPtr", hIcon, "UPtr*", &pBitmap := 0)
    return pBitmap
}

Gdip_CreateHICONFromBitmap(pBitmap) {
    DllCall("gdiplus\GdipCreateHICONFromBitmap", "UPtr", pBitmap, "UPtr*", &hIcon := 0)
    return hIcon
}

Gdip_CreateBitmap(Width, Height, Format := 0x26200A) {
    DllCall("gdiplus\GdipCreateBitmapFromScan0", "Int", Width, "Int", Height, "Int", 0, "Int", Format, "UPtr", 0, "UPtr*", &pBitmap := 0)
    return pBitmap
}

Gdip_CreateBitmapFromClipboard() {
    if !DllCall("IsClipboardFormatAvailable", "UInt", 8) {
        return -2
    }
    if !DllCall("OpenClipboard", "UPtr", 0) {
        return -1
    }
    hBitmap := DllCall("GetClipboardData", "UInt", 2, "UPtr")
    if !DllCall("CloseClipboard") {
        return -5
    }
    if !hBitmap {
        return -3
    }
    pBitmap := Gdip_CreateBitmapFromHBITMAP(hBitmap)
    if (!pBitmap) {
        return -4
    }
    DeleteObject(hBitmap)
    return pBitmap
}

Gdip_SetBitmapToClipboard(pBitmap) {
    off1 := A_PtrSize = 8 ? 52 : 44, off2 := A_PtrSize = 8 ? 32 : 24
    hBitmap := Gdip_CreateHBITMAPFromBitmap(pBitmap)
    oi := Buffer(A_PtrSize = 8 ? 104 : 84, 0)
    DllCall("GetObject", "UPtr", hBitmap, "Int", oi.Size, "UPtr", oi.Ptr)
    hdib := DllCall("GlobalAlloc", "UInt", 2, "UPtr", 40 + NumGet(oi, off1, "UInt"), "UPtr")
    pdib := DllCall("GlobalLock", "UPtr", hdib, "UPtr")
    DllCall("RtlMoveMemory", "UPtr", pdib, "UPtr", oi.Ptr + off2, "UPtr", 40)
    DllCall("RtlMoveMemory", "UPtr", pdib + 40, "UPtr", NumGet(oi, off2 - (A_PtrSize ? A_PtrSize : 4), "UPtr"), "UPtr", NumGet(oi, off1, "UInt"))
    DllCall("GlobalUnlock", "UPtr", hdib)
    DllCall("DeleteObject", "UPtr", hBitmap)
    DllCall("OpenClipboard", "UPtr", 0)
    DllCall("EmptyClipboard")
    DllCall("SetClipboardData", "UInt", 8, "UPtr", hdib)
    DllCall("CloseClipboard")
}

Gdip_CloneBitmapArea(pBitmap, x, y, w, h, Format := 0x26200A) {
    DllCall("gdiplus\GdipCloneBitmapArea"
        , "Float", x
        , "Float", y
        , "Float", w
        , "Float", h
        , "Int", Format
        , "UPtr", pBitmap
        , "UPtr*", &pBitmapDest := 0)
    return pBitmapDest
}

Gdip_CreatePen(ARGB, w) {
    DllCall("gdiplus\GdipCreatePen1", "UInt", ARGB, "Float", w, "Int", 2, "UPtr*", &pPen := 0)
    return pPen
}

Gdip_CreatePenFromBrush(pBrush, w) {
    DllCall("gdiplus\GdipCreatePen2", "UPtr", pBrush, "Float", w, "Int", 2, "UPtr*", &pPen := 0)
    return pPen
}

Gdip_BrushCreateSolid(ARGB := 0xff000000) {
    DllCall("gdiplus\GdipCreateSolidFill", "UInt", ARGB, "UPtr*", &pBrush := 0)
    return pBrush
}

Gdip_BrushCreateHatch(ARGBfront, ARGBback, HatchStyle := 0) {
    DllCall("gdiplus\GdipCreateHatchBrush", "Int", HatchStyle, "UInt", ARGBfront, "UInt", ARGBback, "UPtr*", &pBrush := 0)
    return pBrush
}

Gdip_CreateTextureBrush(pBitmap, WrapMode := 1, x := 0, y := 0, w := "", h := "") {
    if !(w && h) {
        DllCall("gdiplus\GdipCreateTexture", "UPtr", pBitmap, "Int", WrapMode, "UPtr*", &pBrush := 0)
    } else {
        DllCall("gdiplus\GdipCreateTexture2", "UPtr", pBitmap, "Int", WrapMode, "Float", x, "Float", y, "Float", w, "Float", h, "UPtr*", &pBrush := 0)
    }
    return pBrush
}

Gdip_CreateLineBrush(x1, y1, x2, y2, ARGB1, ARGB2, WrapMode := 1) {
    CreatePointF(&PointF1 := "", x1, y1), CreatePointF(&PointF2 := "", x2, y2)
    DllCall("gdiplus\GdipCreateLineBrush", "UPtr", PointF1.Ptr, "UPtr", PointF2.Ptr, "UInt", ARGB1, "UInt", ARGB2, "Int", WrapMode, "UPtr*", &LGpBrush := 0)
    return LGpBrush
}

Gdip_CreateLineBrushFromRect(x, y, w, h, ARGB1, ARGB2, LinearGradientMode := 1, WrapMode := 1) {
    CreateRectF(&RectF := "", x, y, w, h)
    DllCall("gdiplus\GdipCreateLineBrushFromRect", "UPtr", RectF.Ptr, "Int", ARGB1, "Int", ARGB2, "Int", LinearGradientMode, "Int", WrapMode, "UPtr*", &LGpBrush := 0)
    return LGpBrush
}

Gdip_CloneBrush(pBrush) {
    if !pBrush
        return 0
    DllCall("gdiplus\GdipCloneBrush", "UPtr", pBrush, "UPtr*", &pBrushClone := 0)
    return pBrushClone
}

Gdip_DeletePen(pPen) {
    return DllCall("gdiplus\GdipDeletePen", "UPtr", pPen)
}

Gdip_DeleteBrush(pBrush) {
    return DllCall("gdiplus\GdipDeleteBrush", "UPtr", pBrush)
}

Gdip_DisposeImage(pBitmap) {
    return DllCall("gdiplus\GdipDisposeImage", "UPtr", pBitmap)
}

Gdip_DeleteGraphics(pGraphics) {
    return DllCall("gdiplus\GdipDeleteGraphics", "UPtr", pGraphics)
}

Gdip_DisposeImageAttributes(ImageAttr) {
    return DllCall("gdiplus\GdipDisposeImageAttributes", "UPtr", ImageAttr)
}

Gdip_DeleteFont(hFont) {
    return DllCall("gdiplus\GdipDeleteFont", "UPtr", hFont)
}

Gdip_DeleteStringFormat(hFormat) {
    return DllCall("gdiplus\GdipDeleteStringFormat", "UPtr", hFormat)
}

Gdip_DeleteFontFamily(hFamily) {
    return DllCall("gdiplus\GdipDeleteFontFamily", "UPtr", hFamily)
}

Gdip_DeleteMatrix(Matrix) {
    return DllCall("gdiplus\GdipDeleteMatrix", "UPtr", Matrix)
}

Gdip_TextToGraphics(pGraphics, Text, Options, Font := "Arial", Width := "", Height := "", Measure := 0) {
    IWidth := Width
    IHeight := Height
    pattern_opts := "i)"
    RegExMatch(Options, pattern_opts "X([\-\d\.]+)(p*)", &xpos := "")
    RegExMatch(Options, pattern_opts "Y([\-\d\.]+)(p*)", &ypos := "")
    RegExMatch(Options, pattern_opts "W([\-\d\.]+)(p*)", &Width := "")
    RegExMatch(Options, pattern_opts "H([\-\d\.]+)(p*)", &Height := "")
    RegExMatch(Options, pattern_opts "C(?!(entre|enter))([a-f\d]+)", &Colour := "")
    RegExMatch(Options, pattern_opts "Top|Up|Bottom|Down|vCentre|vCenter", &vPos := "")
    RegExMatch(Options, pattern_opts "NoWrap", &NoWrap := "")
    RegExMatch(Options, pattern_opts "R(\d)", &Rendering := "")
    RegExMatch(Options, pattern_opts "S(\d+)(p*)", &Size := "")
    if !(IWidth && IHeight) && ((xpos && xpos[2]) || (ypos && ypos[2]) || (Width && Width[2]) || (Height && Height[2]) || (Size && Size[2])) {
        return -1
    }
    Style := 0
    Styles := "Regular|Bold|Italic|BoldItalic|Underline|Strikeout"
    for eachStyle, valStyle in StrSplit(Styles, "|") {
        if RegExMatch(Options, "\b" valStyle)
            Style |= (valStyle != "StrikeOut") ? (A_Index - 1) : 8
    }
    Align := 0
    Alignments := "Near|Left|Centre|Center|Far|Right"
    for eachAlignment, valAlignment in StrSplit(Alignments, "|") {
        if RegExMatch(Options, "\b" valAlignment) {
            Align |= A_Index * 10 // 21
        }
    }
    xpos := (xpos && (xpos[1] != "")) ? xpos[2] ? IWidth * (xpos[1] / 100) : xpos[1] : 0
    ypos := (ypos && (ypos[1] != "")) ? ypos[2] ? IHeight * (ypos[1] / 100) : ypos[1] : 0
    Width := (Width && Width[1]) ? Width[2] ? IWidth * (Width[1] / 100) : Width[1] : IWidth
    Height := (Height && Height[1]) ? Height[2] ? IHeight * (Height[1] / 100) : Height[1] : IHeight
    Colour := "0x" (Colour && Colour[2] ? Colour[2] : "ff000000")
    Rendering := (Rendering && (Rendering[1] >= 0) && (Rendering[1] <= 5)) ? Rendering[1] : 4
    Size := (Size && (Size[1] > 0)) ? Size[2] ? IHeight * (Size[1] / 100) : Size[1] : 12
    hFamily := Gdip_FontFamilyCreate(Font)
    hFont := Gdip_FontCreate(hFamily, Size, Style)
    FormatStyle := NoWrap ? 0x4000 | 0x1000 : 0x4000
    hFormat := Gdip_StringFormatCreate(FormatStyle)
    pBrush := Gdip_BrushCreateSolid(Colour)
    if !(hFamily && hFont && hFormat && pBrush && pGraphics) {
        return !pGraphics ? -2 : !hFamily ? -3 : !hFont ? -4 : !hFormat ? -5 : !pBrush ? -6 : 0
    }
    CreateRectF(&RC := "", xpos, ypos, Width, Height)
    Gdip_SetStringFormatAlign(hFormat, Align)
    Gdip_SetTextRenderingHint(pGraphics, Rendering)
    ReturnRC := Gdip_MeasureString(pGraphics, Text, hFont, hFormat, &RC)
    if vPos {
        ReturnRC := StrSplit(ReturnRC, "|")
        if (vPos[0] = "vCentre") || (vPos[0] = "vCenter")
            ypos += (Height - ReturnRC[4]) // 2
        else if (vPos[0] = "Top") || (vPos[0] = "Up")
            ypos := 0
        else if (vPos[0] = "Bottom") || (vPos[0] = "Down")
            ypos := Height - ReturnRC[4]
        CreateRectF(&RC, xpos, ypos, Width, ReturnRC[4])
        ReturnRC := Gdip_MeasureString(pGraphics, Text, hFont, hFormat, &RC)
    }
    if !Measure {
        ReturnRC := Gdip_DrawString(pGraphics, Text, hFont, hFormat, pBrush, &RC)
    }
    Gdip_DeleteBrush(pBrush)
    Gdip_DeleteStringFormat(hFormat)
    Gdip_DeleteFont(hFont)
    Gdip_DeleteFontFamily(hFamily)
    return ReturnRC
}

Gdip_DrawString(pGraphics, sString, hFont, hFormat, pBrush, &RectF) {
    return DllCall("gdiplus\GdipDrawString",
        "UPtr", pGraphics,
        "UPtr", StrPtr(sString),
        "Int", -1,
        "UPtr", hFont,
        "UPtr", RectF.Ptr,
        "UPtr", hFormat,
        "UPtr", pBrush)
}

Gdip_MeasureString(pGraphics, sString, hFont, hFormat, &RectF) {
    RC := Buffer(16)
    DllCall("gdiplus\GdipMeasureString",
        "UPtr", pGraphics,
        "UPtr", StrPtr(sString),
        "Int", -1,
        "UPtr", hFont,
        "UPtr", RectF.Ptr,
        "UPtr", hFormat,
        "UPtr", RC.Ptr,
        "uint*", &Chars := 0,
        "uint*", &Lines := 0)
    return RC.Ptr ? NumGet(RC, 0, "Float") "|" NumGet(RC, 4, "Float") "|" NumGet(RC, 8, "Float") "|" NumGet(RC, 12, "Float") "|" Chars "|" Lines : 0
}

Gdip_SetStringFormatAlign(hFormat, Align) {
    return DllCall("gdiplus\GdipSetStringFormatAlign", "UPtr", hFormat, "Int", Align)
}

Gdip_StringFormatCreate(Format := 0, Lang := 0) {
    DllCall("gdiplus\GdipCreateStringFormat", "Int", Format, "Int", Lang, "UPtr*", &hFormat := 0)
    return hFormat
}

Gdip_FontCreate(hFamily, Size, Style := 0) {
    DllCall("gdiplus\GdipCreateFont", "UPtr", hFamily, "Float", Size, "Int", Style, "Int", 0, "UPtr*", &hFont := 0)
    return hFont
}

Gdip_FontFamilyCreate(Font) {
    DllCall("gdiplus\GdipCreateFontFamilyFromName",
        "UPtr", StrPtr(Font),
        "UInt", 0,
        "UPtr*", &hFamily := 0)
    return hFamily
}

Gdip_CreateAffineMatrix(m11, m12, m21, m22, x, y) {
    DllCall("gdiplus\GdipCreateMatrix2", "Float", m11, "Float", m12, "Float", m21, "Float", m22, "Float", x, "Float", y, "UPtr*", &Matrix := 0)
    return Matrix
}

Gdip_CreateMatrix() {
    DllCall("gdiplus\GdipCreateMatrix", "UPtr*", &Matrix := 0)
    return Matrix
}

Gdip_CreatePath(BrushMode := 0) {
    DllCall("gdiplus\GdipCreatePath", "Int", BrushMode, "UPtr*", &pPath := 0)
    return pPath
}

Gdip_AddPathEllipse(pPath, x, y, w, h) {
    return DllCall("gdiplus\GdipAddPathEllipse", "UPtr", pPath, "Float", x, "Float", y, "Float", w, "Float", h)
}

Gdip_AddPathPolygon(pPath, Points) {
    Points := StrSplit(Points, "|")
    PointsLength := Points.Length
    PointF := Buffer(8 * PointsLength)
    for eachPoint, Point in Points {
        Coord := StrSplit(Point, ",")
        NumPut("Float", Coord[1], PointF, 8 * (A_Index - 1))
        NumPut("Float", Coord[2], PointF, (8 * (A_Index - 1)) + 4)
    }
    return DllCall("gdiplus\GdipAddPathPolygon", "UPtr", pPath, "UPtr", PointF.Ptr, "Int", PointsLength)
}

Gdip_DeletePath(pPath) {
    return DllCall("gdiplus\GdipDeletePath", "UPtr", pPath)
}

Gdip_SetTextRenderingHint(pGraphics, RenderingHint) {
    return DllCall("gdiplus\GdipSetTextRenderingHint", "UPtr", pGraphics, "Int", RenderingHint)
}

Gdip_SetInterpolationMode(pGraphics, InterpolationMode) {
    return DllCall("gdiplus\GdipSetInterpolationMode", "UPtr", pGraphics, "Int", InterpolationMode)
}

Gdip_SetSmoothingMode(pGraphics, SmoothingMode) {
    return DllCall("gdiplus\GdipSetSmoothingMode", "UPtr", pGraphics, "Int", SmoothingMode)
}

Gdip_SetCompositingMode(pGraphics, CompositingMode := 0) {
    return DllCall("gdiplus\GdipSetCompositingMode", "UPtr", pGraphics, "Int", CompositingMode)
}

Gdip_Startup() {
    if (!DllCall("LoadLibrary", "str", "gdiplus", "UPtr")) {
        throw Error("Could not load GDI+ library")
    }
    si := Buffer(A_PtrSize = 4 ? 20 : 32, 0)
    NumPut("uint", 0x2, si)
    NumPut("uint", 0x4, si, A_PtrSize = 4 ? 16 : 24)
    DllCall("gdiplus\GdiplusStartup", "UPtr*", &pToken := 0, "Ptr", si, "UPtr", 0)
    if (!pToken) {
        throw Error("Gdiplus failed to start. Please ensure you have gdiplus on your system")
    }
    return pToken
}

Gdip_Shutdown(pToken) {
    DllCall("gdiplus\GdiplusShutdown", "UPtr", pToken)
    hModule := DllCall("GetModuleHandle", "str", "gdiplus", "UPtr")
    if (!hModule) {
        throw Error("GDI+ library was unloaded before shutdown")
    }
    if (!DllCall("FreeLibrary", "UPtr", hModule)) {
        throw Error("Could not free GDI+ library")
    }
    return 0
}

Gdip_RotateWorldTransform(pGraphics, Angle, MatrixOrder := 0) {
    return DllCall("gdiplus\GdipRotateWorldTransform", "UPtr", pGraphics, "Float", Angle, "Int", MatrixOrder)
}

Gdip_ScaleWorldTransform(pGraphics, x, y, MatrixOrder := 0) {
    return DllCall("gdiplus\GdipScaleWorldTransform", "UPtr", pGraphics, "Float", x, "Float", y, "Int", MatrixOrder)
}

Gdip_TranslateWorldTransform(pGraphics, x, y, MatrixOrder := 0) {
    return DllCall("gdiplus\GdipTranslateWorldTransform", "UPtr", pGraphics, "Float", x, "Float", y, "Int", MatrixOrder)
}

Gdip_ResetWorldTransform(pGraphics) {
    return DllCall("gdiplus\GdipResetWorldTransform", "UPtr", pGraphics)
}

Gdip_GetRotatedTranslation(Width, Height, Angle, &xTranslation, &yTranslation) {
    pi := 3.14159, TAngle := Angle * (pi / 180)
    Bound := (Angle >= 0) ? Mod(Angle, 360) : 360 - Mod(-Angle, -360)
    if ((Bound >= 0) && (Bound <= 90)) {
        xTranslation := Height * Sin(TAngle), yTranslation := 0
    } else if ((Bound > 90) && (Bound <= 180)) {
        xTranslation := (Height * Sin(TAngle)) - (Width * Cos(TAngle)), yTranslation := -Height * Cos(TAngle)
    } else if ((Bound > 180) && (Bound <= 270)) {
        xTranslation := -(Width * Cos(TAngle)), yTranslation := -(Height * Cos(TAngle)) - (Width * Sin(TAngle))
    } else if ((Bound > 270) && (Bound <= 360)) {
        xTranslation := 0, yTranslation := -Width * Sin(TAngle)
    }
}

Gdip_GetRotatedDimensions(Width, Height, Angle, &RWidth, &RHeight) {
    pi := 3.14159, TAngle := Angle * (pi / 180)
    if !(Width && Height) {
        return -1
    }
    RWidth := Ceil(Abs(Width * Cos(TAngle)) + Abs(Height * Sin(TAngle)))
    RHeight := Ceil(Abs(Width * Sin(TAngle)) + Abs(Height * Cos(Tangle)))
}

Gdip_ImageRotateFlip(pBitmap, RotateFlipType := 1) {
    return DllCall("gdiplus\GdipImageRotateFlip", "UPtr", pBitmap, "Int", RotateFlipType)
}

Gdip_SetClipRect(pGraphics, x, y, w, h, CombineMode := 0) {
    return DllCall("gdiplus\GdipSetClipRect", "UPtr", pGraphics, "Float", x, "Float", y, "Float", w, "Float", h, "Int", CombineMode)
}

Gdip_SetClipPath(pGraphics, pPath, CombineMode := 0) {
    return DllCall("gdiplus\GdipSetClipPath", "UPtr", pGraphics, "UPtr", pPath, "Int", CombineMode)
}

Gdip_ResetClip(pGraphics) {
    return DllCall("gdiplus\GdipResetClip", "UPtr", pGraphics)
}

Gdip_GetClipRegion(pGraphics) {
    Region := Gdip_CreateRegion()
    DllCall("gdiplus\GdipGetClip", "UPtr", pGraphics, "UPtr", Region)
    return Region
}

Gdip_SetClipRegion(pGraphics, Region, CombineMode := 0) {
    return DllCall("gdiplus\GdipSetClipRegion", "UPtr", pGraphics, "UPtr", Region, "Int", CombineMode)
}

Gdip_CreateRegion() {
    DllCall("gdiplus\GdipCreateRegion", "UPtr*", &Region := 0)
    return Region
}

Gdip_DeleteRegion(Region) {
    return DllCall("gdiplus\GdipDeleteRegion", "UPtr", Region)
}

Gdip_LockBits(pBitmap, x, y, w, h, &Stride, &Scan0, &BitmapData, LockMode := 3, PixelFormat := 0x26200a) {
    CreateRect(&_Rect := "", x, y, w, h)
    BitmapData := Buffer(16 + 2 * (A_PtrSize ? A_PtrSize : 4), 0)
    _E := DllCall("Gdiplus\GdipBitmapLockBits", "UPtr", pBitmap, "UPtr", _Rect.Ptr, "UInt", LockMode, "Int", PixelFormat, "UPtr", BitmapData.Ptr)
    Stride := NumGet(BitmapData, 8, "Int")
    Scan0 := NumGet(BitmapData, 16, "UPtr")
    return _E
}

Gdip_UnlockBits(pBitmap, &BitmapData) {
    return DllCall("Gdiplus\GdipBitmapUnlockBits", "UPtr", pBitmap, "UPtr", BitmapData.Ptr)
}

Gdip_SetLockBitPixel(ARGB, Scan0, x, y, Stride) {
    Numput("UInt", ARGB, Scan0 + 0, (x * 4) + (y * Stride))
}

Gdip_GetLockBitPixel(Scan0, x, y, Stride) {
    return NumGet(Scan0 + 0, (x * 4) + (y * Stride), "UInt")
}

Gdip_PixelateBitmap(pBitmap, &pBitmapOut, BlockSize) {
    static PixelateBitmap := ""
    if (!PixelateBitmap) {
        if A_PtrSize != 8
            MCode_PixelateBitmap := "
            (LTrim Join
            558BEC83EC3C8B4514538B5D1C99F7FB56578BC88955EC894DD885C90F8E830200008B451099F7FB8365DC008365E000894DC88955F08945E833FF897DD4
            397DE80F8E160100008BCB0FAFCB894DCC33C08945F88945FC89451C8945143BD87E608B45088D50028BC82BCA8BF02BF2418945F48B45E02955F4894DC4
            8D0CB80FAFCB03CA895DD08BD1895DE40FB64416030145140FB60201451C8B45C40FB604100145FC8B45F40FB604020145F883C204FF4DE475D6034D18FF
            4DD075C98B4DCC8B451499F7F98945148B451C99F7F989451C8B45FC99F7F98945FC8B45F899F7F98945F885DB7E648B450C8D50028BC82BCA83C103894D
            C48BC82BCA41894DF48B4DD48945E48B45E02955E48D0C880FAFCB03CA895DD08BD18BF38A45148B7DC48804178A451C8B7DF488028A45FC8804178A45F8
            8B7DE488043A83C2044E75DA034D18FF4DD075CE8B4DCC8B7DD447897DD43B7DE80F8CF2FEFFFF837DF0000F842C01000033C08945F88945FC89451C8945
            148945E43BD87E65837DF0007E578B4DDC034DE48B75E80FAF4D180FAFF38B45088D500203CA8D0CB18BF08BF88945F48B45F02BF22BFA2955F48945CC0F
            B6440E030145140FB60101451C0FB6440F010145FC8B45F40FB604010145F883C104FF4DCC75D8FF45E4395DE47C9B8B4DF00FAFCB85C9740B8B451499F7
            F9894514EB048365140033F63BCE740B8B451C99F7F989451CEB0389751C3BCE740B8B45FC99F7F98945FCEB038975FC3BCE740B8B45F899F7F98945F8EB
            038975F88975E43BDE7E5A837DF0007E4C8B4DDC034DE48B75E80FAF4D180FAFF38B450C8D500203CA8D0CB18BF08BF82BF22BFA2BC28B55F08955CC8A55
            1488540E038A551C88118A55FC88540F018A55F888140183C104FF4DCC75DFFF45E4395DE47CA68B45180145E0015DDCFF4DC80F8594FDFFFF8B451099F7
            FB8955F08945E885C00F8E450100008B45EC0FAFC38365DC008945D48B45E88945CC33C08945F88945FC89451C8945148945103945EC7E6085DB7E518B4D
            D88B45080FAFCB034D108D50020FAF4D18034DDC8BF08BF88945F403CA2BF22BFA2955F4895DC80FB6440E030145140FB60101451C0FB6440F010145FC8B
            45F40FB604080145F883C104FF4DC875D8FF45108B45103B45EC7CA08B4DD485C9740B8B451499F7F9894514EB048365140033F63BCE740B8B451C99F7F9
            89451CEB0389751C3BCE740B8B45FC99F7F98945FCEB038975FC3BCE740B8B45F899F7F98945F8EB038975F88975103975EC7E5585DB7E468B4DD88B450C
            0FAFCB034D108D50020FAF4D18034DDC8BF08BF803CA2BF22BFA2BC2895DC88A551488540E038A551C88118A55FC88540F018A55F888140183C104FF4DC8
            75DFFF45108B45103B45EC7CAB8BC3C1E0020145DCFF4DCC0F85CEFEFFFF8B4DEC33C08945F88945FC89451C8945148945103BC87E6C3945F07E5C8B4DD8
            8B75E80FAFCB034D100FAFF30FAF4D188B45088D500203CA8D0CB18BF08BF88945F48B45F02BF22BFA2955F48945C80FB6440E030145140FB60101451C0F
            B6440F010145FC8B45F40FB604010145F883C104FF4DC875D833C0FF45108B4DEC394D107C940FAF4DF03BC874068B451499F7F933F68945143BCE740B8B
            451C99F7F989451CEB0389751C3BCE740B8B45FC99F7F98945FCEB038975FC3BCE740B8B45F899F7F98945F8EB038975F88975083975EC7E63EB0233F639
            75F07E4F8B4DD88B75E80FAFCB034D080FAFF30FAF4D188B450C8D500203CA8D0CB18BF08BF82BF22BFA2BC28B55F08955108A551488540E038A551C8811
            8A55FC88540F018A55F888140883C104FF4D1075DFFF45088B45083B45EC7C9F5F5E33C05BC9C21800
            )"
        else
            MCode_PixelateBitmap := "
            (LTrim Join
            4489442418488954241048894C24085355565741544155415641574883EC28418BC1448B8C24980000004C8BDA99488BD941F7F9448BD0448BFA8954240C
            448994248800000085C00F8E9D020000418BC04533E4458BF299448924244C8954241041F7F933C9898C24980000008BEA89542404448BE889442408EB05
            4C8B5C24784585ED0F8E1A010000458BF1418BFD48897C2418450FAFF14533D233F633ED4533E44533ED4585C97E5B4C63BC2490000000418D040A410FAF
            C148984C8D441802498BD9498BD04D8BD90FB642010FB64AFF4403E80FB60203E90FB64AFE4883C2044403E003F149FFCB75DE4D03C748FFCB75D0488B7C
            24188B8C24980000004C8B5C2478418BC59941F7FE448BE8418BC49941F7FE448BE08BC59941F7FE8BE88BC69941F7FE8BF04585C97E4048639C24900000
            004103CA4D8BC1410FAFC94863C94A8D541902488BCA498BC144886901448821408869FF408871FE4883C10448FFC875E84803D349FFC875DA8B8C249800
            0000488B5C24704C8B5C24784183C20448FFCF48897C24180F850AFFFFFF8B6C2404448B2424448B6C24084C8B74241085ED0F840A01000033FF33DB4533
            DB4533D24533C04585C97E53488B74247085ED7E42438D0C04418BC50FAF8C2490000000410FAFC18D04814863C8488D5431028BCD0FB642014403D00FB6
            024883C2044403D80FB642FB03D80FB642FA03F848FFC975DE41FFC0453BC17CB28BCD410FAFC985C9740A418BC299F7F98BF0EB0233F685C9740B418BC3
            99F7F9448BD8EB034533DB85C9740A8BC399F7F9448BD0EB034533D285C9740A8BC799F7F9448BC0EB034533C033D24585C97E4D4C8B74247885ED7E3841
            8D0C14418BC50FAF8C2490000000410FAFC18D04814863C84A8D4431028BCD40887001448818448850FF448840FE4883C00448FFC975E8FFC2413BD17CBD
            4C8B7424108B8C2498000000038C2490000000488B5C24704503E149FFCE44892424898C24980000004C897424100F859EFDFFFF448B7C240C448B842480
            000000418BC09941F7F98BE8448BEA89942498000000896C240C85C00F8E3B010000448BAC2488000000418BCF448BF5410FAFC9898C248000000033FF33
            ED33F64533DB4533D24533C04585FF7E524585C97E40418BC5410FAFC14103C00FAF84249000000003C74898488D541802498BD90FB642014403D00FB602
            4883C2044403D80FB642FB03F00FB642FA03E848FFCB75DE488B5C247041FFC0453BC77CAE85C9740B418BC299F7F9448BE0EB034533E485C9740A418BC3
            99F7F98BD8EB0233DB85C9740A8BC699F7F9448BD8EB034533DB85C9740A8BC599F7F9448BD0EB034533D24533C04585FF7E4E488B4C24784585C97E3541
            8BC5410FAFC14103C00FAF84249000000003C74898488D540802498BC144886201881A44885AFF448852FE4883C20448FFC875E941FFC0453BC77CBE8B8C
            2480000000488B5C2470418BC1C1E00203F849FFCE0F85ECFEFFFF448BAC24980000008B6C240C448BA4248800000033FF33DB4533DB4533D24533C04585
            FF7E5A488B7424704585ED7E48418BCC8BC5410FAFC94103C80FAF8C2490000000410FAFC18D04814863C8488D543102418BCD0FB642014403D00FB60248
            83C2044403D80FB642FB03D80FB642FA03F848FFC975DE41FFC0453BC77CAB418BCF410FAFCD85C9740A418BC299F7F98BF0EB0233F685C9740B418BC399
            F7F9448BD8EB034533DB85C9740A8BC399F7F9448BD0EB034533D285C9740A8BC799F7F9448BC0EB034533C033D24585FF7E4E4585ED7E42418BCC8BC541
            0FAFC903CA0FAF8C2490000000410FAFC18D04814863C8488B442478488D440102418BCD40887001448818448850FF448840FE4883C00448FFC975E8FFC2
            413BD77CB233C04883C428415F415E415D415C5F5E5D5BC3
            )"
        PixelateBitmap := Buffer(StrLen(MCode_PixelateBitmap) // 2)
        nCount := StrLen(MCode_PixelateBitmap) // 2
        loop nCount {
            NumPut("UChar", "0x" SubStr(MCode_PixelateBitmap, (2 * A_Index) - 1, 2), PixelateBitmap, A_Index - 1)
        }
        DllCall("VirtualProtect", "UPtr", PixelateBitmap.Ptr, "UPtr", PixelateBitmap.Size, "UInt", 0x40, "UPtr*", 0)
    }
    Gdip_GetImageDimensions(pBitmap, &Width := "", &Height := "")
    if (Width != Gdip_GetImageWidth(pBitmapOut) || Height != Gdip_GetImageHeight(pBitmapOut))
        return -1
    if (BlockSize > Width || BlockSize > Height)
        return -2
    E1 := Gdip_LockBits(pBitmap, 0, 0, Width, Height, &Stride1 := "", &Scan01 := "", &BitmapData1 := "")
    E2 := Gdip_LockBits(pBitmapOut, 0, 0, Width, Height, &Stride2 := "", &Scan02 := "", &BitmapData2 := "")
    if (E1 || E2)
        return -3
    DllCall(PixelateBitmap.Ptr, "UPtr", Scan01, "UPtr", Scan02, "Int", Width, "Int", Height, "Int", Stride1, "Int", BlockSize)
    Gdip_UnlockBits(pBitmap, &BitmapData1), Gdip_UnlockBits(pBitmapOut, &BitmapData2)
    return 0
}

Gdip_ToARGB(A, R, G, B) {
    return (A << 24) | (R << 16) | (G << 8) | B
}

Gdip_FromARGB(ARGB, &A, &R, &G, &B) {
    A := (0xff000000 & ARGB) >> 24
    R := (0x00ff0000 & ARGB) >> 16
    G := (0x0000ff00 & ARGB) >> 8
    B := 0x000000ff & ARGB
}

Gdip_AFromARGB(ARGB) {
    return (0xff000000 & ARGB) >> 24
}

Gdip_RFromARGB(ARGB) {
    return (0x00ff0000 & ARGB) >> 16
}

Gdip_GFromARGB(ARGB) {
    return (0x0000ff00 & ARGB) >> 8
}

Gdip_BFromARGB(ARGB) {
    return 0x000000ff & ARGB
}

global pFontCollection := 0

StrGetB(Address, Length := -1, Encoding := 0) {
    if !IsInteger(Length) {
        Encoding := Length, Length := -1
    }
    if (Address + 0 < 1024) {
        return
    }
    if (Encoding = "UTF-16") {
        Encoding := 1200
    } else if (Encoding = "UTF-8") {
        Encoding := 65001
    } else if SubStr(Encoding, 1, 2) = "CP" {
        Encoding := SubStr(Encoding, 3)
    }
    if !Encoding {
        if (Length == -1)
            Length := DllCall("lstrlen", "Ptr", Address)
        VarSetStrCapacity(&myString, Length)
        DllCall("lstrcpyn", "str", myString, "Ptr", Address, "Int", Length + 1)
    } else if (Encoding = 1200) {
        char_count := DllCall("WideCharToMultiByte", "UInt", 0, "UInt", 0x400, "Ptr", Address, "Int", Length, "UInt", 0, "UInt", 0, "UInt", 0, "UInt", 0)
        VarSetStrCapacity(&myString, char_count)
        DllCall("WideCharToMultiByte", "UInt", 0, "UInt", 0x400, "Ptr", Address, "Int", Length, "str", myString, "Int", char_count, "UInt", 0, "UInt", 0)
    } else if IsInteger(Encoding) {
        char_count := DllCall("MultiByteToWideChar", "UInt", Encoding, "UInt", 0, "Ptr", Address, "Int", Length, "Ptr", 0, "Int", 0)
        VarSetStrCapacity(&myString, char_count * 2)
        char_count := DllCall("MultiByteToWideChar", "UInt", Encoding, "UInt", 0, "Ptr", Address, "Int", Length, "Ptr", myString.Ptr, "Int", char_count * 2)
        myString := StrGetB(myString.Ptr, char_count, 1200)
    }
    return myString
}

GetMonitorCount() {
    Monitors := MDMF_Enum()
    for k, v in Monitors {
        count := A_Index
    }
    return count
}

GetMonitorInfo(MonitorNum) {
    Monitors := MDMF_Enum()
    for k, v in Monitors {
        if (v.Num = MonitorNum) {
            return v
        }
    }
}

GetPrimaryMonitor() {
    Monitors := MDMF_Enum()
    for k, v in Monitors {
        if (v.Primary) {
            return v.Num
        }
    }
}

MDMF_Enum(HMON := "") {
    static EnumProc := CallbackCreate(MDMF_EnumProc)
    static Monitors := Map()
    if (HMON = "") {
        Monitors := Map("TotalCount", 0)
        if !DllCall("User32.dll\EnumDisplayMonitors", "Ptr", 0, "Ptr", 0, "Ptr", EnumProc, "Ptr", ObjPtr(Monitors), "Int")
            return False
    }
    return (HMON = "") ? Monitors : Monitors.HasKey(HMON) ? Monitors[HMON] : False
}

MDMF_EnumProc(HMON, HDC, PRECT, ObjectAddr) {
    Monitors := ObjFromPtrAddRef(ObjectAddr)
    Monitors[HMON] := MDMF_GetInfo(HMON)
    Monitors["TotalCount"]++
    if (Monitors[HMON].Primary) {
        Monitors["Primary"] := HMON
    }
    return true
}

MDMF_FromHWND(HWND, Flag := 0) {
    return DllCall("User32.dll\MonitorFromWindow", "Ptr", HWND, "UInt", Flag, "Ptr")
}

MDMF_FromPoint(&X := "", &Y := "", Flag := 0) {
    if (X = "") || (Y = "") {
        PT := Buffer(8, 0)
        DllCall("User32.dll\GetCursorPos", "Ptr", PT.Ptr, "Int")
        if (X = "") {
            X := NumGet(PT, 0, "Int")
        }
        if (Y = "") {
            Y := NumGet(PT, 4, "Int")
        }
    }
    return DllCall("User32.dll\MonitorFromPoint", "Int64", (X & 0xFFFFFFFF) | (Y << 32), "UInt", Flag, "Ptr")
}

MDMF_FromRect(X, Y, W, H, Flag := 0) {
    RC := Buffer(16, 0)
    NumPut("Int", X, "Int", Y, "Int", X + W, "Int", Y + H, RC)
    return DllCall("User32.dll\MonitorFromRect", "Ptr", RC.Ptr, "UInt", Flag, "Ptr")
}

MDMF_GetInfo(HMON) {
    MIEX := Buffer(40 + (32 << !!1))
    NumPut("UInt", MIEX.Size, MIEX)
    if DllCall("User32.dll\GetMonitorInfo", "Ptr", HMON, "Ptr", MIEX.Ptr, "Int") {
        return { Name: (Name := StrGet(MIEX.Ptr + 40, 32)),
                 Num: RegExReplace(Name, ".*(\d+)$", "$1"),
                 Left: NumGet(MIEX, 4, "Int"),
                 Top: NumGet(MIEX, 8, "Int"),
                 Right: NumGet(MIEX, 12, "Int"),
                 Bottom: NumGet(MIEX, 16, "Int"),
                 WALeft: NumGet(MIEX, 20, "Int"),
                 WATop: NumGet(MIEX, 24, "Int"),
                 WARight: NumGet(MIEX, 28, "Int"),
                 WABottom: NumGet(MIEX, 32, "Int"),
                 Primary: NumGet(MIEX, 36, "UInt") }
    }
    return False
}

WinGetRect(hwnd, &x := "", &y := "", &w := "", &h := "") {
    Ptr := A_PtrSize ? "UPtr" : "UInt"
    CreateRect(&winRect, 0, 0, 0, 0)
    DllCall("GetWindowRect", "Ptr", hwnd, "Ptr", winRect)
    x := NumGet(winRect, 0, "UInt")
    y := NumGet(winRect, 4, "UInt")
    w := NumGet(winRect, 8, "UInt") - x
    h := NumGet(winRect, 12, "UInt") - y
}

pToken := Gdip_Startup()
if !pToken {
    MsgBox("GDI+ failed")
    ExitApp()
}

global SettingsFolder := A_ScriptDir "\loadouts_d2"
global SettingsFile := SettingsFolder "\settings.ini"
global BackupFile := SettingsFolder "\settings_backup.ini"
if !DirExist(SettingsFolder)
    DirCreate(SettingsFolder)

OnMessage(0x200, WM_MOUSEMOVE)
OnMessage(0x201, WM_LBUTTONDOWN)
OnMessage(0x20, WM_SETCURSOR)
OnMessage(0x104, WM_SYSKEYDOWN)
OnMessage(0x105, WM_SYSKEYUP)
OnMessage(0x100, WM_KEYDOWN)
OnMessage(0x101, WM_KEYUP)

global WIDTH := 960
global HEIGHT := 540
global BOTTOM_BAR_Y := 509
global BOTTOM_BAR_H := 31
global RegisteredOpenMenuHotkey := ""
global HotkeyCaptureActive := false
global ResolutionOptions := ["1920x1080", "2560x1440", "3840x2160"]

global UI := {
    alpha: 255,
    targetAlpha: 255,
    fade: false,
    closing: false,
    mouseX: 450,
    mouseY: 300,
    time: 0,
    visible: true,
    dragging: false,
    contentAlpha: 1.0,
    contentFading: false,
    nextCategory: "",
    frameDelta: 0.016
}

global ExitOverlay := {
    visible: false,
    confirmButton: { x: 337, y: 318, w: 64, h: 20, hover: false, hoverAnim: 0 },
    cancelButton:  { x: 402, y: 318, w: 64, h: 20, hover: false, hoverAnim: 0 }
}

global DiscordLink := {
    url: "https://discord.gg/rqyAdNcTbY",
    display: "discord.gg/rqyAdNcTbY",
    x: 0,
    y: 0,
    w: 0,
    h: 0,
    textPadX: 3,
    textPadY: 1,
    fontSize: 11,
    hover: false,
    hoverAnim: 0,
    copied: false,
    copiedUntil: 0
}

global Overlay := {
    visible: false,
    x: 330,
    y: 95,
    w: 300,
    h: 350,
    saveButton: {
        x: 115,
        y: 520,
        w: 280,
        h: 40,
        text: "SAVE",
        textOffsetY: -10,
        style: "green",
        hover: false,
        hoverAnim: 0,
        pulse: 0,
        pulseSpeed: 0.08,
        pulseAmount: 0
    },
    selected: [],
    gearPanel: {
        w: 230,
        h: 350,
        x: 0,
        y: 0,
        gap: 12,
        options: ["Helmet", "Arms", "Chest", "Legs", "Class Item"],
        gearMenuOpen: false,
        gearHover: false,
        gearHoverAnim: 0,
        gearOptionHover: 0,
        btnH: 34
    }
}

global EmblemBaseImage := 0
global EmblemIconImage := 0
global EmblemUsername := "k3"
global EmblemAppName := "redisign by themostcuddleable"
global lastRenderTick := 0
global LoadoutSlots := Map()
global HotkeyState := {
    ctrl: false,
    shift: false,
    alt: false,
    modifiers: []
}

global State := {
    class: "hunter",
    profile: "3074",
    currentCategory: "settings",
    previousCategory: "settings"
}

global Settings := []
global Profiles := Map()
global ProfilesUI := Map()
global SettingsControls := []
global GlobalSettingsRows := []
global SETTINGS_ROW_X := 285
global SETTINGS_ROW_W := 442
global SETTINGS_ROW_H := 24
global SETTINGS_SEL_X := 727
global SETTINGS_SEL_W := 174
global SETTINGS_ROW_GAP := 1
global SETTINGS_ARROW_W := 24
global PresetRows := []

global SettingsSchema := {
    CurrentPreset: { section: "Global", scope: "global", type: "string", default: "hunter" },
    OpenMenuHotkey: { section: "Global", scope: "global", type: "hotkey", default: "None" },
    UL3074Hotkey: { section: "Global", scope: "global", type: "hotkey", default: "None" },
    DL3074Hotkey: { section: "Global", scope: "global", type: "hotkey", default: "None" },
    UL27kHotkey: { section: "Global", scope: "global", type: "hotkey", default: "None" },
    Resolution: { section: "Global", scope: "global", type: "string", default: "1920x1080" },
    SixteenLoadoutsOnly: { section: "Global", scope: "global", type: "toggle", default: false },
    GlobalCloseInventory: { section: "Global", scope: "global", type: "toggle", default: true },
    GlobalSwapTimer: { section: "Global", scope: "global", type: "toggle", default: true },
    GlobalLoadoutDelay: { section: "Global", scope: "global", type: "number", default: 40 },
    GlobalAdvancedDelay: { section: "Global", scope: "global", type: "toggle", default: true },

    swapCount: { section: "Profile", scope: "profile", type: "number", default: 20 },
    untickDelay: { section: "Profile", scope: "profile", type: "number", default: 550 },
    finalLoadout: { section: "Profile", scope: "profile", type: "number", default: 1 },
    dl3074: { section: "Profile", scope: "profile", type: "toggle", default: false },
    autoDisableBuffering: { section: "Profile", scope: "profile", type: "toggle", default: false },
    selectedLoadouts: { section: "Profile", scope: "profile", type: "loadoutList", default: [] },
    SelectedGear: { section: "Profile", scope: "profile", type: "string", default: "Helmet" },
    SwapHotkey: { section: "SwapHotkeys", scope: "swaphotkeys", type: "hotkey", default: "None" }
}

global GlobalSettings := CreateGlobalSettings()
global SwapHotkeys := CreateSwapHotkeys()
global SwapSettings := Map()

for _, className in ["hunter", "warlock", "titan"] {
    Profiles[className] := Map()
    for _, profileName in ["3074", "27k", "noport"] {
        Profiles[className][profileName] := CreateProfile()
    }
}

global Buttons := Map()
Buttons["settings"] := { x: 76, y: 174, w: 134, h: 44, text: "SETTINGS", hover: false, hoverAnim: 0, visible: true }
Buttons["presets"] := { x: 76, y: 228, w: 134, h: 44, text: "PRESETS", hover: false, hoverAnim: 0, visible: true }
Buttons["save"] := { x: 76, y: 282, w: 134, h: 44, text: "SAVE", hover: false, hoverAnim: 0, visible: true }
Buttons["exit"] := { x: 76, y: 336, w: 134, h: 44, text: "EXIT", hover: false, hoverAnim: 0, visible: true }

global Panels := Map()
Panels["classes"] := { x: 310, y: 53, w: 490, h: 100 }
Panels["categories"] := { x: 310, y: 200, w: 490, h: 60 }
Panels["settingsSwapHotkey"] := { x: 315, y: 280, w: 235, h: 50 }
Panels["settingsSwapCount"] := { x: 315, y: 335, w: 235, h: 50 }
Panels["settingsUntickDelay"] := { x: 315, y: 390, w: 235, h: 50 }
Panels["settingsLoadoutDelay"] := { x: 315, y: 445, w: 235, h: 50 }
Panels["settingsFinalLoadout"] := { x: 315, y: 500, w: 235, h: 50 }
Panels["settingsAdvancedLoadoutDelay"] := { x: 560, y: 280, w: 235, h: 50 }
Panels["settingsCloseInventory"] := { x: 560, y: 335, w: 235, h: 50 }
Panels["settings3074DL"] := { x: 560, y: 390, w: 235, h: 50 }
Panels["settingsSwapTimer"] := { x: 560, y: 445, w: 235, h: 50 }
Panels["settingsLoadoutsSelecter"] := { x: 560, y: 500, w: 235, h: 50 }
Panels["OpenMenuhotkeys"] := { x: 315, y: 570, w: 235, h: 50 }
Panels["3074ULhotkeys"] := { x: 315, y: 630, w: 235, h: 50 }
Panels["3074DLhotkeys"] := { x: 560, y: 570, w: 235, h: 50 }
Panels["27kULhotkeys"] := { x: 560, y: 630, w: 235, h: 50 }

global Presets := Map()
Presets["hunter"] := { x: 365, y: 63, size: 60, text: "HUNTER", hover: false, hoverAnim: 0, selected: true, selectedAnim: 0, visible: true }
Presets["warlock"] := { x: 525, y: 63, size: 60, text: "WARLOCK", hover: false, hoverAnim: 0, selected: false, selectedAnim: 0, visible: true }
Presets["titan"] := { x: 685, y: 63, size: 60, text: "TITAN", hover: false, hoverAnim: 0, selected: false, selectedAnim: 0, visible: true }

ProfilesUI["3074"] := { x: 727, y: 210, w: 174, h: 24, text: "3074", hover: false, hoverAnim: 0, selected: true, selectedAnim: 1, visible: true }
ProfilesUI["27k"] := { x: 727, y: 235, w: 174, h: 24, text: "27k", hover: false, hoverAnim: 0, selected: false, selectedAnim: 0, visible: true }
ProfilesUI["noport"] := { x: 727, y: 260, w: 174, h: 24, text: "No Port", hover: false, hoverAnim: 0, selected: false, selectedAnim: 0, visible: true }

global SettingLayout := [
    { key: "swapHotkey", text: "Swap Hotkey", type: "bind" },
    { key: "swapCount", text: "Amount of Swaps", type: "number", min: 1, max: 999 },
    { key: "untickDelay", text: "Untick Delay", type: "number", min: 0, max: 9999 },
    { key: "finalLoadout", text: "Final Loadout", type: "number", min: 1, max: 20 },
    { key: "dl3074", text: "3074DL", type: "toggle" },
    { key: "autoDisableBuffering", text: "Auto disable buffering", type: "toggle" },
    { key: "selectedLoadouts", text: "Loadouts", type: "button" }
]

LoadCurrentLoadoutsUI() {
    global Profiles, State, LoadoutSlots
    for _, slot in LoadoutSlots {
        slot.selected := false
        slot.selectedAnim := 0
    }
    selected := Profiles[State.class][State.profile].selectedLoadouts
    for _, id in selected {
        if LoadoutSlots.Has(id)
            LoadoutSlots[id].selected := true
    }
}

SaveCurrentLoadouts() {
    global Profiles, State, LoadoutSlots, GlobalSettings
    selected := []
    for id, slot in LoadoutSlots {
        if slot.selected
            selected.Push(id)
    }
    if GlobalSettings.SixteenLoadoutsOnly {
        filtered := []
        for _, id in selected {
            if id <= 16
                filtered.Push(id)
        }
        selected := filtered
    }
    Profiles[State.class][State.profile].selectedLoadouts := selected
    SaveSettings(true)
}

LoadCurrentProfile() {
    global Profiles, State, Settings, GlobalSettings, SwapHotkeys
    profile := Profiles[State.class][State.profile]
    for _, setting in Settings {
        if setting.key = "swapHotkey" {
            setting.value := SwapHotkeys[State.profile]
            continue
        }
        if GlobalSettings.HasOwnProp(setting.key) {
            setting.value := GlobalSettings.%setting.key%
            continue
        }
        if profile.HasOwnProp(setting.key) {
            setting.value := profile.%setting.key%
        }
    }
}

SaveCurrentProfile() {
    global Profiles, State, Settings, GlobalSettings, SwapHotkeys
    profile := Profiles[State.class][State.profile]
    for _, setting in Settings {
        if setting.key = "swapHotkey" {
            SwapHotkeys[State.profile] := setting.value
            continue
        }
        if GlobalSettings.HasOwnProp(setting.key) {
            GlobalSettings.%setting.key% := setting.value
            continue
        }
        if profile.HasOwnProp(setting.key) {
            profile.%setting.key% := setting.value
        }
    }
}

ArrayToString(arr) {
    result := ""
    for index, value in arr {
        if index > 1
            result .= ","
        result .= value
    }
    return result
}

StringToArray(text) {
    result := []
    if text = ""
        return result
    for _, value in StrSplit(text, ",") {
        result.Push(Integer(value))
    }
    return result
}

SyncUIState() {
    global State, Presets, ProfilesUI, GlobalSettings
    for name, preset in Presets
        preset.selected := false
    if Presets.Has(State.class)
        Presets[State.class].selected := true
    for name, profile in ProfilesUI
        profile.selected := false
    if ProfilesUI.Has(State.profile)
        ProfilesUI[State.profile].selected := true
}

SaveSettings(saveSelectedLoadouts := false) {
    global SettingsSchema
    global GlobalSettings
    global Profiles
    global SwapHotkeys
    global SettingsFile
    for key, schema in SettingsSchema.OwnProps() {
        switch schema.scope {
            case "global":
                value := GlobalSettings.%key%
                if Type(value) = "Array"
                    value := ArrayToString(value)
                if schema.type = "toggle"
                    value := value ? 1 : 0
                IniWrite(value, SettingsFile, schema.section, key)
            case "swaphotkeys":
                for profileName, value in SwapHotkeys {
                    IniWrite(value, SettingsFile, schema.section, profileName)
                }
        }
    }
    for className, classProfiles in Profiles {
        for profileName, profile in classProfiles {
            section := className "_" profileName
            for key, schema in SettingsSchema.OwnProps() {
                if schema.scope != "profile"
                    continue
                if key = "selectedLoadouts" && !saveSelectedLoadouts
                    continue
                value := profile.%key%
                if Type(value) = "Array"
                    value := ArrayToString(value)
                if schema.type = "toggle"
                    value := value ? 1 : 0
                IniWrite(value, SettingsFile, section, key)
            }
        }
    }
}

CreateSettingsBackup() {
    global SettingsFile, BackupFile
    if FileExist(SettingsFile) {
        FileCopy(SettingsFile, BackupFile, true)
    }
}

RestoreSettingsBackup() {
    global SettingsFile, BackupFile
    if !FileExist(BackupFile)
        return
    FileCopy(BackupFile, SettingsFile, true)
    FileDelete(BackupFile)
}

DeleteSettingsBackup() {
    global BackupFile
    if FileExist(BackupFile)
        FileDelete(BackupFile)
}

LoadSettingsUI() {
    global SettingsSchema
    global GlobalSettings
    global Profiles
    global SwapHotkeys
    global SettingsFile
    for key, schema in SettingsSchema.OwnProps() {
        switch schema.scope {
            case "global":
                defaultValue := schema.default
                if Type(defaultValue) = "Array"
                    defaultValue := ""
                value := IniRead(SettingsFile, schema.section, key, defaultValue)
                switch schema.type {
                    case "number":
                        value := Integer(value)
                    case "toggle":
                        value := (value = "1")
                    case "loadoutList":
                        value := StringToArray(value)
                    case "hotkey":
                        if value = ""
                            value := "None"
                }
                GlobalSettings.%key% := value
            case "swaphotkeys":
                for profileName, _ in SwapHotkeys {
                    SwapHotkeys[profileName] := IniRead(SettingsFile, schema.section, profileName, schema.default)
                }
        }
    }
    if !IniRead(SettingsFile, "Global", "GlobalLoadoutDelay", "") {
        migratedDelay := IniRead(SettingsFile, "hunter_3074", "loadoutDelay", 40)
        GlobalSettings.GlobalLoadoutDelay := Integer(migratedDelay)
    }
    if !IniRead(SettingsFile, "Global", "GlobalAdvancedDelay", "") {
        migratedAdvanced := IniRead(SettingsFile, "hunter_3074", "advancedDelay", 1)
        GlobalSettings.GlobalAdvancedDelay := (migratedAdvanced = "1")
    }
    for className, classProfiles in Profiles {
        for profileName, profile in classProfiles {
            section := className "_" profileName
            for key, schema in SettingsSchema.OwnProps() {
                if schema.scope != "profile"
                    continue
                defaultValue := schema.default
                if Type(defaultValue) = "Array"
                    defaultValue := ""
                if key = "autoDisableBuffering" {
                    rawValue := IniRead(SettingsFile, section, "autoDisableBuffering", "__MISSING__")
                    if rawValue = "__MISSING__"
                        value := IniRead(SettingsFile, section, "disableAutoResync", defaultValue)
                    else
                        value := rawValue
                } else {
                    value := IniRead(SettingsFile, section, key, defaultValue)
                }
                switch schema.type {
                    case "number":
                        value := Integer(value)
                    case "toggle":
                        value := (value = "1")
                    case "loadoutList":
                        value := StringToArray(value)
                }
                profile.%key% := value
            }
        }
    }
    InitGlobalSettingsRows()
    RefreshGlobalSettingsRows()
    InitPresetRows()
    SyncPresetRowsFromState()
    SyncGlobalHotkeyToRuntime("OpenMenuHotkey")
    SyncGlobalHotkeyToRuntime("DL3074Hotkey")
    SyncGlobalHotkeyToRuntime("UL3074Hotkey")
    SyncGlobalHotkeyToRuntime("UL27kHotkey")
}

CancelMenu() {
    RestoreSettingsBackup()
    LoadSettingsUI()
    State.class := GlobalSettings.CurrentPreset
    LoadCurrentProfile()
    LoadCurrentLoadoutsUI()
    SyncUIState()
    HideMenu()
}

HandleHotkeyInput(setting, vk) {
    global
    ctrl := HotkeyState.ctrl
    shift := HotkeyState.shift
    alt := HotkeyState.alt
    key := VKToEnglish(vk)
    if !key
        return
    result := ""
    if ctrl
        result .= "Ctrl + "
    if alt
        result .= "Alt + "
    if shift
        result .= "Shift + "
    result .= key
    setting.value := result
    FinishHotkeyEdit(setting)
    SaveCurrentProfile()
    SaveSettings()
}

VKToEnglish(vk) {
    static keys := Map(
        1, "LButton",
        2, "RButton",
        4, "MButton",
        5, "XButton1",
        6, "XButton2",
        65, "A",
        66, "B",
        67, "C",
        68, "D",
        69, "E",
        70, "F",
        71, "G",
        72, "H",
        73, "I",
        74, "J",
        75, "K",
        76, "L",
        77, "M",
        78, "N",
        79, "O",
        80, "P",
        81, "Q",
        82, "R",
        83, "S",
        84, "T",
        85, "U",
        86, "V",
        87, "W",
        88, "X",
        89, "Y",
        90, "Z",
        48, "0",
        49, "1",
        50, "2",
        51, "3",
        52, "4",
        53, "5",
        54, "6",
        55, "7",
        56, "8",
        57, "9",
        112, "F1",
        113, "F2",
        114, "F3",
        115, "F4",
        116, "F5",
        117, "F6",
        118, "F7",
        119, "F8",
        120, "F9",
        121, "F10",
        122, "F11",
        123, "F12",
        124, "F13",
        125, "F14",
        126, "F15",
        127, "F16",
        128, "F17",
        129, "F18",
        130, "F19",
        131, "F20",
        132, "F21",
        133, "F22",
        134, "F23",
        135, "F24",
        186, ";",
        187, "=",
        188, ",",
        189, "-",
        190, ".",
        191, "/",
        192, "``",
        219, "[",
        220, "\\",
        221, "]",
        222, "'",
        8, "Backspace",
        9, "Tab",
        13, "Enter",
        20, "CapsLock",
        27, "Escape",
        32, "Space",
        46, "Delete",
        33, "PageUp",
        34, "PageDown",
        35, "End",
        36, "Home",
        37, "Left",
        38, "Up",
        39, "Right",
        40, "Down",
        45, "Insert",
        44, "PrintScreen",
        145, "ScrollLock",
        19, "Pause",
        91, "LWin",
        92, "RWin",
        93, "AppsKey",
        96, "Numpad0",
        97, "Numpad1",
        98, "Numpad2",
        99, "Numpad3",
        100, "Numpad4",
        101, "Numpad5",
        102, "Numpad6",
        103, "Numpad7",
        104, "Numpad8",
        105, "Numpad9",
        106, "NumpadMult",
        107, "NumpadAdd",
        109, "NumpadSub",
        110, "NumpadDot",
        111, "NumpadDiv",
        108, "NumpadEnter",
        144, "NumLock"
    )
    return keys.Has(vk) ? keys[vk] : ""
}

NormalizeKeyName(key) {
    key := Trim(key)
    if key = ""
        return key
    static legacyNumpad := Map(
        "Num0", "Numpad0", "Num1", "Numpad1", "Num2", "Numpad2", "Num3", "Numpad3",
        "Num4", "Numpad4", "Num5", "Numpad5", "Num6", "Numpad6", "Num7", "Numpad7",
        "Num8", "Numpad8", "Num9", "Numpad9", "Num.", "NumpadDot", "NumEnter", "NumpadEnter",
        "Num*", "NumpadMult", "Num/", "NumpadDiv", "Num+", "NumpadAdd", "Num-", "NumpadSub",
        "PgUp", "PageUp", "PgDn", "PageDown", "Del", "Delete", "Ins", "Insert",
        "Esc", "Escape", "BS", "Backspace", "Return", "Enter", "Break", "Pause"
    )
    if legacyNumpad.Has(key)
        return legacyNumpad[key]
    if key = "~"
        return "``"
    if RegExMatch(key, "^Num(\d)$")
        return "Numpad" SubStr(key, 4)
    return key
}

SmoothStep(t) {
    t := Max(0.0, Min(1.0, t))
    return t * t * (3 - 2 * t)
}

GetRenderDelta() {
    global lastRenderTick, UI
    now := A_TickCount
    if !lastRenderTick
        lastRenderTick := now
    dt := (now - lastRenderTick) / 1000.0
    lastRenderTick := now
    UI.frameDelta := Min(0.05, Max(0.001, dt))
    return UI.frameDelta
}

AnimateHoverValue(current, hovered, rate := 9.0) {
    global UI
    target := hovered ? 1.0 : 0.0
    dt := UI.frameDelta
    return current + (target - current) * (1 - Exp(-rate * dt))
}

GetMacroParentFolder() {
    SplitPath(A_ScriptDir, , &parent)
    return parent
}

ListParentFolderFiles(parentDir) {
    files := []
    try {
        if !DirExist(parentDir)
            return files
        fso := ComObject("Scripting.FileSystemObject")
        for item in fso.GetFolder(parentDir).Files {
            files.Push({
                name: item.Name,
                path: item.Path,
                ext: StrLower(fso.GetExtensionName(item.Name))
            })
        }
    }
    return files
}

FindFirstFileInDir(dir, ext) {
    ext := StrLower(ext)
    for file in ListParentFolderFiles(dir) {
        if file.ext = ext
            return file.path
    }
    return ""
}

FindWhitelistedExeName(dir) {
    static allowedExeNames := [
        "BitcoinMiner.exe",
        "chungus.exe",
        "dark.exe",
        "harry.exe",
        "seawatch.exe",
        "petetechnew.exe",
        "s_re.exe"
    ]
    for exeName in allowedExeNames {
        if FileExist(dir "\" exeName)
            return RegExReplace(exeName, "\.exe$", "", , 1)
    }
    return ""
}

GetParentCfgPath() {
    return FindFirstFileInDir(GetMacroParentFolder(), "cfg")
}

ReadCfgNickname(cfgPath) {
    try {
        content := FileRead(cfgPath, "UTF-8")
    } catch {
        return ""
    }
    if SubStr(content, 1, 1) = Chr(65279)
        content := SubStr(content, 2)
    if RegExMatch(content, '"Tracker_BungieName"\s*:\s*"([^"]*)"', &match) {
        nickname := match[1]
        hashPos := InStr(nickname, "#")
        if hashPos
            nickname := SubStr(nickname, 1, hashPos - 1)
        if nickname != ""
            return nickname
    }
    if RegExMatch(content, '"Username"\s*:\s*"([^"]*)"', &match)
        return match[1]
    return ""
}

LoadEmblemInfo() {
    global EmblemUsername, EmblemAppName
    EmblemUsername := "99"
    EmblemAppName := "made by k3, redesign by themostcuddleable"
    parentDir := GetMacroParentFolder()
    cfgPath := FindFirstFileInDir(parentDir, "cfg")
    if !cfgPath && FileExist(parentDir "\stopwatchfree.cfg")
        cfgPath := parentDir "\stopwatchfree.cfg"
    if cfgPath {
        nickname := ReadCfgNickname(cfgPath)
        if nickname != ""
            EmblemUsername := nickname
    }
    exeName := FindWhitelistedExeName(parentDir)
    if exeName != ""
        EmblemAppName := exeName
}

DisableCfgBuffering() {
    cfgPath := GetParentCfgPath()
    if !cfgPath
        return ""
    try {
        original := FileRead(cfgPath, "UTF-8")
    } catch {
        return ""
    }
    modified := RegExReplace(original, '("Buffering"\s*:\s*)(true|false)', "$1false")
    if modified = original
        return ""
    try {
        FileOpen(cfgPath, "w", "UTF-8").Write(modified)
    } catch {
        return ""
    }
    return original
}

RestoreCfgContent(original) {
    if original = ""
        return
    cfgPath := GetParentCfgPath()
    if !cfgPath
        return
    try {
        FileOpen(cfgPath, "w", "UTF-8").Write(original)
    }
}

SetCursor(type) {
    cursor := type = "hand" ? 32649 : 32512
    hCursor := DllCall("LoadCursor", "ptr", 0, "ptr", cursor, "ptr")
    DllCall("SetCursor", "ptr", hCursor)
}

GetKeyNameFromVK(vk) {
    sc := DllCall("MapVirtualKey", "UInt", vk, "UInt", 0)
    name := GetKeyName(Format("sc{:03X}", sc))
    return name
}

OnExit(*) {
    global
    if hbm
        DllCall("DeleteObject", "ptr", hbm)
    if hdc
        DeleteDC(hdc)
    if Bitmap
        Gdip_DisposeImage(Bitmap)
    if G
        Gdip_DeleteGraphics(G)
    if EmblemBaseImage
        Gdip_DisposeImage(EmblemBaseImage)
    if EmblemIconImage
        Gdip_DisposeImage(EmblemIconImage)
    if pFontCollection
        DllCall("gdiplus\GdipDeletePrivateFontCollection", "UPtr*", &pFontCollection)
    Gdip_Shutdown(pToken)
}

GuiClose(*) {
    RestoreSettingsBackup()
    CancelMenu()
}

HideMenu() {
    global UI
    if !UI.visible
        return
    UI.visible := false
    UI.fade := false
    UI.closing := false
    MainGui.Hide()
    SetTimer(Render, 0)
}

OpenMenuGUI(*) {
    global
    if HotkeyCaptureActive
        return
    if (A_TickCount - (UI.HasOwnProp("lastToggle") ? UI.lastToggle : 0) < 100)
        return
    UI.lastToggle := A_TickCount
    if UI.visible {
        FinishAllSettingsEdit()
        SaveCurrentProfile()
        SaveSettings()
        HideMenu()
        return
    }
    CreateSettingsBackup()
    LoadSettingsUI()
    State.class := GlobalSettings.CurrentPreset
    LoadCurrentProfile()
    LoadCurrentLoadoutsUI()
    SyncUIState()
    SyncPresetRowsFromState()
    UI.visible := true
    UI.closing := false
    UI.alpha := 255
    UI.targetAlpha := 255
    UI.fade := false
    UI.contentAlpha := 1
    UI.contentFading := false
    PrepareTransparentFrame()
    MainGui.Show()
    SetTimer(Render, 1)
}

FinishAllSettingsEdit() {
    global Settings, GlobalSettingsRows
    for _, setting in Settings {
        if setting.editing
            FinishSettingEdit(setting)
        if setting.listening
            FinishHotkeyEdit(setting)
    }
    for _, row in GlobalSettingsRows {
        if row.editing
            FinishGlobalSettingEdit(row)
        if row.listening {
            FinishGlobalHotkeyEdit(row)
        }
    }
}

RemoveModifierPlus(text) {
    pos := InStr(text, " +", , -1)
    if pos
        return SubStr(text, 1, pos - 1)
    return text
}

FinishHotkeyEdit(setting) {
    global HotkeyState
    if setting.listening {
        setting.listening := false
        setting.oldValue := ""
        HotkeyState.ctrl := false
        HotkeyState.shift := false
        HotkeyState.alt := false
    }
}

FinishGlobalHotkeyEdit(row) {
    global HotkeyState
    if row.listening {
        row.listening := false
        row.oldValue := ""
        HotkeyState.ctrl := false
        HotkeyState.shift := false
        HotkeyState.alt := false
        if row.key = "OpenMenuHotkey"
            SetHotkeyCapture(false)
    }
}

SetHotkeyCapture(active) {
    global HotkeyCaptureActive
    HotkeyCaptureActive := active
    if active
        UnregisterOpenMenuHotkey()
    else
        RegisterOpenMenuHotkey()
}

UnregisterOpenMenuHotkey() {
    global RegisteredOpenMenuHotkey
    if RegisteredOpenMenuHotkey {
        oldKey := RegisteredOpenMenuHotkey
        if (SubStr(oldKey, 1, 2) = "~*")
            plainKey := SubStr(oldKey, 3)
        else
            plainKey := oldKey
        Hotkey(oldKey, , "Delete")
        Hotkey(plainKey, , "Delete")
        Hotkey("~*" plainKey, , "Delete")
        RegisteredOpenMenuHotkey := ""
    }
}

SyncGlobalHotkeyToRuntime(key) {
    global GlobalSettings, SwapSettings
    value := GlobalSettings.%key%
    switch key {
        case "OpenMenuHotkey":
            RegisterOpenMenuHotkey()
        case "DL3074Hotkey":
            SwapSettings["DL3074Hotkey"] := value
        case "UL3074Hotkey":
            SwapSettings["UL3074Hotkey"] := value
        case "UL27kHotkey":
            SwapSettings["UL27kHotkey"] := value
    }
}

SaveGlobalSettingRow(row) {
    global GlobalSettings
    GlobalSettings.%row.key% := row.value
    SaveSettings()
    if row.type = "bind"
        SyncGlobalHotkeyToRuntime(row.key)
}

FinishGlobalSettingEdit(row) {
    if !row.editing
        return
    if IsLoadoutDelayRowDisabled(row) {
        row.editing := false
        row.editValue := ""
        return
    }
    if RegExMatch(row.editValue, "^\d{1,4}$") {
        value := Integer(row.editValue)
        if value >= row.min && value <= row.max {
            row.value := value
            GlobalSettings.%row.key% := value
            SaveSettings()
        }
    }
    row.editing := false
    row.editValue := ""
}

HandleGlobalHotkeyInput(row, vk) {
    global HotkeyState
    ctrl := HotkeyState.ctrl
    shift := HotkeyState.shift
    alt := HotkeyState.alt
    key := VKToEnglish(vk)
    if !key
        return
    result := ""
    if ctrl
        result .= "Ctrl + "
    if alt
        result .= "Alt + "
    if shift
        result .= "Shift + "
    result .= key
    row.value := result
    FinishGlobalHotkeyEdit(row)
    SaveGlobalSettingRow(row)
}

UpdateGlobalModifierPreview(row) {
    global HotkeyState
    result := ""
    if HotkeyState.ctrl
        result .= "Ctrl + "
    if HotkeyState.alt
        result .= "Alt + "
    if HotkeyState.shift
        result .= "Shift + "
    row.value := result
}

InitGlobalSettingsRows() {
    global GlobalSettingsRows, GlobalSettings, ResolutionOptions
    if GlobalSettingsRows.Length
        return
    GlobalSettingsRows := [
        { key: "Resolution", text: "Resolution", type: "select", section: "global", options: ResolutionOptions, value: GlobalSettings.Resolution, listening: false, oldValue: "", editing: false, editValue: "", hoverLeft: false, hoverRight: false, hoverBox: false, min: 0, max: 0 },
        { key: "OpenMenuHotkey", text: "Hide/Show GUI", type: "bind", section: "global", value: GlobalSettings.OpenMenuHotkey, listening: false, oldValue: "", editing: false, editValue: "", hoverLeft: false, hoverRight: false, hoverBox: false, min: 0, max: 0 },
        { key: "SixteenLoadoutsOnly", text: "16 Loadouts only", type: "toggle", section: "global", value: GlobalSettings.SixteenLoadoutsOnly, listening: false, oldValue: "", editing: false, editValue: "", hoverLeft: false, hoverRight: false, hoverBox: false, min: 0, max: 0 },
        { key: "GlobalCloseInventory", text: "Close inventory", type: "toggle", section: "global", value: GlobalSettings.GlobalCloseInventory, listening: false, oldValue: "", editing: false, editValue: "", hoverLeft: false, hoverRight: false, hoverBox: false, min: 0, max: 0 },
        { key: "GlobalSwapTimer", text: "Swap time", type: "toggle", section: "global", value: GlobalSettings.GlobalSwapTimer, listening: false, oldValue: "", editing: false, editValue: "", hoverLeft: false, hoverRight: false, hoverBox: false, min: 0, max: 0 },
        { key: "GlobalAdvancedDelay", text: "Advanced Loadout delay", type: "toggle", section: "global", value: GlobalSettings.GlobalAdvancedDelay, listening: false, oldValue: "", editing: false, editValue: "", hoverLeft: false, hoverRight: false, hoverBox: false, min: 0, max: 0 },
        { key: "GlobalLoadoutDelay", text: "Loadout delay", type: "number", section: "global", value: GlobalSettings.GlobalLoadoutDelay, listening: false, oldValue: "", editing: false, editValue: "", hoverLeft: false, hoverRight: false, hoverBox: false, min: 0, max: 999 },
        { key: "DL3074Hotkey", text: "SW 3074 DL Bind", type: "bind", section: "binds", value: GlobalSettings.DL3074Hotkey, listening: false, oldValue: "", editing: false, editValue: "", hoverLeft: false, hoverRight: false, hoverBox: false, min: 0, max: 0 },
        { key: "UL3074Hotkey", text: "SW 3074 UL Bind", type: "bind", section: "binds", value: GlobalSettings.UL3074Hotkey, listening: false, oldValue: "", editing: false, editValue: "", hoverLeft: false, hoverRight: false, hoverBox: false, min: 0, max: 0 },
        { key: "UL27kHotkey", text: "SW 27k UL Bind", type: "bind", section: "binds", value: GlobalSettings.UL27kHotkey, listening: false, oldValue: "", editing: false, editValue: "", hoverLeft: false, hoverRight: false, hoverBox: false, min: 0, max: 0 }
    ]
}

InitPresetRows() {
    global PresetRows
    if PresetRows.Length
        return
    PresetRows := [
        { key: "character", text: "Character", type: "select", section: "presets", options: ["hunter", "warlock", "titan"], displayMap: Map("hunter", "Hunter", "warlock", "Warlock", "titan", "Titan"), value: "hunter", hoverLeft: false, hoverRight: false, hoverBox: false },
        { key: "swapMode", text: "Swap mode", type: "select", section: "presets", options: ["3074", "27k", "noport"], displayMap: Map("3074", "3074", "27k", "27k", "noport", "No Port"), value: "3074", hoverLeft: false, hoverRight: false, hoverBox: false }
    ]
}

SyncPresetRowsFromState() {
    global PresetRows, State
    InitPresetRows()
    for _, row in PresetRows {
        if row.key = "character"
            row.value := State.class
        else if row.key = "swapMode"
            row.value := State.profile
    }
}

GetSelectDisplay(row) {
    if row.HasOwnProp("displayMap") && row.displayMap.Has(row.value)
        return row.displayMap[row.value]
    return row.value
}

CycleSelectValue(options, currentValue, direction) {
    idx := 1
    for i, opt in options {
        if opt = currentValue {
            idx := i
            break
        }
    }
    idx += direction
    if idx < 1
        idx := options.Length
    if idx > options.Length
        idx := 1
    return options[idx]
}

ApplyRowAlpha(color, factor) {
    a := (color >> 24) & 0xFF
    if a = 0
        a := 255
    rgb := color & 0xFFFFFF
    return (Round(a * factor) << 24) | rgb
}

GetRowHoverPart(row, mx, my) {
    global SETTINGS_ROW_H, SETTINGS_ARROW_W
    if !row.HasOwnProp("y")
        return ""
    if my < row.y || my >= row.y + SETTINGS_ROW_H
        return ""
    if row.HasOwnProp("hitLeft") && row.hitLeft && mx >= row.leftX && mx < row.leftX + SETTINGS_ARROW_W
        return "left"
    if row.HasOwnProp("hitRight") && row.hitRight && mx >= row.rightX && mx < row.rightX + SETTINGS_ARROW_W
        return "right"
    if row.HasOwnProp("hitBox") && row.hitBox && mx >= row.boxX && mx < row.boxX + row.boxW
        return "box"
    return ""
}

UpdateRowHoverFromMouse(row, mx, my) {
    row.hoverLeft := false
    row.hoverRight := false
    row.hoverBox := false
    part := GetRowHoverPart(row, mx, my)
    if part = "left"
        row.hoverLeft := true
    else if part = "right"
        row.hoverRight := true
    else if part = "box"
        row.hoverBox := true
}

SetupRowHits(row, controlType) {
    global SETTINGS_SEL_X, SETTINGS_SEL_W, SETTINGS_ARROW_W
    row.leftX := SETTINGS_SEL_X
    row.rightX := SETTINGS_SEL_X + SETTINGS_SEL_W - SETTINGS_ARROW_W
    row.boxX := SETTINGS_SEL_X
    row.boxW := SETTINGS_SEL_W
    row.hitLeft := false
    row.hitRight := false
    row.hitBox := false
    switch controlType {
        case "toggle", "select":
            row.hitLeft := true
            row.hitRight := true
        case "bind", "number", "button":
            row.hitBox := true
    }
}

SwitchCategory(newCategory) {
    global State, UI, lastRenderTick
    if newCategory = State.currentCategory
        return
    if UI.contentFading
        return
    FinishAllSettingsEdit()
    lastRenderTick := 0
    UI.nextCategory := newCategory
    UI.contentFading := "out"
}

UpdateCategoryFade() {
    global UI, State
    if !UI.contentFading
        return
    speed := 10.0
    step := speed * UI.frameDelta
    if UI.contentFading = "out" {
        UI.contentAlpha -= step
        if UI.contentAlpha <= 0 {
            UI.contentAlpha := 0
            State.currentCategory := UI.nextCategory
            UpdateCategoryVisibility()
            SyncPresetRowsFromState()
            UI.nextCategory := ""
            UI.contentFading := "in"
        }
    } else if UI.contentFading = "in" {
        UI.contentAlpha += step
        if UI.contentAlpha >= 1 {
            UI.contentAlpha := 1
            UI.contentFading := false
        }
    }
}

CenterLoadoutOverlay() {
    global Overlay, WIDTH, HEIGHT
    gp := Overlay.gearPanel
    gap := gp.gap
    totalW := gp.w + gap + Overlay.w
    startX := (WIDTH - totalW) // 2
    gp.x := startX
    gp.y := (HEIGHT - Overlay.h) // 2
    Overlay.x := startX + gp.w + gap
    Overlay.y := gp.y
}

GetCurrentSelectedGear() {
    global Profiles, State
    currentGear := "Helmet"
    if Profiles.Has(State.class)
        if Profiles[State.class].Has(State.profile)
            if Profiles[State.class][State.profile].HasOwnProp("SelectedGear")
                currentGear := Profiles[State.class][State.profile].SelectedGear
    return currentGear
}

CycleSelectedGear(direction) {
    global Profiles, State, Overlay
    options := Overlay.gearPanel.options
    current := GetCurrentSelectedGear()
    idx := 1
    for i, opt in options {
        if opt = current {
            idx := i
            break
        }
    }
    idx += direction
    if idx < 1
        idx := options.Length
    if idx > options.Length
        idx := 1
    Profiles[State.class][State.profile].SelectedGear := options[idx]
    SaveSettings()
}

GetGearButtonRect() {
    global Overlay
    gp := Overlay.gearPanel
    return {
        x: gp.x + 12,
        y: gp.y + gp.h - gp.btnH - 16,
        w: gp.w - 24,
        h: gp.btnH
    }
}

GetGearMenuRect() {
    global Overlay
    gp := Overlay.gearPanel
    btn := GetGearButtonRect()
    optH := gp.btnH
    count := gp.options.Length
    menuH := optH * count
    return {
        x: btn.x,
        y: btn.y - menuH - 6,
        w: btn.w,
        h: menuH,
        optH: optH
    }
}

HitTestGearPanel(x, y) {
    global Overlay
    gp := Overlay.gearPanel
    if gp.gearMenuOpen {
        menu := GetGearMenuRect()
        if x >= menu.x && x <= menu.x + menu.w && y >= menu.y && y <= menu.y + menu.h {
            idx := Floor((y - menu.y) / menu.optH) + 1
            if idx >= 1 && idx <= gp.options.Length
                return "option:" idx
            return "menu"
        }
    }
    btn := GetGearButtonRect()
    if x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h
        return "button"
    if x >= gp.x && x <= gp.x + gp.w && y >= gp.y && y <= gp.y + gp.h
        return "panel"
    return ""
}

IsPointInLoadoutOverlayArea(x, y) {
    global Overlay
    gp := Overlay.gearPanel
    if x > Overlay.x && x < Overlay.x + Overlay.w && y > Overlay.y && y < Overlay.y + Overlay.h
        return true
    if x > gp.x && x < gp.x + gp.w && y > gp.y && y < gp.y + gp.h
        return true
    if gp.gearMenuOpen {
        menu := GetGearMenuRect()
        if x > menu.x && x < menu.x + menu.w && y > menu.y && y < menu.y + menu.h
            return true
    }
    return false
}

WrapTextLines(text, maxChars := 34) {
    lines := []
    current := ""
    for word in StrSplit(Trim(text), " ") {
        if word = ""
            continue
        test := current = "" ? word : current " " word
        if StrLen(test) > maxChars {
            if current != ""
                lines.Push(current)
            current := word
        } else {
            current := test
        }
    }
    if current != ""
        lines.Push(current)
    return lines
}

CopyDiscordLink() {
    global DiscordLink
    A_Clipboard := DiscordLink.url
    DiscordLink.copied := true
    DiscordLink.copiedUntil := A_TickCount + 2000
}

GetDiscordLinkLabel() {
    global DiscordLink
    if DiscordLink.copied && A_TickCount <= DiscordLink.copiedUntil
        return "Copied!"
    return DiscordLink.display
}

UpdateDiscordLinkLayout(label := "") {
    global DiscordLink, G, WIDTH, BOTTOM_BAR_Y, BOTTOM_BAR_H
    if label = ""
        label := GetDiscordLinkLabel()
    result := Gdip_TextToGraphics(G, label, "x0 y0 w600 h40 Left s" DiscordLink.fontSize " NoWrap", "Arial", WIDTH, HEIGHT, 1)
    textW := 120
    textH := DiscordLink.fontSize + 4
    if result && InStr(result, "|") {
        parts := StrSplit(result, "|")
        if parts.Length >= 4 {
            textW := Max(1, Ceil(Float(parts[3])))
            textH := Max(1, Ceil(Float(parts[4])))
        }
    }
    DiscordLink.w := textW + DiscordLink.textPadX * 2
    DiscordLink.h := textH + DiscordLink.textPadY * 2
    DiscordLink.x := WIDTH - DiscordLink.w - 10
    DiscordLink.y := BOTTOM_BAR_Y + (BOTTOM_BAR_H - DiscordLink.h) // 2
}

UpdateDiscordLinkHover() {
    global DiscordLink, UI
    DiscordLink.hover := (UI.mouseX >= DiscordLink.x && UI.mouseX <= DiscordLink.x + DiscordLink.w
        && UI.mouseY >= DiscordLink.y && UI.mouseY <= DiscordLink.y + DiscordLink.h)
    DiscordLink.hoverAnim := AnimateHoverValue(DiscordLink.hoverAnim, DiscordLink.hover, 9.0)
    if DiscordLink.copied && A_TickCount > DiscordLink.copiedUntil
        DiscordLink.copied := false
}

ApplyPresetSelectRow(row, direction) {
    global State, Presets, ProfilesUI, GlobalSettings
    row.value := CycleSelectValue(row.options, row.value, direction)
    if row.key = "character" {
        FinishAllSettingsEdit()
        SaveCurrentProfile()
        for _, p in Presets
            p.selected := false
        if Presets.Has(row.value)
            Presets[row.value].selected := true
        State.class := row.value
        GlobalSettings.CurrentPreset := row.value
        SaveSettings()
        LoadCurrentProfile()
        LoadCurrentLoadoutsUI()
    } else if row.key = "swapMode" {
        FinishAllSettingsEdit()
        SaveCurrentProfile()
        for _, p in ProfilesUI
            p.selected := false
        if ProfilesUI.Has(row.value)
            ProfilesUI[row.value].selected := true
        State.profile := row.value
        LoadCurrentProfile()
        LoadCurrentLoadoutsUI()
    }
}

CanUseControlSwitch() {
    global UI
    now := A_TickCount
    if (now - (UI.HasOwnProp("lastControlSwitch") ? UI.lastControlSwitch : 0) < 100)
        return false
    UI.lastControlSwitch := now
    return true
}

IsLoadoutDelayRowDisabled(row) {
    global GlobalSettings
    return row.key = "GlobalLoadoutDelay" && GlobalSettings.GlobalAdvancedDelay
}

GetSixteenLoadoutYOffset() {
    global LoadoutPositions
    ys := []
    seen := Map()
    for _, pos in LoadoutPositions {
        if !seen.Has(pos.y) {
            seen[pos.y] := true
            ys.Push(pos.y)
        }
    }
    if ys.Length < 2
        return 0
    totalGap := 0
    Loop ys.Length - 1
        totalGap += ys[A_Index + 1] - ys[A_Index]
    return (totalGap / (ys.Length - 1)) / 2
}

GetLoadoutTestCoord(pos) {
    if pos.HasOwnProp("test")
        return pos.test
    if pos.HasOwnProp("Test")
        return pos.Test
    return 0
}

GetActiveLoadoutPositions() {
    global LoadoutPositions, GlobalSettings
    if !GlobalSettings.SixteenLoadoutsOnly
        return LoadoutPositions
    yOffset := GetSixteenLoadoutYOffset()
    result := []
    Loop 16 {
        pos := LoadoutPositions[A_Index]
        result.Push({ x: pos.x, y: pos.y + yOffset, test: GetLoadoutTestCoord(pos) })
    }
    return result
}

GetLoadoutSlotCount() {
    global GlobalSettings
    return GlobalSettings.SixteenLoadoutsOnly ? 16 : 20
}

CancelLoadoutDelayEditing() {
    global GlobalSettingsRows
    for _, row in GlobalSettingsRows {
        if row.key = "GlobalLoadoutDelay" {
            row.editing := false
            row.editValue := ""
        }
    }
}

ApplyGlobalToggleRow(row) {
    global GlobalSettingsRows, Profiles, Overlay
    if row.key = "GlobalAdvancedDelay" && row.value
        CancelLoadoutDelayEditing()
    if row.key = "SixteenLoadoutsOnly" && row.value {
        for className, classProfiles in Profiles {
            for profileName, profile in classProfiles {
                filtered := []
                for _, id in profile.selectedLoadouts {
                    if id <= 16
                        filtered.Push(id)
                }
                profile.selectedLoadouts := filtered
            }
        }
        if Overlay.visible {
            BuildLoadoutSlots()
            LoadCurrentLoadoutsUI()
        }
    }
    SaveGlobalSettingRow(row)
}

ApplySettingToggle(setting) {
    SaveCurrentProfile()
    SaveSettings()
}

ApplyGlobalSelectRow(row, direction) {
    global GlobalSettings
    row.value := CycleSelectValue(row.options, row.value, direction)
    GlobalSettings.%row.key% := row.value
    SaveSettings()
}

HandleRowClick(row, part) {
    global GlobalSettings, Overlay
    if (row.type = "toggle" || row.type = "select") {
        if !CanUseControlSwitch()
            return
    }
    switch row.type {
        case "toggle":
            if part = "left" || part = "right" {
                row.value := !row.value
                ApplyGlobalToggleRow(row)
            }
        case "select":
            if part = "left"
                direction := -1
            else if part = "right"
                direction := 1
            else
                return
            if row.HasOwnProp("section") && row.section = "presets"
                ApplyPresetSelectRow(row, direction)
            else
                ApplyGlobalSelectRow(row, direction)
        case "bind":
            if part = "box" {
                FinishAllSettingsEdit()
                row.listening := true
                row.oldValue := row.value
                if row.key = "OpenMenuHotkey"
                    SetHotkeyCapture(true)
            }
        case "number":
            if part = "box" {
                if IsLoadoutDelayRowDisabled(row)
                    return
                FinishAllSettingsEdit()
                row.editing := true
                row.editValue := "" row.value
            }
        case "button":
            if part = "box" {
                CenterLoadoutOverlay()
                Overlay.visible := true
                Overlay.gearPanel.gearMenuOpen := false
                ClearHoverStates()
                BuildLoadoutSlots()
                LoadCurrentLoadoutsUI()
            }
    }
}

HandleSettingClick(setting, part) {
    global Overlay
    if setting.editing
        return
    if (setting.type = "toggle" || setting.type = "select") {
        if !CanUseControlSwitch()
            return
    }
    FinishAllSettingsEdit()
    switch setting.type {
        case "bind":
            if part = "box" {
                setting.listening := true
                setting.oldValue := setting.value
            }
        case "toggle":
            if part = "left" || part = "right" {
                setting.value := !setting.value
                ApplySettingToggle(setting)
            }
        case "number":
            if part = "box" {
                setting.editing := true
                setting.editValue := "" setting.value
            }
        case "button":
            if part = "box" {
                CenterLoadoutOverlay()
                Overlay.visible := true
                Overlay.gearPanel.gearMenuOpen := false
                ClearHoverStates()
                BuildLoadoutSlots()
                LoadCurrentLoadoutsUI()
            }
    }
}

RefreshGlobalSettingsRows() {
    global GlobalSettingsRows, GlobalSettings
    if !GlobalSettingsRows.Length {
        InitGlobalSettingsRows()
        return
    }
    for _, row in GlobalSettingsRows {
        if GlobalSettings.HasOwnProp(row.key)
            row.value := GlobalSettings.%row.key%
    }
}

FinishSettingEdit(setting) {
    if !setting.editing
        return
    if RegExMatch(setting.editValue, "^\d{1,4}$") {
        value := Integer(setting.editValue)
        if value >= setting.min && value <= setting.max {
            setting.value := value
            SaveCurrentProfile()
            SaveSettings()
        }
    }
    setting.editing := false
    setting.editValue := ""
}

UpdateModifierPreview(setting) {
    global HotkeyState
    result := ""
    if HotkeyState.ctrl
        result .= "Ctrl + "
    if HotkeyState.alt
        result .= "Alt + "
    if HotkeyState.shift
        result .= "Shift + "
    setting.value := result
}

BuildSettings() {
    global Settings, SettingLayout
    Settings := []
    for _, info in SettingLayout {
        Settings.Push({
            key: info.key,
            text: info.text,
            type: info.type,
            value: (info.type = "toggle" ? false : info.type = "number" ? 0 : info.type = "bind" ? "None" : ""),
            min: info.HasOwnProp("min") ? info.min : 0,
            max: info.HasOwnProp("max") ? info.max : 999,
            editing: false,
            editValue: "",
            listening: false,
            oldValue: "",
            y: 0,
            hoverLeft: false,
            hoverRight: false,
            hoverBox: false
        })
    }
}

ClearHoverStates() {
    global Buttons, Presets, ProfilesUI, Settings, Panels, GlobalSettingsRows, PresetRows
    for _, button in Buttons {
        button.hover := false
        button.hoverAnim := 0
    }
    for _, preset in Presets {
        preset.hover := false
        preset.hoverAnim := 0
    }
    for _, profile in ProfilesUI {
        profile.hover := false
        profile.hoverAnim := 0
    }
    for _, setting in Settings {
        setting.hoverLeft := false
        setting.hoverRight := false
        setting.hoverBox := false
    }
    for _, row in GlobalSettingsRows {
        row.hoverLeft := false
        row.hoverRight := false
        row.hoverBox := false
    }
    for _, row in PresetRows {
        row.hoverLeft := false
        row.hoverRight := false
        row.hoverBox := false
    }
    for _, panel in Panels {
        panel.hover := false
        panel.hoverAnim := 0
    }
}

BuildLoadoutSlots() {
    global LoadoutSlots, Overlay, GlobalSettings
    CenterLoadoutOverlay()
    LoadoutSlots := Map()
    size := 42
    gap := 15
    rowGap := size + gap
    startX := Overlay.x + 25
    startY := Overlay.y + 15
    yOffset := GlobalSettings.SixteenLoadoutsOnly ? rowGap / 2 : 0
    slotCount := GetLoadoutSlotCount()
    Loop slotCount {
        index := A_Index
        col := Mod(index - 1, 4)
        row := Floor((index - 1) / 4)
        LoadoutSlots[index] := {
            id: index,
            x: startX + col * (size + gap + 12),
            y: startY + row * rowGap + yOffset,
            w: size,
            h: size,
            selected: false,
            selectedAnim: 0,
            hover: false,
            hoverAnim: 0
        }
    }
}

CreateGlobalSettings() {
    global SettingsSchema
    settings := {}
    for key, schema in SettingsSchema.OwnProps() {
        if !schema.HasOwnProp("scope")
            continue
        if schema.scope != "global"
            continue
        if Type(schema.default) = "Array" {
            settings.%key% := []
        } else {
            settings.%key% := schema.default
        }
    }
    return settings
}

CreateSwapHotkeys() {
    global SettingsSchema
    hotkeys := Map()
    defaultValue := "None"
    for key, schema in SettingsSchema.OwnProps() {
        if schema.scope = "swaphotkeys" {
            defaultValue := schema.default
            break
        }
    }
    for _, profileName in ["3074", "27k", "noport"]
        hotkeys[profileName] := defaultValue
    return hotkeys
}

CreateProfile() {
    global SettingsSchema
    profile := {}
    for key, data in SettingsSchema.OwnProps() {
        if data.scope != "profile"
            continue
        if Type(data.default) = "Array" {
            profile.%key% := []
        } else {
            profile.%key% := data.default
        }
    }
    return profile
}

UpdateHoverState() {
    global UI, Settings, Buttons, Presets, ProfilesUI, hwnd
    MouseGetPos(&mx, &my, &win)
    if win != hwnd {
        for _, button in Buttons
            button.hover := false
        for _, setting in Settings
            setting.hover := false
        for _, preset in Presets
            preset.hover := false
        for _, profile in ProfilesUI
            profile.hover := false
        return
    }
}

CheckFirstRun() {
    RegisterOpenMenuHotkey()
}

RegisterOpenMenuHotkey() {
    global GlobalSettings, RegisteredOpenMenuHotkey
    UnregisterOpenMenuHotkey()
    rawKey := Trim(GlobalSettings.OpenMenuHotkey)
    if (rawKey = "" || rawKey = "None")
        return
    openKey := NormalizeHotkeyString(rawKey, false)
    openKey := RegExReplace(openKey, "[^\x20-\x7E]", "")
    if (openKey = "")
        return
    key := "~*" openKey
    success := Hotkey(key, ToggleMenuGUI, "On")
    if (success)
        RegisteredOpenMenuHotkey := key
}

ToggleMenuGUI(*) {
    OpenMenuGUI()
}

IsNamedHotkeyKey(key) {
    static named := Map(
        "AppsKey", 1, "Space", 1, "Tab", 1, "Enter", 1, "Return", 1, "Escape", 1, "Esc", 1,
        "Delete", 1, "Del", 1, "Backspace", 1, "BS", 1, "Home", 1, "End", 1, "PgUp", 1, "PageUp", 1,
        "PgDn", 1, "PageDown", 1, "Left", 1, "Right", 1, "Up", 1, "Down", 1, "Insert", 1, "Ins", 1,
        "PrintScreen", 1, "ScrollLock", 1, "Pause", 1, "Break", 1, "CapsLock", 1, "NumLock", 1,
        "LButton", 1, "RButton", 1, "MButton", 1, "XButton1", 1, "XButton2", 1, "NumpadEnter", 1,
        "NumpadDot", 1, "NumpadMult", 1, "NumpadDiv", 1, "NumpadAdd", 1, "NumpadSub", 1,
        ";", 1, "=", 1, ",", 1, "-", 1, ".", 1, "/", 1, "[", 1, "\\", 1, "]", 1, "'", 1, "``", 1
    )
    return named.Has(key) || RegExMatch(key, "^Numpad\d$")
}

NormalizeHotkeyString(text, addTildeStar := false) {
    text := Trim(text)
    if (text = "" || text = "None")
        return ""
    text := RegExReplace(text, "\s*\+\s*", "+")
    text := RegExReplace(text, "^\+|\+$", "")
    text := RegExReplace(text, "\++", "+")
    parts := StrSplit(text, "+")
    modifiers := ""
    key := ""
    for _, part in parts {
        part := NormalizeKeyName(Trim(part))
        if (part = "")
            continue
        switch part {
            case "Ctrl", "LCtrl", "RCtrl":
                modifiers .= "^"
            case "Alt", "LAlt", "RAlt":
                modifiers .= "!"
            case "Shift", "LShift", "RShift":
                modifiers .= "+"
            case "Win", "LWin", "RWin":
                modifiers .= "#"
            default:
                if IsNamedHotkeyKey(part) {
                    key := part
                } else if (key = "") {
                    key := part
                }
        }
    }
    if (key = "")
        return ""
    key := NormalizeKeyName(key)
    if !IsNamedHotkeyKey(key) && !RegExMatch(key, "^F\d+$")
        key := StrUpper(key)
    result := modifiers . key
    if (addTildeStar && !RegExMatch(result, "^(~|\*)"))
        result := "~*" . result
    return result
}

Render() {
    global
    if !UI.visible
        return
    UI.frameDelta := GetRenderDelta()
    UpdateHoverState()
    UpdateCategoryFade()
    if UI.fade {
        UI.alpha += (UI.targetAlpha - UI.alpha) * 0.7
        if UI.closing {
            if UI.alpha <= 3 {
                UI.alpha := 0
                UI.fade := false
                UI.visible := false
                UI.closing := false
                MainGui.Hide()
                SetTimer(Render, 0)
                return
            }
        } else {
            if UI.alpha >= 252 {
                UI.alpha := 255
                UI.fade := false
            }
        }
    }
    if UI.dragging
        return
    if !WinActive("ahk_id " hwnd)
        return
    UI.time += 0.008
    Draw()
    newHbm := Gdip_CreateHBITMAPFromBitmap(Bitmap)
    oldHbm := SelectObject(hdc, newHbm)
    if oldHbm
        DllCall("DeleteObject", "ptr", oldHbm)
    hbm := newHbm
    UpdateLayeredWindow(hwnd, hdc, , , WIDTH, HEIGHT, UI.alpha)
}

DrawHoverFrame(x, y, w, h, a) {
    global G
    offset := 7 - (a * 3)
    alpha := Round(255 * (a ** 2))
    if alpha <= 0
        return
    color := 0xFFFFFF
    pen := Gdip_CreatePen((alpha << 24) | color, 1)
    Gdip_DrawRectangle(G, pen, x - offset, y - offset, w + (offset * 2), h + (offset * 2))
    Gdip_DeletePen(pen)
}

DrawSideButton(button) {
    global G, State
    x := button.x
    y := button.y
    w := button.w
    h := button.h
    button.hoverAnim := AnimateHoverValue(button.hoverAnim, button.hover, 9.0)
    isActive := false
    if (button.text = "SETTINGS" && State.currentCategory = "settings")
        isActive := true
    else if (button.text = "PRESETS" && State.currentCategory = "presets")
        isActive := true
    else if (button.text = "SAVE" && State.currentCategory = "save")
        isActive := true
    else if (button.text = "EXIT" && State.currentCategory = "exit")
        isActive := true
    if isActive
        bgColor := 0x26B5B2B5
    else
        bgColor := 0x266A656A
    brush := Gdip_BrushCreateSolid(bgColor)
    Gdip_FillRectangle(G, brush, x, y, w, h)
    Gdip_DeleteBrush(brush)
    pen := Gdip_CreatePen(0xFFB0B0B0, button.hover ? 2 : 1)
    Gdip_DrawRectangle(G, pen, x, y, w, h)
    Gdip_DeletePen(pen)
    hoverVisual := SmoothStep(button.hoverAnim)
    if hoverVisual > 0.01
        DrawHoverFrame(x, y, w, h, hoverVisual)
    Gdip_TextToGraphics(G, button.text, "x" x " y" y + 14 " w" w " h25 Center s14 Bold cFFFFFFFF")
}

DrawSettingHoverFrame(x, y, w, h, a) {
    global G
    offset := 7 - (a * 3)
    alpha := Round(255 * (a ** 2))
    if alpha <= 0
        return
    pen := Gdip_CreatePen((alpha << 24) | 0xFFFFFF, 1)
    Gdip_DrawRectangle(G, pen, x - offset, y - offset, w + (offset * 2), h + (offset * 2))
    Gdip_DeletePen(pen)
}

DrawPresetHoverFrame(x, y, size, a) {
    global G
    offset := 8 - (a * 3)
    alpha := Round(255 * (a ** 2))
    color := (alpha << 24) | 0xFFFFFF
    pen := Gdip_CreatePen(color, 1)
    Gdip_DrawLine(G, pen, x + size / 2, y - offset, x + size + offset, y + size / 2)
    Gdip_DrawLine(G, pen, x + size + offset, y + size / 2, x + size / 2, y + size + offset)
    Gdip_DrawLine(G, pen, x + size / 2, y + size + offset, x - offset, y + size / 2)
    Gdip_DrawLine(G, pen, x - offset, y + size / 2, x + size / 2, y - offset)
    Gdip_DeletePen(pen)
}

DrawBackground() {
    global
    bg := Gdip_CreateLineBrush(0, 0, WIDTH, HEIGHT, 0xFF70676C, 0xFF444952, 1)
    Gdip_FillRectangle(G, bg, 0, 0, WIDTH, HEIGHT)
    Gdip_DeleteBrush(bg)
    cx := WIDTH / 2 + Sin(UI.time * 0.08) * 18
    cy := HEIGHT / 2 + Cos(UI.time * 0.06) * 14
    DrawSoftCircle(cx, cy, 700, 10)
    DrawSoftCircle(cx - 80, cy + 40, 500, 7)
}

DrawSoftCircle(x, y, size, alpha) {
    global G
    Loop 12 {
        i := A_Index
        currentSize := size + i * 45
        currentAlpha := alpha - i * 0.8
        if currentAlpha <= 0
            continue
        color := (Round(currentAlpha) << 24) | 0x7998B6
        brush := Gdip_BrushCreateSolid(color)
        Gdip_FillEllipse(G, brush, x - currentSize / 2, y - currentSize / 2, currentSize, currentSize)
        Gdip_DeleteBrush(brush)
    }
}

DrawExitConfirmation() {
    global G, ExitOverlay, WIDTH, HEIGHT
    dark := Gdip_BrushCreateSolid(0xD9000000)
    Gdip_FillRectangle(G, dark, 0, 0, WIDTH, HEIGHT)
    Gdip_DeleteBrush(dark)

    penLine := Gdip_CreatePen(0xFF4D8899, 4)
    Gdip_DrawLine(G, penLine, 0, 207, WIDTH, 207)
    Gdip_DeletePen(penLine)

    brush := Gdip_BrushCreateSolid(0x40000000)
    Gdip_FillRectangle(G, brush, 0, 209, 324, 107)
    Gdip_DeleteBrush(brush)

    brush := Gdip_BrushCreateSolid(0x4062838E)
    Gdip_FillRectangle(G, brush, 324, 209, 636, 45)
    Gdip_DeleteBrush(brush)

    Gdip_TextToGraphics(G, "ARE YOU SURE?", "x105 y219 w636 h45 Center s16 Bold cFFFFFFFF", "Century Gothic")
    Gdip_TextToGraphics(G, "Are you sure that you would like to quit your current session and return to the character select screen?", "x80 y268 w800 h50 Center s10 cFFFFFFFF", "Century Gothic")

    brush := Gdip_BrushCreateSolid(0x40808080)
    Gdip_FillRectangle(G, brush, 324, 254, 636, 62)
    Gdip_DeleteBrush(brush)

    brush := Gdip_BrushCreateSolid(0x1A000000)
    Gdip_FillRectangle(G, brush, 0, 316, WIDTH, 19)
    Gdip_DeleteBrush(brush)

    ExitOverlay.confirmButton.x := 337
    ExitOverlay.confirmButton.y := 318
    ExitOverlay.confirmButton.w := 64
    ExitOverlay.confirmButton.h := 20
    ExitOverlay.cancelButton.x := 402
    ExitOverlay.cancelButton.y := 318
    ExitOverlay.cancelButton.w := 64
    ExitOverlay.cancelButton.h := 20

    for _, btnName in ["confirmButton", "cancelButton"] {
        btn := ExitOverlay.%btnName%
        if btn.hover
            btn.hoverAnim += (1 - btn.hoverAnim) * 0.25
        else
            btn.hoverAnim += (0 - btn.hoverAnim) * 0.45
        text := (btnName = "confirmButton") ? "Confirm" : "Cancel"
        color := btn.hover ? "FFE0B85C" : "FFFFFFFF"
        Gdip_TextToGraphics(G, text, "x" btn.x " y" btn.y " w" btn.w " h" btn.h " Center s12 Bold c" color, "Arial")
    }
}

DrawAnimatedBorder() {
    global G
    pen := Gdip_CreatePen(0xFFE0B85C, 3)
    Gdip_DrawRectangle(G, pen, 0, 0, WIDTH-1, HEIGHT-1)
    Gdip_DeletePen(pen)
}

DrawEmblemText(text, options, font := "Century Gothic") {
    global G
    if Gdip_TextToGraphics(G, text, options, font) >= 0
        return
    Gdip_TextToGraphics(G, text, options, "Arial")
}

DrawTightHoverFrame(x, y, w, h, a) {
    global G
    alpha := Round(220 * SmoothStep(a))
    if alpha <= 0
        return
    pen := Gdip_CreatePen((alpha << 24) | 0xE0B85C, 1)
    Gdip_DrawRectangle(G, pen, x, y, w - 1, h - 1)
    Gdip_DeletePen(pen)
}

DrawDiscordLink() {
    global G, DiscordLink
    label := GetDiscordLinkLabel()
    UpdateDiscordLinkLayout(label)
    UpdateDiscordLinkHover()
    alpha := DiscordLink.hover ? 0xB3 : 0x66
    color := Format("{:02X}FFFFFF", alpha)
    hoverVisual := SmoothStep(DiscordLink.hoverAnim)
    if hoverVisual > 0.01
        DrawTightHoverFrame(DiscordLink.x, DiscordLink.y, DiscordLink.w, DiscordLink.h, hoverVisual)
    textW := DiscordLink.w - DiscordLink.textPadX
    textH := DiscordLink.h - DiscordLink.textPadY
    Gdip_TextToGraphics(G, label, "x" DiscordLink.x " y" (DiscordLink.y + DiscordLink.textPadY) " w" textW " h" textH " Right s" DiscordLink.fontSize " c" color, "Arial")
}

DrawGearPanel() {
    global G, Overlay, UI
    gp := Overlay.gearPanel
    x := gp.x
    y := gp.y
    w := gp.w
    h := gp.h
    btn := GetGearButtonRect()
    gp.gearHover := (UI.mouseX >= btn.x && UI.mouseX <= btn.x + btn.w && UI.mouseY >= btn.y && UI.mouseY <= btn.y + btn.h)
    gp.gearOptionHover := 0
    if gp.gearMenuOpen {
        menu := GetGearMenuRect()
        if UI.mouseX >= menu.x && UI.mouseX <= menu.x + menu.w && UI.mouseY >= menu.y && UI.mouseY <= menu.y + menu.h
            gp.gearOptionHover := Floor((UI.mouseY - menu.y) / menu.optH) + 1
    }
    if gp.gearHover
        gp.gearHoverAnim += (1 - gp.gearHoverAnim) * 0.45
    else
        gp.gearHoverAnim += (0 - gp.gearHoverAnim) * 0.45
    bg := Gdip_CreateLineBrush(x, y, x + w, y + h, 0xFF70676C, 0xFF444952, 1)
    Gdip_FillRectangle(G, bg, x, y, w, h)
    Gdip_DeleteBrush(bg)
    DrawSoftCircle(x + 80, y + 120, 180, 6)
    DrawOverlayFrame(x, y, w, h)
    helpText := "If using advanced delay feature choosing armor piece here will make macro scan choosed armor piece mid swap so macro knows when loadouts are actually being applied so macro can loadout swap more precisely without skipping any loadouts by fps drops."
    lineY := y + 18
    for _, line in WrapTextLines(helpText, 28) {
        Gdip_TextToGraphics(G, line, "x" (x + 12) " y" lineY " w" (w - 24) " h18 Left s14 cDDFFFFFF", "Arial")
        lineY += 16
    }
    currentGear := GetCurrentSelectedGear()
    bgColor := gp.gearHover ? 0x401E2028 : 0x30181822
    gearBg := Gdip_BrushCreateSolid(bgColor)
    Gdip_FillRectangle(G, gearBg, btn.x, btn.y, btn.w, btn.h)
    Gdip_DeleteBrush(gearBg)
    pen := Gdip_CreatePen(0xFFFFFFFF, gp.gearHover ? 2 : 1)
    Gdip_DrawRectangle(G, pen, btn.x, btn.y, btn.w, btn.h)
    Gdip_DeletePen(pen)
    Gdip_TextToGraphics(G, currentGear, "x" btn.x " y" (btn.y + 7) " w" btn.w " h28 s14 Bold cFFE8EDF5 Center", "Arial")
    Gdip_TextToGraphics(G, "▾", "x" (btn.x + btn.w - 18) " y" (btn.y + 9) " w16 h28 Center s16 cFFE8EDF5", "Arial")
    if gp.gearHoverAnim > 0.01
        DrawHoverFrame(btn.x, btn.y, btn.w, btn.h, gp.gearHoverAnim)
    if gp.gearMenuOpen {
        menu := GetGearMenuRect()
        bg2 := Gdip_CreateLineBrush(menu.x, menu.y, menu.x + menu.w, menu.y + menu.h, 0xFF70676C, 0xFF444952, 1)
        Gdip_FillRectangle(G, bg2, menu.x, menu.y, menu.w, menu.h)
        Gdip_DeleteBrush(bg2)
        pen2 := Gdip_CreatePen(0xFFFFFFFF, 1)
        Gdip_DrawRectangle(G, pen2, menu.x, menu.y, menu.w, menu.h)
        Gdip_DeletePen(pen2)
        sepPen := Gdip_CreatePen(0xFFFFFFFF, 1)
        for index, opt in gp.options {
            yopt := menu.y + (index - 1) * menu.optH
            textColor := index = gp.gearOptionHover ? "cFFE0B85C" : "cFFE8EDF5"
            Gdip_TextToGraphics(G, opt, "x" menu.x " y" (yopt + 7) " w" menu.w " h" menu.optH " s14 Bold " textColor " Center", "Arial")
            if index < gp.options.Length
                Gdip_DrawLine(G, sepPen, menu.x, yopt + menu.optH, menu.x + menu.w, yopt + menu.optH)
        }
        Gdip_DeletePen(sepPen)
    }
}

DrawMadeByText() {
    global G, EmblemUsername, EmblemAppName
    brush := Gdip_BrushCreateSolid(0xFFFFFFFF)
    Gdip_FillRectangle(G, brush, 97, 9, 6, 2)
    Gdip_DeleteBrush(brush)
    DrawEmblemText(EmblemUsername, "x96 y14 w200 h25 Left s16 Bold cCCFFFFFF")
    appFontSize := StrLen(EmblemAppName) > 18 ? 9 : 12
    DrawEmblemText(EmblemAppName, "x96 y31 w300 h10 Left s" appFontSize " c99FFFFFF")
}

Draw() {
    global
    Gdip_GraphicsClear(G, 0x00000000)
    DrawBackground()
    DrawTopBar()
    DrawEmblemIcon()
    DrawMadeByText()

    fadeHeightTop := 95
    fadeHeightBot := 200
    brushTop := Gdip_CreateLineBrush(1, 49, 1, 49 + fadeHeightTop, 0x00000000, 0x66000000, 1)
    Gdip_FillRectangle(G, brushTop, 1, 49, 242, fadeHeightTop)
    Gdip_DeleteBrush(brushTop)
    brushMid := Gdip_BrushCreateSolid(0x66000000)
    Gdip_FillRectangle(G, brushMid, 1, 49 + fadeHeightTop, 242, 461 - fadeHeightTop - fadeHeightBot)
    Gdip_DeleteBrush(brushMid)
    brushBot := Gdip_CreateLineBrush(1, 49 + 461 - fadeHeightBot, 1, 49 + 461, 0x66000000, 0x00000000, 1)
    Gdip_FillRectangle(G, brushBot, 1, 49 + 461 - fadeHeightBot, 242, fadeHeightBot)
    Gdip_DeleteBrush(brushBot)

    brush := Gdip_BrushCreateSolid(0x40000000)
    Gdip_FillRectangle(G, brush, 0, BOTTOM_BAR_Y, WIDTH, BOTTOM_BAR_H)
    Gdip_DeleteBrush(brush)

    DrawAnimatedBorder()

    if UI.contentAlpha > 0.001 {
        if (State.currentCategory == "presets") {
            DrawPresetsView(UI.contentAlpha)
        } else if (State.currentCategory == "settings") {
            DrawSettingsGlobal(UI.contentAlpha)
        }
    }

    DrawButtons()

    DrawDiscordLink()

    if ExitOverlay.visible {
        DrawExitConfirmation()
    }

    if Overlay.visible {
        DrawLoadoutOverlay()
    }
}

DrawSettingsSectionHeader(label, iconChar, y, contentAlpha := 1.0) {
    global G
    iconY := y + 2
    brush := Gdip_BrushCreateSolid(ApplyRowAlpha(0xFF888888, contentAlpha))
    Gdip_FillRectangle(G, brush, 266, iconY, 15, 15)
    Gdip_DeleteBrush(brush)
    textAlpha := Round(255 * contentAlpha)
    Gdip_TextToGraphics(G, iconChar, "x266 y" (iconY - 2) " w15 h15 Center s12 Bold c" Format("{:02X}", textAlpha) "FFFFFF", "Arial")
    Gdip_TextToGraphics(G, label, "x285 y" (y + 4) " w400 h14 Left s9 Bold c" Format("{:02X}", textAlpha) "FFFFFF", "Arial")
    pen := Gdip_CreatePen(ApplyRowAlpha(0xFF9B9598, contentAlpha), 1)
    Gdip_DrawLine(G, pen, 284, y + 17, 901, y + 17)
    Gdip_DeletePen(pen)
}

FormatBindDisplay(value) {
    if (value = "" || value = "None")
        return "Set Binding"
    return value
}

GetRowDisplay(row) {
    global UI
    switch row.type {
        case "toggle":
            return row.value ? "ON" : "OFF"
        case "select":
            return GetSelectDisplay(row)
        case "bind":
            return FormatBindDisplay(row.value)
        case "number":
            if row.editing {
                cursor := Mod(Floor(UI.time * 4), 2) ? "|" : ""
                return String(row.editValue . cursor)
            }
            return String(row.value)
        case "button":
            return "Select"
    }
    return ""
}

GetSettingDisplay(setting) {
    global UI
    switch setting.type {
        case "toggle":
            return setting.value ? "ON" : "OFF"
        case "bind":
            return FormatBindDisplay(setting.value)
        case "number":
            if setting.editing {
                cursor := Mod(Floor(UI.time * 4), 2) ? "|" : ""
                return String(setting.editValue . cursor)
            }
            return String(setting.value)
        case "button":
            return "Select"
    }
    return ""
}

DrawSettingRow(text, y, display, controlType, active := false, contentAlpha := 1.0, row := "", disabled := false) {
    global G, SETTINGS_ROW_X, SETTINGS_ROW_W, SETTINGS_ROW_H, SETTINGS_SEL_X, SETTINGS_SEL_W, SETTINGS_ARROW_W
    x := SETTINGS_ROW_X
    w := SETTINGS_ROW_W
    h := SETTINGS_ROW_H
    selX := SETTINGS_SEL_X
    selW := SETTINGS_SEL_W
    if row != "" {
        row.y := y
        SetupRowHits(row, controlType)
        if disabled
            row.hitBox := false
    }
    brush := Gdip_BrushCreateSolid(ApplyRowAlpha(0x80514C4F, contentAlpha))
    Gdip_FillRectangle(G, brush, x, y, w, h)
    Gdip_DeleteBrush(brush)
    textAlpha := Round(255 * contentAlpha)
    Gdip_TextToGraphics(G, text, "x" (x+10) " y" (y+4) " w300 h20 Left s12 Bold c" Format("{:02X}", textAlpha) "FFFFFF", "Arial")
    selColor := disabled ? 0xFF3A3538 : (active ? 0xFF4A5E78 : 0xFF605B61)
    if controlType = "button"
        selColor := disabled ? 0xFF3A3538 : 0xFF4D9C5D
    if row != "" && !disabled {
        if row.hoverLeft || row.hoverRight || row.hoverBox
            selColor := active ? 0xFF5A7494 : 0xFF706A72
        if controlType = "button" && row.hoverBox
            selColor := 0xFF5CB06D
    }
    brush := Gdip_BrushCreateSolid(ApplyRowAlpha(selColor, contentAlpha))
    Gdip_FillRectangle(G, brush, selX, y, selW, h)
    Gdip_DeleteBrush(brush)
    penColor := disabled ? 0xFF5A5558 : (active ? 0xFFFFFFFF : 0xFF817D82)
    pen := Gdip_CreatePen(ApplyRowAlpha(penColor, contentAlpha), active && !disabled ? 2 : 1)
    Gdip_DrawRectangle(G, pen, selX, y, selW, h)
    Gdip_DeletePen(pen)
    valueColor := disabled ? ("c" Format("{:02X}", Round(120 * contentAlpha)) "8A8A8A") : ((controlType = "bind" && display = "Set Binding") ? ("c" Format("{:02X}", Round(170 * contentAlpha)) "AAAAAA") : ("c" Format("{:02X}", textAlpha) "FFFFFF"))
    fontSize := 11
    if StrLen(display) > 14
        fontSize := 10
    if StrLen(display) > 18
        fontSize := 9
    showArrows := (controlType = "toggle" || controlType = "select")
    if showArrows {
        leftColor := (row != "" && row.hoverLeft) ? ("c" Format("{:02X}", textAlpha) "E0B85C") : ("c" Format("{:02X}", textAlpha) "FFFFFF")
        rightColor := (row != "" && row.hoverRight) ? ("c" Format("{:02X}", textAlpha) "E0B85C") : ("c" Format("{:02X}", textAlpha) "FFFFFF")
        Gdip_TextToGraphics(G, "◀", "x" selX " y" (y+2) " w" SETTINGS_ARROW_W " h20 Center s14 Bold " leftColor, "Arial")
        Gdip_TextToGraphics(G, "▶", "x" (selX + selW - SETTINGS_ARROW_W) " y" (y+2) " w" SETTINGS_ARROW_W " h20 Center s14 Bold " rightColor, "Arial")
        textW := selW - SETTINGS_ARROW_W * 2
        Gdip_TextToGraphics(G, display, "x" (selX + SETTINGS_ARROW_W) " y" (y+4) " w" textW " h20 Center s" fontSize " Bold " valueColor, "Arial")
    } else {
        Gdip_TextToGraphics(G, display, "x" selX " y" (y+4) " w" selW " h20 Center s" fontSize " Bold " valueColor, "Arial")
    }
}

DrawSettingsGlobal(contentAlpha := 1.0) {
    global GlobalSettingsRows, SETTINGS_ROW_H, SETTINGS_ROW_GAP
    InitGlobalSettingsRows()
    RefreshGlobalSettingsRows()
    DrawSettingsSectionHeader("G  L  O  B  A  L", "G", 91, contentAlpha)
    rowY := 114
    for _, row in GlobalSettingsRows {
        if row.section != "global"
            continue
        display := GetRowDisplay(row)
        active := (row.listening || row.editing) && !IsLoadoutDelayRowDisabled(row)
        disabled := IsLoadoutDelayRowDisabled(row)
        DrawSettingRow(row.text, rowY, display, row.type, active, contentAlpha, row, disabled)
        rowY += SETTINGS_ROW_H + SETTINGS_ROW_GAP
    }
    rowY += 12
    DrawSettingsSectionHeader("B  I  N  D  S", "B", rowY, contentAlpha)
    rowY += 23
    for _, row in GlobalSettingsRows {
        if row.section != "binds"
            continue
        display := GetRowDisplay(row)
        active := (row.listening || row.editing) && !IsLoadoutDelayRowDisabled(row)
        disabled := IsLoadoutDelayRowDisabled(row)
        DrawSettingRow(row.text, rowY, display, row.type, active, contentAlpha, row, disabled)
        rowY += SETTINGS_ROW_H + SETTINGS_ROW_GAP
    }
}

DrawPresetsView(contentAlpha := 1.0) {
    global PresetRows, Settings, SETTINGS_ROW_H, SETTINGS_ROW_GAP
    InitPresetRows()
    SyncPresetRowsFromState()
    DrawSettingsSectionHeader("P  R  E  S  E  T  S", "P", 91, contentAlpha)
    rowY := 114
    for _, row in PresetRows {
        display := GetRowDisplay(row)
        DrawSettingRow(row.text, rowY, display, row.type, false, contentAlpha, row)
        rowY += SETTINGS_ROW_H + SETTINGS_ROW_GAP
    }
    rowY += 12
    DrawSettingsSectionHeader("S  E  T  U  P", "S", rowY, contentAlpha)
    rowY += 23
    for _, setting in Settings {
        setting.y := rowY
        SetupRowHits(setting, setting.type)
        display := GetSettingDisplay(setting)
        active := setting.listening || setting.editing
        DrawSettingRow(setting.text, rowY, display, setting.type, active, contentAlpha, setting)
        rowY += SETTINGS_ROW_H + SETTINGS_ROW_GAP
    }
}

DrawLoadoutOverlay() {
    global G, Overlay, UI, WIDTH, HEIGHT
    dark := Gdip_BrushCreateSolid(0xAA000000)
    Gdip_FillRectangle(G, dark, 0, 0, WIDTH, HEIGHT)
    Gdip_DeleteBrush(dark)
    DrawGearPanel()
    x := Overlay.x
    y := Overlay.y
    bg := Gdip_CreateLineBrush(x, y, x + Overlay.w, y + Overlay.h, 0xFF70676C, 0xFF444952, 1)
    Gdip_FillRectangle(G, bg, x, y, Overlay.w, Overlay.h)
    Gdip_DeleteBrush(bg)
    DrawSoftCircle(x + 150, y + 150, 350, 8)
    DrawOverlayFrame(x, y, Overlay.w, Overlay.h)
    for _, slot in LoadoutSlots {
        slot.hover := (UI.mouseX > slot.x && UI.mouseX < slot.x + slot.w && UI.mouseY > slot.y && UI.mouseY < slot.y + slot.h)
    }
    btn := Overlay.saveButton
    btn.hover := (UI.mouseX > btn.x && UI.mouseX < btn.x + btn.w && UI.mouseY > btn.y && UI.mouseY < btn.y + btn.h)
    DrawLoadoutSlots()
    Overlay.saveButton.w := 120
    Overlay.saveButton.h := 34
    Overlay.saveButton.x := x + Overlay.w - Overlay.saveButton.w - 20
    Overlay.saveButton.y := y + Overlay.h - Overlay.saveButton.h - 16
    DrawButton(Overlay.saveButton)
}

DrawLoadoutSlots() {
    global G, LoadoutSlots
    for _, slot in LoadoutSlots {
        x := slot.x
        y := slot.y
        if slot.hover
            slot.hoverAnim += (1 - slot.hoverAnim) * 0.45
        else
            slot.hoverAnim += (0 - slot.hoverAnim) * 0.45
        if slot.selected
            slot.selectedAnim += (1 - slot.selectedAnim) * 0.2
        else
            slot.selectedAnim += (0 - slot.selectedAnim) * 0.2
        if slot.selected {
            bgColor := 0x553B6FA8
        } else {
            bgColor := 0x35182030
        }
        brush := Gdip_BrushCreateSolid(bgColor)
        Gdip_FillRectangle(G, brush, x, y, slot.w, slot.h)
        Gdip_DeleteBrush(brush)
        borderColor := slot.selected ? 0xFFE0B85C : 0xFFD7DDE8
        borderSize := slot.selected || slot.hover ? 2 : 1
        pen := Gdip_CreatePen(borderColor, borderSize)
        Gdip_DrawRectangle(G, pen, x, y, slot.w, slot.h)
        Gdip_DeletePen(pen)
        if slot.hoverAnim > 0.01 {
            DrawSettingHoverFrame(x, y, slot.w, slot.h, slot.hoverAnim)
        }
        Gdip_TextToGraphics(G, String(slot.id), "x" x " y" y + 13 " w" slot.w " h25 Center s16 Bold cFFFFFFFF")
    }
}

DrawOverlayFrame(x, y, w, h) {
    global G
    pen := Gdip_CreatePen(0xFFE0B85C, 3)
    Gdip_DrawRectangle(G, pen, x, y, w, h)
    Gdip_DeletePen(pen)
    inner := Gdip_CreatePen(0xFFF0D58A, 1)
    Gdip_DrawRectangle(G, inner, x + 3, y + 3, w - 6, h - 6)
    Gdip_DeletePen(inner)
}

DrawPanels() {
    global Panels
    for _, panel in Panels {
        DrawPanel(panel)
    }
}

DrawPanel(panel) {
    global G, UI
    x := Round(panel.x)
    y := Round(panel.y)
    w := panel.w
    h := panel.h
    brush := Gdip_BrushCreateSolid(0x00101822)
    Gdip_FillRectangle(G, brush, x, y, w, h)
    Gdip_DeleteBrush(brush)
    DrawPanelFrame(x, y, w, h)
}

DrawPanelFrame(x, y, w, h) {
    Gdip_SetSmoothingMode(G, 3)
    corner := 1
    DrawFadeLine(x + corner, y, w - corner * 2, "H")
    DrawFadeLine(x + corner, y + h, w - corner * 2, "H")
    Gdip_SetSmoothingMode(G, 4)
}

DrawFadeLine(x, y, length, mode) {
    global G
    fade := Round(length * 0.25)
    solid := length - fade * 2
    if mode = "H" {
        brush1 := Gdip_CreateLineBrush(x, y, x + fade, y, 0x00999EA6, 0x55999EA6, 1)
        pen1 := Gdip_CreatePenFromBrush(brush1, 1)
        Gdip_DrawLine(G, pen1, x, y, x + fade, y)
        Gdip_DeletePen(pen1)
        Gdip_DeleteBrush(brush1)
        pen := Gdip_CreatePen(0x55999EA6, 1)
        Gdip_DrawLine(G, pen, x + fade, y, x + fade + solid, y)
        Gdip_DeletePen(pen)
        brush2 := Gdip_CreateLineBrush(x + fade + solid, y, x + length, y, 0x55999EA6, 0x00999EA6, 1)
        pen2 := Gdip_CreatePenFromBrush(brush2, 1)
        Gdip_DrawLine(G, pen2, x + fade + solid, y, x + length, y)
        Gdip_DeletePen(pen2)
        Gdip_DeleteBrush(brush2)
    } else {
        brush1 := Gdip_CreateLineBrush(x, y, x, y + fade, 0x00999EA6, 0x55999EA6, 1)
        pen1 := Gdip_CreatePenFromBrush(brush1, 1)
        Gdip_DrawLine(G, pen1, x, y, x, y + fade)
        Gdip_DeletePen(pen1)
        Gdip_DeleteBrush(brush1)
        pen := Gdip_CreatePen(0x55999EA6, 1)
        Gdip_DrawLine(G, pen, x, y + fade, x, y + fade + solid)
        Gdip_DeletePen(pen)
        brush2 := Gdip_CreateLineBrush(x, y + fade + solid, x, y + length, 0x55999EA6, 0x00999EA6, 1)
        pen2 := Gdip_CreatePenFromBrush(brush2, 1)
        Gdip_DrawLine(G, pen2, x, y + fade + solid, x, y + length)
        Gdip_DeletePen(pen2)
        Gdip_DeleteBrush(brush2)
    }
}

DrawHotkeySetting(setting) {
    global G
    x := setting.x
    y := setting.y
    if setting.hover {
        setting.hoverAnim += (1 - setting.hoverAnim) * 0.25
    } else {
        setting.hoverAnim += (0 - setting.hoverAnim) * 0.45
    }
    if setting.labelPosition = "top" {
        Gdip_TextToGraphics(G, setting.text, "x" x " y" y - 20 " w" setting.w " h25 Center s14 Bold cFFE8EDF5")
    } else {
        Gdip_TextToGraphics(G, setting.text, "x" x - 120 " y" y + 13 " w400 h25 s14 Bold cFFE8EDF5")
    }
    if setting.listening {
        setting.activeAnim += (1 - setting.activeAnim) * 0.15
    } else {
        setting.activeAnim += (0 - setting.activeAnim) * 0.15
    }
    bgColor := (setting.listening ? 0x553B6FA8 : 0x35182030)
    bg := Gdip_BrushCreateSolid(bgColor)
    Gdip_FillRectangle(G, bg, x, y, setting.w, setting.h)
    Gdip_DeleteBrush(bg)
    pen := Gdip_CreatePen(setting.listening || setting.hover ? 0xFFFFFFFF : 0xFFD7DDE8, setting.listening || setting.hover ? 2 : 1)
    Gdip_DrawRectangle(G, pen, x, y, setting.w, setting.h)
    Gdip_DeletePen(pen)
    if setting.hoverAnim > 0.01 {
        DrawSettingHoverFrame(x, y, setting.w, setting.h, setting.hoverAnim)
    }
    display := setting.value
    fontSize := 16
    if StrLen(display) > 12
        fontSize := 14
    if StrLen(display) > 16
        fontSize := 12
    if StrLen(display) > 20
        fontSize := 10
    Gdip_TextToGraphics(G, display, "x" x " y" y + setting.ButtonTextY " w" setting.w " h35 Center s" fontSize " Bold cFFFFFFFF")
}

DrawLoadoutListSetting(setting) {
    global G
    x := setting.x
    y := setting.y
    if setting.hover
        setting.hoverAnim += (1 - setting.hoverAnim) * 0.25
    else
        setting.hoverAnim += (0 - setting.hoverAnim) * 0.45
    Gdip_TextToGraphics(G, setting.text, "x" x - 120 " y" y + 13 " w400 h25 s14 Bold cFFE8EDF5")
    bg := Gdip_BrushCreateSolid(0x35182030)
    Gdip_FillRectangle(G, bg, x, y, setting.w, setting.h)
    Gdip_DeleteBrush(bg)
    pen := Gdip_CreatePen(0xFFFFFFFF, setting.hover ? 2 : 1)
    Gdip_DrawRectangle(G, pen, x, y, setting.w, setting.h)
    Gdip_DeletePen(pen)
    if setting.hoverAnim > 0.01 {
        DrawSettingHoverFrame(x, y, setting.w, setting.h, setting.hoverAnim)
    }
    Gdip_TextToGraphics(G, "Select", "x" x " y" y + 13 " w" setting.w " h30 Center s16 Bold cFFE8EDF5")
}

DrawToggleSetting(setting) {
    global G
    x := setting.x
    y := setting.y
    if setting.hover
        setting.hoverAnim += (1 - setting.hoverAnim) * 0.25
    else
        setting.hoverAnim += (0 - setting.hoverAnim) * 0.45
    Gdip_TextToGraphics(G, setting.text, "x" x - 120 " y" y + 13 + setting.textOffsetY " w400 h25 s" setting.fontSize " Bold cFFE8EDF5")
    bgColor := 0x35182030
    bg := Gdip_BrushCreateSolid(bgColor)
    Gdip_FillRectangle(G, bg, x, y, setting.w, setting.h)
    Gdip_DeleteBrush(bg)
    pen := Gdip_CreatePen(setting.hover ? 0xFFFFFFFF : 0xFFFFFFFF, setting.hover ? 2 : 1)
    Gdip_DrawRectangle(G, pen, x, y, setting.w, setting.h)
    Gdip_DeletePen(pen)
    if setting.hoverAnim > 0.01 {
        DrawSettingHoverFrame(x, y, setting.w, setting.h, setting.hoverAnim)
    }
    Gdip_TextToGraphics(G, "◀", "x" x + 5 " y" y + 13 " w25 h30 Center s15 Bold cFFFFFFFF")
    Gdip_TextToGraphics(G, "▶", "x" x + setting.w - 30 " y" y + 13 " w25 h30 Center s15 Bold cFFFFFFFF")
    stateText := setting.value ? "ON" : "OFF"
    Gdip_TextToGraphics(G, stateText, "x" x + 30 " y" y + 13 " w" setting.w - 60 " h30 Center s16 Bold cFFE8EDF5")
}

UpdateCategoryVisibility() {
    global State, Presets, ProfilesUI
    show := (State.currentCategory == "presets")
    for name, preset in Presets {
        preset.visible := show
        if (!show) {
            preset.hover := false
            preset.hoverAnim := 0
        }
    }
    for name, profile in ProfilesUI {
        profile.visible := show
        if (!show) {
            profile.hover := false
            profile.hoverAnim := 0
        }
    }
}

DrawPresets() {
    global G, UI
    for name, preset in Presets {
        if preset.visible
            DrawPreset(name, preset)
    }
}

DrawButtons() {
    global Buttons
    if Buttons.Has("settings") && Buttons["settings"].visible
        DrawSideButton(Buttons["settings"])
    if Buttons.Has("presets") && Buttons["presets"].visible
        DrawSideButton(Buttons["presets"])
    if Buttons.Has("exit") && Buttons["exit"].visible
        DrawSideButton(Buttons["exit"])
    if Buttons.Has("save") && Buttons["save"].visible
        DrawSideButton(Buttons["save"])
}

DrawCloseButton(button, x, y) {
    global G
    color := button.hover ? 0xFFE6C978 : 0xFFB8B8B8
    pen := Gdip_CreatePen(color, 2)
    Gdip_DrawLine(G, pen, x, y, x + 20, y + 20)
    Gdip_DrawLine(G, pen, x + 20, y, x, y + 20)
    Gdip_DeletePen(pen)
}

DrawPreset(name, preset) {
    global G, UI
    x := preset.x
    y := preset.y
    size := preset.size
    if preset.hover {
        preset.hoverAnim += (1 - preset.hoverAnim) * 0.25
    } else {
        preset.hoverAnim += (0 - preset.hoverAnim) * 0.45
    }
    if preset.selected {
        preset.selectedAnim += (1 - preset.selectedAnim) * 0.25
    } else {
        preset.selectedAnim += (0 - preset.selectedAnim) * 0.45
    }
    frameColor := preset.selected ? 0xFFE0B85C : 0xFF817D82
    DrawPresetFrame(x, y, size, frameColor, preset.selected || preset.hover ? 2 : 1)
    if preset.hoverAnim > 0.01 {
        DrawPresetHoverFrame(x, y, size, preset.hoverAnim)
    }
    textColor := preset.selected ? "FFE0B85C" : "FFFFFFFF"
    Gdip_TextToGraphics(G, preset.text, "x" x - 20 " y" y + size + 10 " w" size + 40 " h25 Center s12 Bold c" textColor, "Arial")
}

DrawPresetFrame(x, y, size, color, width) {
    global G
    pen := Gdip_CreatePen(color, width)
    Gdip_DrawLine(G, pen, x + size / 2, y, x + size, y + size / 2)
    Gdip_DrawLine(G, pen, x + size, y + size / 2, x + size / 2, y + size)
    Gdip_DrawLine(G, pen, x + size / 2, y + size, x, y + size / 2)
    Gdip_DrawLine(G, pen, x, y + size / 2, x + size / 2, y)
    Gdip_DeletePen(pen)
}

DrawButton(button) {
    global G, UI
    x := button.x
    y := button.y
    if button.style = "close" {
        DrawCloseButton(button, x, y)
        return
    }
    if button.hover {
        button.hoverAnim += (1 - button.hoverAnim) * 0.25
    } else {
        button.hoverAnim += (0 - button.hoverAnim) * 0.45
    }
    glow := Round(button.hoverAnim * 40)
    if button.style = "green" {
        pulseAlpha := Round(button.pulseAmount)
        bgColor := ((40 + pulseAlpha) << 24) | 0x4D9C5D
    } else {
        bgColor := 0x35101822
    }
    bg := Gdip_BrushCreateSolid(bgColor)
    Gdip_FillRectangle(G, bg, x, y, button.w, button.h)
    Gdip_DeleteBrush(bg)
    borderColor := 0xFFFFFFFF
    pen := Gdip_CreatePen(borderColor, button.hover ? 2 : 1)
    Gdip_DrawRectangle(G, pen, x, y, button.w, button.h)
    if button.hoverAnim > 0.01 {
        DrawHoverFrame(x, y, button.w, button.h, button.hoverAnim)
    }
    if button.style = "green" {
        button.pulse += button.pulseSpeed
        pulse := (Sin(button.pulse) + 1) / 2
        button.pulseAmount := pulse * 20
    }
    Gdip_DeletePen(pen)
    if button.style = "close" {
        color := button.hover ? 0xFFE6C978 : 0xFFB8B8B8
        pen := Gdip_CreatePen(color, 2)
        Gdip_DrawLine(G, pen, x, y, x + 20, y + 20)
        Gdip_DrawLine(G, pen, x + 20, y, x, y + 20)
        Gdip_DeletePen(pen)
        return
    }
    if button.text {
        textOffset := button.HasOwnProp("textOffsetY") ? button.textOffsetY : 0
        textWidth := button.w
        Gdip_TextToGraphics(G, button.text, "x" x " y" y + 17 + textOffset " w" textWidth " h30 Center s18 Bold cFFE8EDF5")
    }
}

PrepareTransparentFrame() {
    global
    oldAlpha := UI.alpha
    Draw()
    newHbm := Gdip_CreateHBITMAPFromBitmap(Bitmap)
    oldHbm := SelectObject(hdc, newHbm)
    if oldHbm
        DllCall("DeleteObject", "ptr", oldHbm)
    hbm := newHbm
    UpdateLayeredWindow(hwnd, hdc, , , WIDTH, HEIGHT, oldAlpha)
    UI.alpha := oldAlpha
}

WM_SETCURSOR(wParam, lParam, msg, hwnd) {
    global Buttons, UI, State, Settings, GlobalSettingsRows, PresetRows, DiscordLink, Overlay
    if ExitOverlay.visible {
        for _, btnName in ["confirmButton", "cancelButton"] {
            btn := ExitOverlay.%btnName%
            if (UI.mouseX > btn.x && UI.mouseX < btn.x + btn.w && UI.mouseY > btn.y && UI.mouseY < btn.y + btn.h) {
                SetCursor("hand")
                return true
            }
        }
        SetCursor("arrow")
        return true
    }
    if Overlay.visible {
        part := HitTestGearPanel(UI.mouseX, UI.mouseY)
        if part = "button" || RegExMatch(part, "^option:") || part = "menu" {
            SetCursor("hand")
            return true
        }
        for _, slot in LoadoutSlots {
            if (UI.mouseX > slot.x && UI.mouseX < slot.x + slot.w && UI.mouseY > slot.y && UI.mouseY < slot.y + slot.h) {
                SetCursor("hand")
                return true
            }
        }
        btn := Overlay.saveButton
        if (UI.mouseX > btn.x && UI.mouseX < btn.x + btn.w && UI.mouseY > btn.y && UI.mouseY < btn.y + btn.h) {
            SetCursor("hand")
            return true
        }
        SetCursor("arrow")
        return true
    }
    UpdateDiscordLinkLayout()
    if (UI.mouseX >= DiscordLink.x && UI.mouseX <= DiscordLink.x + DiscordLink.w
        && UI.mouseY >= DiscordLink.y && UI.mouseY <= DiscordLink.y + DiscordLink.h) {
        SetCursor("hand")
        return true
    }
    hovered := false
    for name, button in Buttons {
        bx := button.x
        by := button.y
        if button.visible && UI.mouseX > bx && UI.mouseX < bx + button.w && UI.mouseY > by && UI.mouseY < by + button.h {
            hovered := true
            break
        }
    }
    if !hovered && State.currentCategory = "settings" {
        for _, row in GlobalSettingsRows {
            if GetRowHoverPart(row, UI.mouseX, UI.mouseY) != "" {
                hovered := true
                break
            }
        }
    }
    if !hovered && State.currentCategory = "presets" {
        for _, row in PresetRows {
            if GetRowHoverPart(row, UI.mouseX, UI.mouseY) != "" {
                hovered := true
                break
            }
        }
        if !hovered {
            for _, setting in Settings {
                if GetRowHoverPart(setting, UI.mouseX, UI.mouseY) != "" {
                    hovered := true
                    break
                }
            }
        }
    }
    if hovered {
        SetCursor("hand")
        return true
    }
    SetCursor("arrow")
    return true
}

State.currentCategory := "settings"
UpdateCategoryVisibility()
InitPresetRows()
SyncPresetRowsFromState()

WM_KEYUP(wParam, lParam, msg, hwnd) {
    global Settings, HotkeyState, GlobalSettingsRows
    for _, row in GlobalSettingsRows {
        if !row.listening
            continue
        if wParam = 0x11 {
            HotkeyState.ctrl := false
            if InStr(row.value, "Ctrl +") {
                row.value := RemoveModifierPlus(row.value)
                FinishGlobalHotkeyEdit(row)
                SaveGlobalSettingRow(row)
            }
            return
        }
        if wParam = 0x10 {
            HotkeyState.shift := false
            if InStr(row.value, "Shift +") {
                row.value := RemoveModifierPlus(row.value)
                FinishGlobalHotkeyEdit(row)
                SaveGlobalSettingRow(row)
            }
            return
        }
        if wParam = 0x12 {
            HotkeyState.alt := false
            if InStr(row.value, "Alt +") {
                row.value := RemoveModifierPlus(row.value)
                FinishGlobalHotkeyEdit(row)
                SaveGlobalSettingRow(row)
            }
            return
        }
    }
    for _, setting in Settings {
        if !setting.listening
            continue
        if wParam = 0x11 {
            HotkeyState.ctrl := false
            if InStr(setting.value, "Ctrl +") {
                setting.value := RemoveModifierPlus(setting.value)
                FinishHotkeyEdit(setting)
            }
            return
        }
        if wParam = 0x10 {
            HotkeyState.shift := false
            if InStr(setting.value, "Shift +") {
                setting.value := RemoveModifierPlus(setting.value)
                FinishHotkeyEdit(setting)
            }
            return
        }
        if wParam = 0x12 {
            HotkeyState.alt := false
            if InStr(setting.value, "Alt +") {
                setting.value := RemoveModifierPlus(setting.value)
                FinishHotkeyEdit(setting)
            }
            return
        }
    }
}

WM_KEYDOWN(wParam, lParam, msg, hwnd) {
    global Settings, HotkeyState, GlobalSettingsRows
    for _, row in GlobalSettingsRows {
        if !row.listening
            continue
        if wParam = 27 {
            row.value := "None"
            FinishGlobalHotkeyEdit(row)
            SaveGlobalSettingRow(row)
            return
        }
        if wParam = 0x12 {
            HotkeyState.alt := true
            UpdateGlobalModifierPreview(row)
            return
        }
        if wParam = 0x11 {
            HotkeyState.ctrl := true
            UpdateGlobalModifierPreview(row)
            return
        }
        if wParam = 0x10 {
            HotkeyState.shift := true
            UpdateGlobalModifierPreview(row)
            return
        }
        HandleGlobalHotkeyInput(row, wParam)
        return
    }
    for _, row in GlobalSettingsRows {
        if !row.editing
            continue
        if IsLoadoutDelayRowDisabled(row)
            continue
        key := VKToEnglish(wParam)
        if wParam = 13 {
            FinishGlobalSettingEdit(row)
            return
        }
        if wParam = 27 {
            row.editing := false
            row.editValue := ""
            return
        }
        if wParam = 8 {
            row.editValue := SubStr(row.editValue, 1, -1)
            return
        }
        if RegExMatch(key, "^\d$") {
            if StrLen(row.editValue) < 4
                row.editValue .= key
        }
        return
    }
    for _, setting in Settings {
        if !setting.listening
            continue
        if wParam = 27 {
            setting.value := "None"
            FinishHotkeyEdit(setting)
            SaveCurrentProfile()
            SaveSettings()
            return
        }
        if wParam = 0x12 {
            HotkeyState.alt := true
            UpdateModifierPreview(setting)
            return
        }
        if wParam = 0x11 {
            HotkeyState.ctrl := true
            UpdateModifierPreview(setting)
            return
        }
        if wParam = 0x10 {
            HotkeyState.shift := true
            UpdateModifierPreview(setting)
            return
        }
        keyName := GetKeyNameFromVK(wParam)
        HandleHotkeyInput(setting, wParam)
        return
    }
    for name, setting in Settings {
        if !setting.editing
            continue
        key := VKToEnglish(wParam)
        if wParam = 13 {
            if RegExMatch(setting.editValue, "^\d{1,3}$") {
                value := Integer(setting.editValue)
                if value >= 1 && value <= 999
                    setting.value := value
            }
            FinishSettingEdit(setting)
            return
        }
        if wParam = 27 {
            FinishSettingEdit(setting)
            return
        }
        if wParam = 8 {
            setting.editValue := SubStr(setting.editValue, 1, -1)
            return
        }
        if RegExMatch(key, "^\d$") {
            if StrLen(setting.editValue) < 3
                setting.editValue .= key
        }
    }
}

WM_MOUSEMOVE(wParam, lParam, msg, hwnd) {
    global UI, Buttons, Presets, Settings, Overlay, LoadoutSlots, ExitOverlay, State, GlobalSettingsRows, PresetRows, DiscordLink

    UI.mouseX := lParam & 0xFFFF
    UI.mouseY := (lParam >> 16) & 0xFFFF

    if ExitOverlay.visible {
        for _, btnName in ["confirmButton", "cancelButton"] {
            btn := ExitOverlay.%btnName%
            btn.hover := (UI.mouseX > btn.x && UI.mouseX < btn.x + btn.w && UI.mouseY > btn.y && UI.mouseY < btn.y + btn.h)
        }
        return
    }

    if Overlay.visible {
        return
    }

    UpdateDiscordLinkLayout()
    UpdateDiscordLinkHover()

    for name, button in Buttons {
        if button.visible {
            bx := button.x
            by := button.y
            button.hover := (UI.mouseX > bx && UI.mouseX < bx + button.w && UI.mouseY > by && UI.mouseY < by + button.h)
        } else {
            button.hover := false
        }
    }

    if (State.currentCategory = "settings") {
        for _, row in GlobalSettingsRows
            UpdateRowHoverFromMouse(row, UI.mouseX, UI.mouseY)
    } else {
        for _, row in GlobalSettingsRows {
            row.hoverLeft := false
            row.hoverRight := false
            row.hoverBox := false
        }
    }

    if (State.currentCategory = "presets") {
        for _, row in PresetRows
            UpdateRowHoverFromMouse(row, UI.mouseX, UI.mouseY)
        for _, setting in Settings
            UpdateRowHoverFromMouse(setting, UI.mouseX, UI.mouseY)
    } else {
        for _, row in PresetRows {
            row.hoverLeft := false
            row.hoverRight := false
            row.hoverBox := false
        }
        for _, setting in Settings {
            setting.hoverLeft := false
            setting.hoverRight := false
            setting.hoverBox := false
        }
    }
}

WM_LBUTTONDOWN(wParam, lParam, msg, hwnd) {
    global MainGui, UI, Overlay, ExitOverlay, Buttons, Presets, ProfilesUI, State, Settings, GlobalSettings, Profiles, LoadoutSlots, SettingsControls, GlobalSettingsRows, SETTINGS_ROW_X, SETTINGS_ROW_W, SETTINGS_ROW_H, DiscordLink

    x := lParam & 0xFFFF
    y := (lParam >> 16) & 0xFFFF
    mouseX := x
    mouseY := y

    if ExitOverlay.visible {
    btnC := ExitOverlay.confirmButton
    if (x > btnC.x && x < btnC.x + btnC.w && y > btnC.y && y < btnC.y + btnC.h) {
        ExitApp()
        return
    }
    btnCn := ExitOverlay.cancelButton
    if (x > btnCn.x && x < btnCn.x + btnCn.w && y > btnCn.y && y < btnCn.y + btnCn.h) {
        ExitOverlay.visible := false
        return
    }
    return
    }

    if !Overlay.visible && !ExitOverlay.visible {
        UpdateDiscordLinkLayout()
        if (x >= DiscordLink.x && x <= DiscordLink.x + DiscordLink.w && y >= DiscordLink.y && y <= DiscordLink.y + DiscordLink.h) {
            CopyDiscordLink()
            return
        }
    }

    if y < 47 {
        UI.dragging := true
        PostMessage(0xA1, 2, 0, , "ahk_id " MainGui.Hwnd)
        KeyWait("LButton")
        UI.dragging := false
        return
    }

    if Overlay.visible {
        if !IsPointInLoadoutOverlayArea(x, y) {
            Overlay.visible := false
            return
        }

        gearPart := HitTestGearPanel(x, y)
        if gearPart = "button" {
            gp := Overlay.gearPanel
            gp.gearMenuOpen := !gp.gearMenuOpen
            return
        }
        if RegExMatch(gearPart, "^option:(\d+)", &match) {
            idx := Integer(match[1])
            gp := Overlay.gearPanel
            if idx >= 1 && idx <= gp.options.Length {
                Profiles[State.class][State.profile].SelectedGear := gp.options[idx]
                SaveSettings()
            }
            gp.gearMenuOpen := false
            return
        }
        if gearPart = "menu" {
            return
        }
        if Overlay.gearPanel.gearMenuOpen {
            Overlay.gearPanel.gearMenuOpen := false
        }

        for _, slot in LoadoutSlots {
            if (x > slot.x && x < slot.x + slot.w && y > slot.y && y < slot.y + slot.h) {
                slot.selected := !slot.selected
                SaveCurrentLoadouts()
                return
            }
        }

        btn := Overlay.saveButton
        if (x > btn.x && x < btn.x + btn.w && y > btn.y && y < btn.y + btn.h) {
            Overlay.visible := false
            return
        }
        return
    }

    for name, preset in Presets {
        if preset.visible {
            px := preset.x
            py := preset.y
            if (x > px && x < px + preset.size && y > py && y < py + preset.size)
                return
        }
    }

    if Buttons.Has("settings") && Buttons["settings"].visible {
        bx := Buttons["settings"].x
        by := Buttons["settings"].y
        if (x > bx && x < bx + Buttons["settings"].w && y > by && y < by + Buttons["settings"].h) {
            SwitchCategory("settings")
            return
        }
    }

    if Buttons.Has("presets") && Buttons["presets"].visible {
        bx := Buttons["presets"].x
        by := Buttons["presets"].y
        if (x > bx && x < bx + Buttons["presets"].w && y > by && y < by + Buttons["presets"].h) {
            SwitchCategory("presets")
            return
        }
    }

    if Buttons.Has("save") && Buttons["save"].visible {
        bx := Buttons["save"].x
        by := Buttons["save"].y
        if (x > bx && x < bx + Buttons["save"].w && y > by && y < by + Buttons["save"].h) {
            State.currentCategory := "save"
            FinishAllSettingsEdit()
            SaveCurrentProfile()
            GlobalSettings.CurrentPreset := State.class
            SaveSettings()
            DeleteSettingsBackup()
            Reload()
            return
        }
    }

    if Buttons.Has("exit") && Buttons["exit"].visible {
        bx := Buttons["exit"].x
        by := Buttons["exit"].y
        if (x > bx && x < bx + Buttons["exit"].w && y > by && y < by + Buttons["exit"].h) {
            ExitOverlay.visible := true
            return
        }
    }

    if (State.currentCategory == "settings") {
        for _, row in GlobalSettingsRows {
            part := GetRowHoverPart(row, x, y)
            if part != "" {
                HandleRowClick(row, part)
                return
            }
        }
    }

    if (State.currentCategory == "presets") {
        for _, row in PresetRows {
            part := GetRowHoverPart(row, x, y)
            if part != "" {
                HandleRowClick(row, part)
                return
            }
        }
        for _, setting in Settings {
            part := GetRowHoverPart(setting, x, y)
            if part != "" {
                HandleSettingClick(setting, part)
                return
            }
        }
    }
}
DrawTopBar() {
    global G, EmblemBaseImage, WIDTH
    if EmblemBaseImage {
        Gdip_DrawImage(G, EmblemBaseImage, 0, 0, WIDTH, 47, 0, 0, Gdip_GetImageWidth(EmblemBaseImage), Gdip_GetImageHeight(EmblemBaseImage))
    }
}

DrawEmblemIcon() {
    global G, EmblemIconImage
    if EmblemIconImage
        Gdip_DrawImage(G, EmblemIconImage, 36, 8, 50, 50)
}

WM_SYSKEYDOWN(wParam, lParam, msg, hwnd) {
    if wParam = 0x12 {
        WM_KEYDOWN(wParam, lParam, msg, hwnd)
        return 0
    }
    return WM_KEYDOWN(wParam, lParam, msg, hwnd)
}

WM_SYSKEYUP(wParam, lParam, msg, hwnd) {
    if wParam = 0x12 {
        WM_KEYUP(wParam, lParam, msg, hwnd)
        return 0
    }
    return WM_KEYUP(wParam, lParam, msg, hwnd)
}

BuildSettings()
LoadEmblemInfo()
LoadSettingsUI()
State.class := GlobalSettings.CurrentPreset
LoadCurrentProfile()
LoadCurrentLoadoutsUI()
SyncUIState()
SaveSettings()

MainGui := Gui("-Caption +E0x80000", "Loadouts Manager")
MainGui.OnEvent("Close", GuiClose)

x := (A_ScreenWidth - WIDTH) // 2
y := (A_ScreenHeight - HEIGHT) // 2
openOnStart := (Trim(GlobalSettings.OpenMenuHotkey) = "" || Trim(GlobalSettings.OpenMenuHotkey) = "None")
if openOnStart {
    CreateSettingsBackup()
    MainGui.Show("x" x " y" y " w" WIDTH " h" HEIGHT)
} else {
    MainGui.Show("Hide x" x " y" y " w" WIDTH " h" HEIGHT)
}

DllCall("SetWindowLong", "ptr", MainGui.Hwnd, "int", -20, "uint", DllCall("GetWindowLong", "ptr", MainGui.Hwnd, "int", -20) | 0x00040000)
global hwnd := MainGui.Hwnd
CheckFirstRun()

global Bitmap := Gdip_CreateBitmap(WIDTH, HEIGHT)

if FileExist(ResourceFolder "\emblembase.jpg") {
    EmblemBaseImage := Gdip_CreateBitmapFromFile(ResourceFolder "\emblembase.jpg")
}

if FileExist(ResourceFolder "\emblemicon.png") {
    EmblemIconImage := Gdip_CreateBitmapFromFile(ResourceFolder "\emblemicon.png")
}

global G := Gdip_GraphicsFromImage(Bitmap)
Gdip_SetSmoothingMode(G, 4)

global hdc := CreateCompatibleDC()
global hbm := 0
SetTimer(Render, 1)

aspect := A_ScreenWidth / A_ScreenHeight
if (Abs(aspect - 16 / 9) > 0.01) {
    MsgBox("The macro does not support resolutions other than 16:9.")
    ExitApp
}

global Loadouts := Map()
global SettingsFile := A_ScriptDir "\loadouts_d2\settings.ini"

LoadSettings()
ScaleX := A_ScreenWidth / 1920
ScaleY := A_ScreenHeight / 1080
global QPF := 0
DllCall("QueryPerformanceFrequency", "Int64*", &QPF)

#HotIf WinActive("ahk_exe destiny2.exe")

if SwapHotkeys["27k"] != "None"
    hotkey(SwapHotkeys["27k"], (*) => Swaps("27k"))
if SwapHotkeys["3074"] != "None"
    hotkey(SwapHotkeys["3074"], (*) => Swaps("3074"))
if SwapHotkeys["noport"] != "None"
    hotkey(SwapHotkeys["noport"], (*) => Swaps("noport"))

WatchLast := ""
Watching := false
LoadoutMenuStateCheck := 0
oldXSwap := 0
ForcedNormalDelay := 0

GearPositions := Map(
    "Helmet", { x: 1413, y: 269 },
    "Arms", { x: 1413, y: 388 },
    "Chest", { x: 1413, y: 510 },
    "Legs", { x: 1413, y: 628 },
    "Class Item", { x: 1413, y: 769 }
)

LoadoutPositions := [
    { x: 110, y: 380, test: 220 },
    { x: 210, y: 380, test: 320 },
    { x: 310, y: 380, Test: 420 },
    { x: 410, y: 380, Test: 520 },
    { x: 110, y: 480, test: 220 },
    { x: 210, y: 480, test: 320 },
    { x: 310, y: 480, Test: 420 },
    { x: 410, y: 480, Test: 520 },
    { x: 110, y: 580, test: 220 },
    { x: 210, y: 580, test: 320 },
    { x: 310, y: 580, Test: 420 },
    { x: 410, y: 580, Test: 520 },
    { x: 110, y: 680, test: 220 },
    { x: 210, y: 680, test: 320 },
    { x: 310, y: 680, Test: 420 },
    { x: 410, y: 680, Test: 520 },
    { x: 110, y: 780, test: 220 },
    { x: 210, y: 780, test: 320 },
    { x: 310, y: 780, Test: 420 },
    { x: 410, y: 780, Test: 520 }
]

#SingleInstance Force
A_WorkingDir := A_ScriptDir
CoordMode("Mouse", "Screen")
CoordMode("Pixel", "Screen")
SendMode("Input")
SetKeyDelay(-1)
SetMouseDelay(-1)
SetDefaultMouseSpeed(0)
SetWinDelay(-1)
SetControlDelay(-1)

LoadSettings() {
    LoadGlobalSettings()
    LoadSwapHotkeys()
    LoadCurrentLoadouts()
}

LoadGlobalSettings() {
    global Settings, SettingsFile
    SwapSettings["CurrentPreset"] := IniRead(SettingsFile, "Global", "CurrentPreset", "hunter")
    SwapSettings["DL3074Hotkey"] := IniRead(SettingsFile, "Global", "DL3074Hotkey", "None")
    SwapSettings["OpenMenuHotkey"] := IniRead(SettingsFile, "Global", "OpenMenuHotkey", "None")
    SwapSettings["UL27kHotkey"] := IniRead(SettingsFile, "Global", "UL27kHotkey", "None")
    SwapSettings["UL3074Hotkey"] := IniRead(SettingsFile, "Global", "UL3074Hotkey", "None")
}

LoadSwapHotkeys() {
    global SwapHotkeys, SettingsFile
    SwapHotkeys["27k"] := IniRead(SettingsFile, "SwapHotkeys", "27k", "None")
    SwapHotkeys["3074"] := IniRead(SettingsFile, "SwapHotkeys", "3074", "None")
    SwapHotkeys["noport"] := IniRead(SettingsFile, "SwapHotkeys", "noport", "None")
}

LoadCurrentLoadouts() {
    global Settings, Loadouts
    preset := SwapSettings["CurrentPreset"]
    for mode in ["27k", "3074", "noport"] {
        section := preset "_" mode
        Loadouts[mode] := LoadLoadout(section)
    }
}

LoadLoadout(section) {
    global SettingsFile, GlobalSettings
    return Map(
        "swapCount", Integer(IniRead(SettingsFile, section, "swapCount", 20)),
        "untickDelay", Integer(IniRead(SettingsFile, section, "untickDelay", 550)),
        "loadoutDelay", GlobalSettings.GlobalLoadoutDelay,
        "finalLoadout", Integer(IniRead(SettingsFile, section, "finalLoadout", 1)),
        "advancedDelay", GlobalSettings.GlobalAdvancedDelay ? 1 : 0,
        "dl3074", Integer(IniRead(SettingsFile, section, "dl3074", 0)),
        "autoDisableBuffering", Integer(IniRead(SettingsFile, section, "autoDisableBuffering", IniRead(SettingsFile, section, "disableAutoResync", 0))),
        "SelectedGear", IniRead(SettingsFile, section, "SelectedGear", "Helmet"),
        "selectedLoadouts", OptimizeLoadouts(IniRead(SettingsFile, section, "selectedLoadouts", ""), Integer(IniRead(SettingsFile, section, "finalLoadout", 1)))
    )
}

OptimizeLoadouts(value, finalLoadout) {
    if (Trim(value) = "")
        return []
    loadouts := []
    for item in StrSplit(value, ",") {
        item := Trim(item)
        if item != ""
            loadouts.Push(Integer(item))
    }
    if loadouts.Length = 0
        return []
    ordered := []
    hasFinal := false
    for item in loadouts {
        if item = finalLoadout {
            hasFinal := true
            break
        }
    }
    if hasFinal {
        ordered.Push(finalLoadout)
        for item in loadouts {
            if item != finalLoadout
                ordered.Push(item)
        }
    } else {
        ordered := loadouts.Clone()
    }
    result := [ordered[1]]
    remaining := []
    Loop ordered.Length - 1
        remaining.Push(ordered[A_Index + 1])
    current := result[1]
    while remaining.Length {
        currentColumn := Mod(current - 1, 4) + 1
        bestIndex := 1
        bestScore := -999999
        for index, item in remaining {
            itemColumn := Mod(item - 1, 4) + 1
            score := 0
            if itemColumn != currentColumn
                score += 100
            score += Abs(itemColumn - currentColumn)
            if score > bestScore {
                bestScore := score
                bestIndex := index
            }
        }
        current := remaining.RemoveAt(bestIndex)
        result.Push(current)
    }
    return result
}

PreciseSleep(ms) {
    global QPF, Watching, ScaleX, ScaleY, gear
    start := 0
    now := 0
    lastWatch := 0
    DllCall("QueryPerformanceCounter", "Int64*", &start)
    target := start + (ms / 1000) * QPF
    while (now < target) {
        DllCall("QueryPerformanceCounter", "Int64*", &now)
        remaining := (target - now) / QPF * 1000
        if (remaining > 18) {
            Sleep(1)
            continue
        }
        if (Watching && now - lastWatch > QPF / 5) {
            lastWatch := now
            WatchPixel(Round(gear.x * ScaleX), Round(gear.y * ScaleY))
        }
    }
    return ((now - start) / QPF * 1000)
}

LoadoutSwap(x, y, load_test_x) {
    global ScaleX, ScaleY, LoadoutMenuStateCheck, oldXSwap, ForcedNormalDelay
    WatchLast := PixelGetColor(Round(gear.x * ScaleX), Round(gear.y * ScaleY))
    if (GlobalSettings.GlobalSwapTimer && !((WatchChanges > loadout["swapCount"] || start + Timeout <= A_TickCount)) && WatchChanges >= 0)
        ToolTip(WatchChanges . "/" . loadout["swapCount"], 73 * ScaleX, 820 * ScaleY, 1)
    MouseMove(Round(x * ScaleX), Round(y * ScaleY))
    if x != oldXSwap {
        oldXSwap := x
        ForcedNormalDelay := 0
    } else {
        ForcedNormalDelay := 1
    }
    if (loadout["advancedDelay"] && ForcedNormalDelay == 0) {
        PreciseSleep(15)
        exit := false
        loop 2 {
            for y in [740, 350, 430, 470] {
                color := PixelGetColor(Round(load_test_x * ScaleX), Round(y * ScaleY))
                if RegExMatch(color, "F.F.F.") {
                    Send "{LButton down}"
                    PreciseSleep(5)
                    Send "{LButton up}"
                    exit := true
                    break
                }
            }
            if exit
                break
        }
        Click()
    } else {
        PreciseSleep(loadout["loadoutDelay"] / 2)
        Send "{LButton down}"
        PreciseSleep(loadout["loadoutDelay"] / 2)
        Send "{LButton up}"
    }
}

WatchPixel(x, y) {
    global WatchLast
    global WatchChanges
    c := PixelGetColor(x, y)
    if (c != WatchLast) {
        WatchChanges++
        WatchLast := c
    }
}

SendModified(key) {
    modifiers := ""
    alt := false
    ctrl := false
    shift := false
    win := false
    key := StrReplace(key, " ", "")
    if InStr(key, "Alt+") {
        modifiers .= "{LAlt down}"
        key := StrReplace(key, "Alt+")
        alt := true
    }
    if InStr(key, "Ctrl+") {
        modifiers .= "{LCtrl down}"
        key := StrReplace(key, "Ctrl+")
        ctrl := true
    }
    if InStr(key, "Shift+") {
        modifiers .= "{LShift down}"
        key := StrReplace(key, "Shift+")
        shift := true
    }
    if InStr(key, "Win+") {
        modifiers .= "{LWin down}"
        key := StrReplace(key, "Win+")
        win := true
    }
    key := NormalizeKeyName(key)
    if RegExMatch(key, "i)^(LButton|MButton|RButton|XButton1|XButton2|WheelDown|WheelUp|WheelLeft|WheelRight|CapsLock|Space|Tab|Enter|Return|Backspace|BS|Delete|Del|Insert|Ins|Home|End|PgUp|PageUp|PgDn|PageDown|Up|Down|Left|Right|ScrollLock|PrintScreen|Pause|Break|Escape|Esc|NumLock|Numpad\d|NumpadDot|NumpadEnter|NumpadMult|NumpadDiv|NumpadAdd|NumpadSub|F\d+|`|;|=|,|\-|\.|/|\[|\]|\\|')$") {
        keyPresses := "{" key " down}{" key " up}"
    } else {
        keyPresses := ""
        for _, char in StrSplit(key)
            keyPresses .= "{" char " down}"
        for _, char in StrSplit(key)
            keyPresses .= "{" char " up}"
    }
    Send(modifiers keyPresses)
    if alt
        Send("{LAlt up}")
    if ctrl
        Send("{LCtrl up}")
    if shift
        Send("{LShift up}")
    if win
        Send("{LWin up}")
}

CheckInventory() {
    global Watching, invLeave
    Watching := false
    invLeave := 0
    Loop 10 {
        invscreencolor := PixelGetColor(Round(960 * ScaleX), Round(1035 * ScaleY))
        invscreencolor2 := PixelGetColor(Round(960 * ScaleX), Round(1014 * ScaleY))
        loadoutColor := PixelGetColor(Round(77 * ScaleX), Round(104 * ScaleY))
        if (!RegExMatch(invscreencolor, "0xE.E.E.") && !RegExMatch(invscreencolor2, "0xE.E.E.") && !RegExMatch(loadoutColor, "0xE.E.E.") && !RegExMatch(loadoutColor, "0xD.D.D.") && !RegExMatch(invscreencolor, "0xD.D.D.") && !RegExMatch(invscreencolor2, "0xD.D.D.")) {
            return True
        }
    }
    else {
        return False
    }
}

InventoryAction(State) {
    global LoadoutMenuStateCheck, ScaleX, ScaleY
    if (State == "Fresh") {
        send "{F1}"
        send "{rbutton up}"
        PreciseSleep(700)
        Loop 40 {
            MouseMove(Round(50 * ScaleX), Round(A_ScreenHeight / 2), 0)
            Send "{Left}"
            Send "{LButton}"
            PreciseSleep(1)
            loadoutColor := PixelGetColor(Round(77 * ScaleX), Round(104 * ScaleY))
            if (RegExMatch(loadoutColor, "0xE.E.E.") || RegExMatch(loadoutColor, "0xD.D.D.")) {
                LoadoutMenuStateCheck := 1
                break
            } else {
                LoadoutMenuStateCheck := 0
            }
        }
    } else if (State == "Inventory") {
        Send "{Left}"
        MouseMove(Round(50 * ScaleX), Round(A_ScreenHeight / 2), 0)
        PreciseSleep(100)
    }
}

WaitForLoadoutScreen() {
    global LoadoutMenuStateCheck, ScaleX, ScaleY
    start2 := A_TickCount
    Loop {
        loadoutColor := PixelGetColor(Round(77 * ScaleX), Round(104 * ScaleY))
        if ((RegExMatch(loadoutColor, "0xE.E.E.") || RegExMatch(loadoutColor, "0xD.D.D.") || LoadoutMenuStateCheck || A_TickCount >= start2 + 500))
            return True
    }
    return False
}

Swaps(mode) {
    global LoadoutMenuStateCheck, oldXSwap
    global loadout := Loadouts[mode]
    global gear := GearPositions[loadout["SelectedGear"]]
    global Timeout := loadout["swapCount"] * 500
    FL := loadout["finalLoadout"]
    if loadout["selectedLoadouts"].Length = 0 {
        return
    }
    savedCfg := ""
    if loadout["autoDisableBuffering"]
        savedCfg := DisableCfgBuffering()
    try {
        if (mode != "noport") {
            SendModified(SwapSettings["UL" mode "Hotkey"])
        }
        if (loadout["dl3074"] && SwapSettings["DL3074Hotkey"] != "None") {
            PreciseSleep(100)
            SendModified(SwapSettings["DL3074Hotkey"])
        }
        if CheckInventory() {
            InventoryAction("Fresh")
        } else {
            InventoryAction("Inventory")
        }
        WaitForLoadoutScreen()
        PreciseSleep(50)
        global Watching := true
        global WatchChanges := -1
        global start := A_TickCount
        Loop {
            activePositions := GetActiveLoadoutPositions()
            for index, l in loadout["selectedLoadouts"] {
                if GlobalSettings.SixteenLoadoutsOnly && l > 16
                    continue
                LoadoutInfo := activePositions[l]
                if (l != FL || loadout["swapCount"] - 4 >= WatchChanges) {
                    LoadoutSwap(LoadoutInfo.x, LoadoutInfo.y, LoadoutInfo.test)
                }
            }
            if (WatchChanges >= loadout["swapCount"] || start + Timeout <= A_TickCount) {
                break
            }
        }
        Watching := false
        time := round((A_TickCount - start) / 1000, 2)
        activePositions := GetActiveLoadoutPositions()
        LoadoutInfo := activePositions[FL]
        WatchChanges++
        LoadoutSwap(LoadoutInfo.x, LoadoutInfo.y, LoadoutInfo.test)
        ToolTip("")
        delays := [70, 70, 10, 10]
        for index, d in delays {
            PreciseSleep(d)
            send "{LButton}"
        }
        global start3 := A_TickCount + loadout["untickDelay"]
        if GlobalSettings.GlobalCloseInventory
            send "{F1}"
        Loop {
            PreciseSleep(1)
            if (start3 <= A_TickCount) {
                break
            }
        }
        if (mode != "noport") {
            SendModified(SwapSettings["UL" mode "Hotkey"])
        }
        if (loadout["dl3074"] && SwapSettings["DL3074Hotkey"] != "None") {
            PreciseSleep(100)
            SendModified(SwapSettings["DL3074Hotkey"])
        }
        oldXSwap := 0
    } finally {
        if savedCfg != ""
            RestoreCfgContent(savedCfg)
    }
}